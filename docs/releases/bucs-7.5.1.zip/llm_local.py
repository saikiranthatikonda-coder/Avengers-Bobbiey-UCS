"""OpenAI-compatible local LLM client.

Works with Ollama (http://127.0.0.1:11434/v1), LM Studio (http://127.0.0.1:1234/v1),
llama.cpp server, vLLM, or any endpoint that speaks /v1/chat/completions.

Configure via .env:
    LOCAL_LLM_URL=http://127.0.0.1:11434/v1
    LOCAL_LLM_MODEL=llama3.2        # optional — auto-picks first model if empty
    LOCAL_LLM_KEY=                  # optional bearer token
"""

import asyncio
import json
import os
import time
from pathlib import Path

import httpx

PREF_FILE = Path(__file__).parent / "model_pref.json"


class LocalLLM:
    def __init__(self, base_url: str | None = None, model: str | None = None,
                 api_key: str | None = None, hub=None, isolated: bool = False) -> None:
        # isolated=True: a provider-registry client (llm_providers.py). It must
        # NOT pick up the Ollama env/pref model or LOCAL_LLM_KEY — that would
        # silently swap its model or send the local key to a remote provider.
        self.base_url = (base_url or ("" if isolated else os.getenv("LOCAL_LLM_URL",
                         "http://127.0.0.1:11434/v1"))).rstrip("/")
        self.model = model or (None if isolated else os.getenv("LOCAL_LLM_MODEL")) or None
        self.last_error: str | None = None
        # persisted selection (survives restarts) takes precedence
        self.pref_force_local = False   # user chose a local/Ollama brain last time
        if not isolated:
            try:
                pref = json.loads(PREF_FILE.read_text(encoding="utf-8"))
                if pref.get("model"):
                    self.model = pref["model"]
                self.pref_force_local = bool(pref.get("force_local"))
            except Exception:
                pass
        self.api_key = api_key or (None if isolated else os.getenv("LOCAL_LLM_KEY")) or None
        self.hub = hub
        self.available = False
        self.remote_node = None                    # set when routed to a fleet node's Ollama
        self.last_latency_ms: int | None = None
        self.last_tps: float | None = None        # completion tokens / second
        self.last_tokens: int | None = None
        self.calls_total = 0

    def save_pref(self, force_local: bool | None = None) -> None:
        if force_local is not None:
            self.pref_force_local = force_local
        try:
            PREF_FILE.write_text(json.dumps({
                "model": self.model,
                "force_local": self.pref_force_local,
            }), encoding="utf-8")
        except Exception:
            pass

    async def list_models(self) -> list[dict]:
        """Installed local models. Prefers Ollama's native /api/tags (rich
        metadata: size, params, quantization); falls back to /v1/models."""
        root = self.base_url[:-3] if self.base_url.endswith("/v1") else self.base_url
        try:
            async with httpx.AsyncClient(timeout=5, trust_env=False) as c:
                r = await c.get(f"{root}/api/tags")
                r.raise_for_status()
                data = r.json()
            out = []
            for m in data.get("models", []):
                det = m.get("details") or {}
                out.append({
                    "name": m.get("name"),
                    "size_gb": round((m.get("size") or 0) / 1e9, 1),
                    "param_size": det.get("parameter_size"),
                    "quant": det.get("quantization_level"),
                    "family": det.get("family"),
                })
            if out:
                return out
        except Exception:
            pass
        try:
            async with httpx.AsyncClient(timeout=5, trust_env=False) as c:
                r = await c.get(f"{self.base_url}/models", headers=self._headers())
                r.raise_for_status()
                return [{"name": m.get("id")} for m in (r.json().get("data") or [])
                        if m.get("id")]
        except Exception:
            return []

    def _headers(self) -> dict:
        h = {"content-type": "application/json"}
        if self.api_key:
            h["authorization"] = f"Bearer {self.api_key}"
        return h

    async def probe(self) -> bool:
        """Check the endpoint is alive; auto-pick a model if none configured."""
        try:
            # trust_env=False: never route localhost through a system/corporate
            # proxy (causes 403 Forbidden on networks that block private addrs)
            async with httpx.AsyncClient(timeout=4, trust_env=False) as c:
                r = await c.get(f"{self.base_url}/models", headers=self._headers())
                r.raise_for_status()
                data = r.json()
            models = [m.get("id") for m in (data.get("data") or []) if m.get("id")]
            if not self.model and models:
                self.model = models[0]
            self.available = bool(self.model)
        except Exception:
            self.available = False
        return self.available

    async def running(self) -> list[dict]:
        """Models loaded in memory RIGHT NOW (Ollama /api/ps): RAM/VRAM split,
        context window, expiry. Empty on non-Ollama endpoints."""
        root = self.base_url[:-3] if self.base_url.endswith("/v1") else self.base_url
        try:
            async with httpx.AsyncClient(timeout=5, trust_env=False) as c:
                r = await c.get(f"{root}/api/ps")
                r.raise_for_status()
                data = r.json()
            out = []
            for m in data.get("models", []):
                size = m.get("size") or 0
                vram = m.get("size_vram") or 0
                out.append({
                    "name": m.get("name"),
                    "ram_gb": round(max(0, size - vram) / 1e9, 2),
                    "vram_gb": round(vram / 1e9, 2),
                    "context": m.get("context_length"),
                    "until": m.get("expires_at"),
                })
            return out
        except Exception:
            return []

    def perf(self) -> dict:
        """Latest measured performance of this client."""
        return {
            "latency_ms": self.last_latency_ms,
            "tokens_per_sec": self.last_tps,
            "last_completion_tokens": self.last_tokens,
            "calls_total": self.calls_total,
        }

    async def chat_stream(self, prompt: str, system: str | None = None, on_delta=None,
                          timeout: float = 60.0, max_tokens: int = 300) -> str | None:
        """Streaming chat over the OpenAI-compatible SSE API. Calls
        on_delta(text) per chunk; returns the full reply, or None on failure
        (callers fall back exactly as with chat())."""
        if not self.model:
            return None
        import json as _json
        messages: list[dict] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        t0 = time.time(); parts: list[str] = []
        try:
            async with httpx.AsyncClient(timeout=timeout, trust_env=False) as c:
                async with c.stream("POST", f"{self.base_url}/chat/completions",
                                    headers=self._headers(),
                                    json={"model": self.model, "messages": messages,
                                          "max_tokens": max_tokens, "temperature": 0.4,
                                          "stream": True}) as r:
                    r.raise_for_status()
                    async for line in r.aiter_lines():
                        if not line.startswith("data:"):
                            continue
                        data = line[5:].strip()
                        if data == "[DONE]":
                            break
                        try:
                            chunk = (_json.loads(data).get("choices") or [{}])[0].get("delta", {}).get("content")
                        except Exception:
                            continue
                        if chunk:
                            parts.append(chunk)
                            if on_delta:
                                await on_delta(chunk)
            self.last_latency_ms = int((time.time() - t0) * 1000)
            self.calls_total += 1
            out = "".join(parts)
            if "<think>" in out:
                import re as _re
                out = _re.sub(r"<think>.*?</think>", "", out, flags=_re.DOTALL)
            return out.strip() or None
        except asyncio.CancelledError:
            raise
        except Exception as e:
            self.last_error = str(e)[:300]
            if self.hub:
                await self.hub.broadcast({"type": "log", "level": "warn",
                                          "msg": f"local LLM stream failed: {e}"})
            return None

    async def chat(self, prompt: str, system: str | None = None,
                   timeout: float = 60.0, max_tokens: int = 300) -> str | None:
        """Single-turn chat. Returns None on any failure (caller falls back)."""
        if not self.model:
            return None
        messages: list[dict] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        t0 = time.time()
        try:
            async with httpx.AsyncClient(timeout=timeout, trust_env=False) as c:
                r = await c.post(
                    f"{self.base_url}/chat/completions",
                    headers=self._headers(),
                    json={
                        "model": self.model,
                        "messages": messages,
                        "max_tokens": max_tokens,
                        "temperature": 0.4,
                    },
                )
                r.raise_for_status()
                data = r.json()
            elapsed = time.time() - t0
            self.last_latency_ms = int(elapsed * 1000)
            self.calls_total += 1
            usage = data.get("usage") or {}
            ctoks = usage.get("completion_tokens")
            if ctoks and elapsed > 0:
                self.last_tokens = ctoks
                self.last_tps = round(ctoks / elapsed, 1)
            content = (data.get("choices") or [{}])[0].get("message", {}).get("content")
            content = content or ""
            # strip any reasoning residue (Qwen3 etc. may emit <think>…</think>)
            if "<think>" in content:
                import re as _re
                content = _re.sub(r"<think>.*?</think>", "", content, flags=_re.DOTALL)
            return content.strip() or None
        except Exception as e:
            self.last_error = str(e)[:300]
            self.available = False
            if self.hub:
                await self.hub.broadcast({
                    "type": "log", "level": "warn",
                    "msg": f"local LLM call failed: {e}",
                })
            return None
