import asyncio
import platform
import time

import httpx
import psutil

from hub import Hub
from source_links import safe_url


class SystemMonitor:
    def __init__(self, hub: Hub, interval: float = 2.0) -> None:
        self.hub = hub
        self.interval = interval
        self.latest: dict = {}
        self.disk_path = "C:\\" if platform.system() == "Windows" else "/"

    async def run(self) -> None:
        psutil.cpu_percent(interval=None)
        net_prev = psutil.net_io_counters()
        t_prev = time.time()
        while True:
            await asyncio.sleep(self.interval)
            cpu = psutil.cpu_percent(interval=None)
            mem = psutil.virtual_memory().percent
            try:
                disk = psutil.disk_usage(self.disk_path).percent
            except Exception:
                disk = 0.0
            net = psutil.net_io_counters()
            now = time.time()
            dt = max(now - t_prev, 0.001)
            up = (net.bytes_sent - net_prev.bytes_sent) / dt / 1024
            down = (net.bytes_recv - net_prev.bytes_recv) / dt / 1024
            net_prev, t_prev = net, now
            self.latest = {
                "cpu": cpu,
                "mem": mem,
                "disk": disk,
                "net_up": round(up, 1),
                "net_down": round(down, 1),
            }
            await self.hub.broadcast({"type": "metrics", **self.latest})


class NewsService:
    def __init__(self, api_key: str | None, hub: Hub) -> None:
        self.api_key = api_key
        self.hub = hub
        self.recent: list[dict] = []
        self.source = "none"          # "newsapi" | "open" | "none"
        self.store = None             # corestore.CoreStore: the operator's source selection (open feeds)
        self.last_ok = 0.0

    async def fetch_top(self, country: str = "us", page_size: int = 12) -> list[dict]:
        """NewsAPI when NEWSAPI_KEY is set; otherwise (or if it fails) the
        keyless open feeds in open_news.py. Real headlines only, never mocked."""
        if not self.api_key:
            return await self.fetch_open()
        items = await self._fetch_newsapi(country, page_size)
        return items or await self.fetch_open()

    async def fetch_open(self) -> list[dict]:
        from open_news import fetch_open_news
        prefs = (self.store.data.get("news") or {}) if self.store is not None else {}
        articles, failed = await fetch_open_news(disabled=prefs.get("disabled") or (),
                                                 custom=prefs.get("custom") or ())
        self.source = "open"
        if articles:
            self.recent = articles
            self.last_ok = time.time()          # freshness signal for the self-healing watchdog
            await self.hub.broadcast({"type": "news", "items": articles, "source": "open"})
        if failed:
            await self.hub.broadcast({"type": "log", "level": "warn",
                                      "msg": f"news: {', '.join(failed)} unreachable"})
        return articles

    async def _fetch_newsapi(self, country: str, page_size: int) -> list[dict]:
        url = "https://newsapi.org/v2/top-headlines"
        params = {"country": country, "pageSize": page_size, "apiKey": self.api_key}
        try:
            async with httpx.AsyncClient(timeout=10) as c:
                r = await c.get(url, params=params)
                r.raise_for_status()
                data = r.json()
            articles = [
                {
                    "title": a.get("title"),
                    "source": (a.get("source") or {}).get("name"),
                    "url": safe_url(a.get("url")),
                    "ts": a.get("publishedAt"),
                }
                for a in data.get("articles", [])
                if a.get("title") and a.get("title") != "[Removed]"
            ]
            self.recent = articles
            self.last_ok = time.time()          # freshness signal for the self-healing watchdog
            self.source = "newsapi"
            await self.hub.broadcast({"type": "news", "items": articles, "source": "newsapi"})
            return articles
        except Exception as e:
            await self.hub.broadcast({
                "type": "log", "level": "warn", "msg": f"news fetch failed: {e}",
            })
            return []
