/* ═══════════════════════════════════════════════════════════
   AVENGERS HUD · client controller · STARK INDUSTRIES × BOBBIEY
   ═══════════════════════════════════════════════════════════ */

const $ = (s) => document.querySelector(s);
const escapeHTML = (s) =>
  (s || "").replace(/[&<>"]/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c]));

// ── clock ────────────────────────────────────────────
function tickClock() {
  const d = new Date();
  $("#clock").textContent = d.toTimeString().slice(0, 8);
  $("#clock-date").textContent =
    `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,"0")}.${String(d.getDate()).padStart(2,"0")}`;
}
setInterval(tickClock, 1000); tickClock();

// ── world clocks ─────────────────────────────────────
const WORLD_CLOCKS = [
  { city: "NYC", tz: "America/New_York" },
  { city: "LA",  tz: "America/Los_Angeles" },
  { city: "LON", tz: "Europe/London" },
  { city: "MUM", tz: "Asia/Kolkata" },
  { city: "TOK", tz: "Asia/Tokyo" },
];
function renderWorldClocks() {
  const host = $("#world-clocks"); if (!host) return;
  host.innerHTML = WORLD_CLOCKS.map(c => {
    let t = "--:--";
    try { t = new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: c.tz }); } catch (e) {}
    return `<div class="clock-mini"><div class="clock-mini-city">${c.city}</div><div class="clock-mini-time">${t}</div></div>`;
  }).join("");
}
setInterval(renderWorldClocks, 30000); renderWorldClocks();

// ── ops timer ────────────────────────────────────────
const opsStart = Date.now();
function tickOps() {
  const s = Math.floor((Date.now() - opsStart) / 1000);
  const h = String(Math.floor(s/3600)).padStart(2,"0");
  const m = String(Math.floor((s%3600)/60)).padStart(2,"0");
  const ss = String(s%60).padStart(2,"0");
  const el = $("#ops-timer"); if (el) el.textContent = `${h}:${m}:${ss}`;
}
setInterval(tickOps, 1000); tickOps();

// ── theme switcher ───────────────────────────────────
const themeBtns = document.querySelectorAll(".theme-btn");
themeBtns.forEach(b => b.addEventListener("click", () => {
  const t = b.dataset.theme;
  document.body.classList.remove("theme-jarvis", "theme-stark", "theme-stealth");
  document.body.classList.add("theme-" + t);
  themeBtns.forEach(x => x.classList.toggle("active", x === b));
  try { localStorage.setItem("avengers-theme", t); } catch (e) {}
}));
function applySavedTheme() {
  try {
    const saved = localStorage.getItem("avengers-theme");
    if (saved && /^(jarvis|stark|stealth)$/.test(saved)) {
      document.body.classList.remove("theme-jarvis","theme-stark","theme-stealth");
      document.body.classList.add("theme-" + saved);
      themeBtns.forEach(x => x.classList.toggle("active", x.dataset.theme === saved));
    }
  } catch (e) {}
}
applySavedTheme();
window.addEventListener("storage", (e) => { if (e.key === "avengers-theme") applySavedTheme(); });   // other tabs

// ── status pills ─────────────────────────────────────
function setPill(id, label, level) {
  const el = $(id); if (!el) return;
  el.classList.remove("ok","warn","error");
  if (level) el.classList.add(level);
  const v = el.querySelector(".sp-val");
  if (v) v.textContent = label;
}
async function refreshPills() {
  try {
    const r = await fetch("/api/status");
    const d = await r.json();
    setPill("#sp-brain", (d.brain_mode || "?").toUpperCase(),
            (d.brain_mode === "llm" || d.brain_mode === "local-llm") ? "ok"
            : d.brain_mode === "local" ? "warn" : "error");
    setPill("#sp-tts", d.tts_enabled ? "ON" : "OFF", d.tts_enabled ? "ok" : "error");
    setPill("#sp-news", d.news_count > 0 ? `${d.news_count} ITEMS` : "EMPTY",
            d.news_count > 0 ? "ok" : "warn");
  } catch (e) {}
}

// ── charts ───────────────────────────────────────────
const mkChart = (id, color) => new Chart(document.getElementById(id), {
  type: "line",
  data: { labels: [], datasets: [{ data: [], borderColor: color, backgroundColor: color + "22",
    borderWidth: 1.5, fill: true, tension: 0.32, pointRadius: 0 }] },
  options: {
    responsive: true, maintainAspectRatio: false, animation: false,
    plugins: { legend: { display: false }, tooltip: { enabled: false } },
    scales: { x: { display: false }, y: { min: 0, max: 100, display: false } },
    elements: { line: { borderJoinStyle: "round" } },
  },
});
const cpuChart = mkChart("cpu-chart", "#00d9ff");
const memChart = mkChart("mem-chart", "#ff7a00");
const MAX_POINTS = 60;
function pushChart(ch, val) {
  ch.data.labels.push(""); ch.data.datasets[0].data.push(val);
  if (ch.data.labels.length > MAX_POINTS) { ch.data.labels.shift(); ch.data.datasets[0].data.shift(); }
  ch.update("none");
}

// ── avengers list ────────────────────────────────────
function shortBadge(c) { const w = c.split(/\s+/); return w.length === 1 ? c.slice(0,3) : w.map(s => s[0]).join("").slice(0,3); }
function renderAgents(agents) {
  const list = $("#avengers-list"); list.innerHTML = "";
  for (const a of agents) {
    const card = document.createElement("div");
    card.className = "agent-card"; card.dataset.agent = a.name;
    card.dataset.role = a.role;
    card.tabIndex = 0;
    card.setAttribute("role", "button");
    card.title = `${a.codename} — click for operations file`;
    card.style.setProperty("--agent-color", a.color);
    card.innerHTML = `
      <div class="agent-icon">${shortBadge(a.codename)}</div>
      <div class="agent-meta">
        <div class="agent-name">${a.codename}</div>
        <div class="agent-role">${a.role}</div>
      </div>
      <div class="agent-status">${a.status}</div>`;
    list.appendChild(card);
  }
  $("#agent-count").textContent = `${agents.length} agents online`;
  try { agentsOnline = agents.length; } catch (e) {}
}
function updateAgentStatus(name, status, task) {
  const card = document.querySelector(`.agent-card[data-agent="${name}"]`);
  if (!card) return;
  const el = card.querySelector(".agent-status");
  el.textContent = status; el.className = "agent-status " + status;
  card.classList.toggle("active", status !== "idle");
  // live current-task display: swap the role line while the agent works
  const roleEl = card.querySelector(".agent-role");
  if (roleEl) {
    if (status !== "idle" && task && task !== "—") roleEl.textContent = "▸ " + task;
    else roleEl.textContent = card.dataset.role || roleEl.textContent;
  }
}

// ── event stream ─────────────────────────────────────
function logEvent(html, kind = "info") {
  const ev = $("#event-stream");
  const line = document.createElement("div");
  line.className = "event-line " + kind;
  line.innerHTML = `<span class="ts">${new Date().toTimeString().slice(0,8)}</span>${html}`;
  ev.appendChild(line);
  while (ev.children.length > 200) ev.removeChild(ev.firstChild);
  ev.scrollTop = ev.scrollHeight;
  try { bumpActivity(); } catch (e) {}   // feeds the AI-ops activity heatmap
}

// ── news ─────────────────────────────────────────────
function renderNews(items) {
  const list = $("#news-list"); list.innerHTML = "";
  if (!items.length) { list.innerHTML = '<div class="news-empty">no headlines yet — news sources unreachable, retrying every 10 min</div>'; return; }
  for (const it of items.slice(0, 12)) {
    const div = document.createElement("div");
    div.className = "news-item";
    const age = it.ts ? Math.max(0, Math.round((Date.now() - Date.parse(it.ts)) / 60000)) : null;
    const when = age == null || isNaN(age) ? "" : age < 60 ? ` · ${age}m ago` : ` · ${Math.round(age / 60)}h ago`;
    div.innerHTML = `<div>${escapeHTML(it.title)}</div><div class="src">▸ ${escapeHTML(it.source || "unknown")}${when}</div>`;
    if (/^https?:\/\//.test(it.url || "")) { div.onclick = () => window.open(it.url, "_blank", "noopener"); div.title = "open article"; }
    list.appendChild(div);
  }
}

// ── voice waveform ───────────────────────────────────
class Waveform {
  constructor(canvas) {
    this.c = canvas; this.ctx = canvas.getContext("2d");
    this.state = "idle"; this.t = 0;
    this.amp = 0.08; this.ampCur = 0.08; this.color = "#00d9ff";
    this._size();
    window.addEventListener("resize", () => this._size());
  }
  _size() {
    const dpr = window.devicePixelRatio || 1;
    const rect = this.c.getBoundingClientRect();
    this.cssW = Math.max(rect.width, 60); this.cssH = Math.max(rect.height, 40);
    this.c.width = this.cssW * dpr; this.c.height = this.cssH * dpr;
    this.ctx.setTransform(1,0,0,1,0,0); this.ctx.scale(dpr, dpr);
  }
  setState(state) {
    this.state = state;
    const s = getComputedStyle(document.body);
    if (state === "speaking") { this.amp = 1.0; this.color = s.getPropertyValue("--stark").trim() || "#ff7a00"; }
    else if (state === "listening") { this.amp = 0.55; this.color = "#50fa7b"; }
    else if (state === "processing") { this.amp = 0.32; this.color = "#ffb86c"; }
    else { this.amp = 0.08; this.color = s.getPropertyValue("--accent").trim() || "#00d9ff"; }
  }
  start() { const loop = () => { this.draw(); requestAnimationFrame(loop); }; loop(); }
  draw() {
    this.t += 1; this.ampCur += (this.amp - this.ampCur) * 0.07;
    const ctx = this.ctx, w = this.cssW, h = this.cssH, cy = h/2;
    ctx.clearRect(0,0,w,h);
    ctx.strokeStyle = this.color + "22"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, cy); ctx.lineTo(w, cy); ctx.stroke();
    ctx.shadowColor = this.color;
    for (let layer = 0; layer < 3; layer++) {
      ctx.beginPath();
      const phase = this.t * (0.055 + layer * 0.018);
      const freq  = 0.024 + layer * 0.014;
      const layerAmp = this.ampCur * (h * 0.44) * (1 - layer * 0.28);
      for (let x = 0; x <= w; x += 2) {
        const env = Math.sin(x * 0.04 + phase * 1.4) * 0.45 + Math.sin(x * 0.11 + phase) * 0.55;
        const y = cy + Math.sin(x * freq + phase) * layerAmp * env;
        if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = this.color; ctx.lineWidth = 1.6 - layer * 0.35;
      ctx.globalAlpha = 0.9 - layer * 0.22; ctx.shadowBlur = 7 + layer * 2;
      ctx.stroke();
    }
    ctx.globalAlpha = 1; ctx.shadowBlur = 0;
    if (this.state === "speaking" || this.state === "listening") {
      const px = ((this.t * 2.4) % (w + 40)) - 20;
      ctx.beginPath(); ctx.fillStyle = this.color; ctx.shadowColor = this.color; ctx.shadowBlur = 14;
      ctx.arc(px, cy, 2.2, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
    }
  }
}
const wave = new Waveform(document.getElementById("wave-canvas")); wave.start();

/* ═══ HOLOGRAPHIC EARTH (orb core) ═══════════════════
   Real rotating globe via d3 orthographic projection + world-atlas land —
   actual continents, dark ocean (keeps overlaid text legible), graticule,
   spherical 3D shading, and orbiting satellites. Colour follows --orb-color
   so the globe shifts with the voice state. */
class OrbEarth {
  constructor(canvas) {
    this.c = canvas; this.ctx = canvas.getContext("2d");
    this.t = 0;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.size = canvas.width;                       // logical px (square, 184)
    this.c.width = this.size * this.dpr;
    this.c.height = this.size * this.dpr;
    this.ctx.scale(this.dpr, this.dpr);
    this.R = this.size * 0.40;
    this.land = null;
    this.sats = [0, 2.1, 4.0];
    if (window.d3) {
      this.proj = d3.geoOrthographic()
        .scale(this.R).translate([this.size / 2, this.size / 2]).clipAngle(90);
      this.path = d3.geoPath(this.proj, this.ctx);
      this.grat = d3.geoGraticule10();
      this._load();
    }
  }
  async _load() {
    try {
      const w = await (await fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/land-110m.json")).json();
      this.land = topojson.feature(w, w.objects.land);
    } catch (e) { /* graceful: ocean + graticule still render */ }
  }
  color() {
    return getComputedStyle(document.body).getPropertyValue("--orb-color").trim() || "#00d9ff";
  }
  start() { const loop = () => { this.draw(); requestAnimationFrame(loop); }; loop(); }
  draw() {
    this.t += 1;
    const ctx = this.ctx, s = this.size, col = this.color();
    ctx.clearRect(0, 0, s, s);
    if (!this.proj) return;

    this.proj.rotate([this.t * 0.18, -14]);   // spin W→E with a slight axial tilt

    // ocean disc — dark so the STANDBY label stays readable on top
    ctx.beginPath(); this.path({ type: "Sphere" });
    ctx.fillStyle = "rgba(2,12,22,0.82)"; ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = col;
    ctx.shadowColor = col; ctx.shadowBlur = 9; ctx.globalAlpha = 0.85;
    ctx.stroke(); ctx.shadowBlur = 0; ctx.globalAlpha = 1;

    // graticule
    ctx.beginPath(); this.path(this.grat);
    ctx.strokeStyle = col; ctx.globalAlpha = 0.13; ctx.lineWidth = 0.5;
    ctx.stroke(); ctx.globalAlpha = 1;

    // continents
    if (this.land) {
      ctx.beginPath(); this.path(this.land);
      ctx.fillStyle = col; ctx.globalAlpha = 0.34; ctx.fill();
      ctx.globalAlpha = 0.75; ctx.lineWidth = 0.5; ctx.strokeStyle = col;
      ctx.stroke(); ctx.globalAlpha = 1;
    }

    // spherical 3D shading (lit upper-left, shadowed lower-right)
    ctx.save();
    ctx.beginPath(); this.path({ type: "Sphere" }); ctx.clip();
    const g = ctx.createRadialGradient(s * 0.36, s * 0.34, s * 0.05, s * 0.5, s * 0.5, this.R);
    g.addColorStop(0, "rgba(255,255,255,0.06)");
    g.addColorStop(0.6, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(0,0,0,0.5)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, s, s);
    ctx.restore();

    // Hyderabad HQ ping (only when on the near hemisphere)
    const rot = this.proj.rotate();
    const center = [-rot[0], -rot[1]];
    if (d3.geoDistance([78.49, 17.39], center) < Math.PI / 2) {
      const p = this.proj([78.49, 17.39]);
      const pulse = 1.6 + Math.sin(this.t * 0.1) * 0.7;
      ctx.beginPath(); ctx.arc(p[0], p[1], pulse, 0, Math.PI * 2);
      ctx.fillStyle = col; ctx.shadowColor = col; ctx.shadowBlur = 7;
      ctx.fill(); ctx.shadowBlur = 0;
    }

    // orbiting satellites
    const cx = s / 2, cy = s / 2;
    for (const ph of this.sats) {
      const a = this.t * 0.02 + ph;
      const ox = cx + Math.cos(a) * (this.R + 8);
      const oy = cy + Math.sin(a) * (this.R + 8) * 0.4;
      ctx.beginPath(); ctx.arc(ox, oy, 1.3, 0, Math.PI * 2);
      ctx.fillStyle = col; ctx.shadowColor = col; ctx.shadowBlur = 5;
      ctx.globalAlpha = 0.9; ctx.fill();
      ctx.shadowBlur = 0; ctx.globalAlpha = 1;
    }
  }
}
(() => {
  const el = document.getElementById("orb-earth");
  if (el) { try { new OrbEarth(el).start(); } catch (e) { console.warn("globe:", e); } }
})();

// ── voice state ──────────────────────────────────────
// orb "engaged" glow: BUCS is waiting for the operator's follow-up
var OrbEngage = {
  _t: null,
  on(seconds) {
    const orb = document.getElementById("voice-orb"); if (!orb) return;
    orb.classList.add("engaged"); clearTimeout(this._t);
    this._t = setTimeout(() => orb.classList.remove("engaged"), Math.max(1, seconds || 20) * 1000);
  },
};
// map a mic reading (int16 peak) onto 0..1 on a log scale, smoothed
var OrbMic = { v: 0, set(peak, trigger) {
  const orb = document.getElementById("voice-orb"); if (!orb) return;
  const lo = Math.log10(Math.max(trigger || 150, 100)), hi = Math.log10(12000);
  const x = Math.max(0, Math.min(1, (Math.log10(Math.max(peak, 1)) - lo) / (hi - lo)));
  this.v = x > this.v ? x : this.v * 0.6 + x * 0.4;          // fast attack, gentle release
  orb.style.setProperty("--mic", this.v.toFixed(3));
} };

function setVoiceState(state) {
  const orb = $("#voice-orb"); if (!orb) return;
  orb.classList.remove("listening","speaking","processing");
  if (state !== "idle" && state !== "standby") orb.classList.add(state);
  if (state !== "listening") orb.style.setProperty("--mic", "0");
  $("#voice-label").textContent = state === "idle" ? "STANDBY" : state.toUpperCase();
  wave.setState(state);
  const sub = $("#voice-sublabel");
  if (sub) {
    if (state === "speaking")        sub.textContent = "◉ TRANSMITTING";
    else if (state === "listening")  sub.textContent = "◉ LISTENING";
    else if (state === "processing") sub.textContent = "◉ PROCESSING";
    else                              sub.textContent = "";
  }
}
// ═══ REAL-TIME ENGINE · live command console ═══════════════════
// Renders {"type":"cmd"} events from realtime.py: one row per command with
// stage chips, the streamed reply, timings and a cancel control. `var` +
// method object so WS events that land during load can't hit a TDZ.
var CommandConsole = {
  rows: new Map(), order: [],
  SRC: { voice: "🎙 VOICE", text: "⌨ TEXT", ui: "◉ UI", clap: "👏 CLAP", api: "⇄ API", agent: "◆ AGENT" },
  on(m) {
    if (m.stage === "interrupt") { this.flash("interrupted"); return; }
    if (!m.id) return;
    let r = this.rows.get(m.id);
    if (!r) {
      if (!m.text && m.stage === "received" && m.source !== "clap" && m.source !== "voice") return;
      r = { id: m.id, text: m.text || "(summoned)", source: m.source, agent: m.agent, stages: new Set(), reply: "", marks: {}, final: null };
      this.rows.set(m.id, r); this.order.unshift(m.id);
      while (this.order.length > 6) this.rows.delete(this.order.pop());
    }
    if (m.agent) r.agent = m.agent;
    r.stages.add(m.stage);
    if (m.stage === "handoff") r.handoff = `${m.from} → ${m.to}`;
    if (m.stage === "routed") r.route = m.route === "fast" ? `FAST · ${m.intent || ""}` : "AGENT";
    if (m.stage === "acting" || m.stage === "progress") r.detail = m.detail || r.detail;
    if (m.stage === "delta") r.reply += m.text || "";
    if (["done", "failed", "cancelled"].includes(m.stage)) {
      r.final = m.stage; r.marks = m.marks || {}; r.path = m.path;
      if (m.reply) r.reply = m.reply;
      if (m.error && m.stage !== "cancelled") r.reply = (r.reply ? r.reply + "\n" : "") + "⚠ " + m.error;
    }
    if (typeof JarvisSummon !== "undefined") JarvisSummon.fromCmd(m, r);
    this.render();
  },
  chips(r) {
    const has = s => r.stages.has(s);
    const c = (on, label, cls = "") => `<span class="cmd-chip ${on ? "on " + cls : ""}">${label}</span>`;
    return [c(has("ack"), "ACK"), c(has("routed"), r.route || "ROUTE"),
      r.handoff ? c(true, escapeHTML(r.handoff.toUpperCase()), "hand") : "",
      c(has("thinking") || has("acting"), has("acting") ? "ACT" : "THINK"),
      c(has("delta") || !!r.reply, "RESPOND"),
      r.final ? c(true, r.final.toUpperCase(), r.final === "done" ? "ok" : "bad") : ""].join("");
  },
  timing(r) {
    const k = r.marks || {}; const f = v => v == null ? null : v < 1000 ? `${Math.round(v)} ms` : `${(v / 1000).toFixed(1)} s`;
    return [k.ack_ms != null ? `ack ${f(k.ack_ms)}` : "", k.first_token_ms != null ? `1st token ${f(k.first_token_ms)}` : "",
      k.first_speech_ms != null ? `1st voice ${f(k.first_speech_ms)}` : "", k.total_ms != null ? `total ${f(k.total_ms)}` : "",
      r.path ? r.path.toUpperCase() : ""].filter(Boolean).join(" · ");
  },
  render() {
    const host = document.getElementById("cmd-list"); if (!host) return;
    if (!this.order.length) return;
    host.innerHTML = this.order.map(id => {
      const r = this.rows.get(id); const live = !r.final;
      return `<div class="cmd-row ${live ? "live" : r.final}" data-id="${r.id}">
        <div class="cmd-q"><span class="cmd-src">${this.SRC[r.source] || r.source}</span>
          <span class="cmd-q-txt" title="${escapeHTML(r.text)}">${escapeHTML(r.text)}</span>
          ${r.agent ? `<span class="cmd-src">${escapeHTML(String(r.agent).toUpperCase())}</span>` : ""}
          ${live ? `<button class="cmd-x" data-cancel="${r.id}" aria-label="cancel command">×</button>` : ""}</div>
        <div class="cmd-stages">${this.chips(r)}</div>
        ${r.reply || r.detail ? `<div class="cmd-a">${escapeHTML(r.reply || r.detail || "")}</div>` : ""}
        ${r.final ? `<div class="cmd-t">${this.timing(r)}</div>` : ""}
      </div>`;
    }).join("");
    const stop = document.getElementById("cmd-stop-all");
    if (stop) stop.hidden = ![...this.rows.values()].some(r => !r.final);
  },
  flash(what) { const t = document.getElementById("cmd-lat"); if (t) { t.textContent = `■ ${what.toUpperCase()}`; setTimeout(() => this.refreshLatency(), 2500); } },
  async refreshLatency() {
    try {
      const d = await (await fetch("/api/engine")).json(); const L = d.latency || {};
      const f = v => v == null ? "—" : v < 1000 ? `${Math.round(v)}ms` : `${(v / 1000).toFixed(1)}s`;
      const parts = ["fast", "claude", "local-llm", "template"].filter(p => L[p]).map(p => `${p.toUpperCase()} ${f(L[p].p50_ms)}`);
      if (d.first_speech_p50_ms != null) parts.push(`1ST VOICE ${f(d.first_speech_p50_ms)}`);
      const el = document.getElementById("cmd-lat");
      if (el) el.textContent = parts.length ? "p50 · " + parts.join(" · ") : `${d.totals?.commands || 0} commands · no timings yet`;
    } catch (e) {}
  },
  async cancel(id) { try { await fetch("/api/command/cancel", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id }) }); } catch (e) {} },
};
document.addEventListener("click", e => {
  const id = e.target && e.target.dataset && e.target.dataset.cancel;
  if (id) CommandConsole.cancel(id);
  if (e.target && e.target.id === "cmd-stop-all") CommandConsole.cancel(null);
});
document.addEventListener("keydown", e => {
  const modalOpen = document.getElementById("tool-modal") && !document.getElementById("tool-modal").hidden;
  if (e.key === "Escape" && !modalOpen && [...CommandConsole.rows.values()].some(r => !r.final)) CommandConsole.cancel(null);
});
setTimeout(() => CommandConsole.refreshLatency(), 3000); setInterval(() => CommandConsole.refreshLatency(), 15000);

// ═══ CONVERSATION MODE · one agent, no wake word, quiet background ═══
var ConversationMode = {
  set(on) {
    const b = document.getElementById("conv-toggle"); if (!b) return;
    b.setAttribute("aria-pressed", on ? "true" : "false");
    const st = on ? "ON" : "OFF";
    b.innerHTML = `<span class="cv-full">CONVERSATION · ${st}</span><span class="cv-short">CONV · ${st}</span>`;
    const sub = document.getElementById("voice-sublabel");
    if (sub) sub.textContent = on ? 'say "jarvis…", then just talk' : "";
  },
  async load() { try { this.set((await (await fetch("/api/conversation")).json()).on); } catch (e) {} },
  async toggle() {
    const b = document.getElementById("conv-toggle"); const on = b.getAttribute("aria-pressed") !== "true";
    this.set(on);
    try { this.set((await (await fetch("/api/conversation", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ on }) })).json()).on); }
    catch (e) { logEvent(`<span class="tag">[voice]</span> conversation mode not changed: ${escapeHTML(e.message)}`, "warn"); return this.load(); }
    logEvent(`<span class="tag">[voice]</span> conversation mode ${on ? "ON — just talk to JARVIS; background voices muted (still shown here)" : "OFF — wake words + all agent voices"}`);
  },
};
document.addEventListener("click", e => { if (e.target && e.target.closest && e.target.closest("#conv-toggle")) ConversationMode.toggle(); });
setTimeout(() => ConversationMode.load(), 500);


// ═══ JARVIS · ENGINEERING panel (devagent.py events: {"type":"dev"}) ═══
var DevPanel = {
  el: id => document.getElementById(id),
  open() { const p = this.el("dev-panel"); if (p) p.hidden = false; },
  close() { const p = this.el("dev-panel"); if (p) p.hidden = true; },
  stage(t, ok) { const s = this.el("dev-stage"); if (s) { s.textContent = t; s.className = "dev-stage" + (ok ? " ok" : ""); } },
  actions(list) {
    const a = this.el("dev-actions"); if (!a) return;
    a.innerHTML = list.map(([id, label]) => `<button class="cmd-btn" data-dev="${id}">${label}</button>`).join("");
  },
  on(m) {
    if (m.type === "dev-open") { this.open(); return; }
    this.open();
    if (m.stage === "diagnosing") {
      this.el("dev-req").textContent = `“${m.request}”`; this.el("dev-out").textContent = "";
      this.el("dev-tools").innerHTML = ""; this.el("dev-result").innerHTML = ""; this.actions([]);
      this.stage("DIAGNOSING · READ-ONLY");
    }
    if (m.stage === "tool") {
      const t = this.el("dev-tools"); const line = document.createElement("div");
      line.textContent = `${m.tool === "Read" ? "reading" : m.tool === "Grep" ? "searching" : m.tool === "Glob" ? "listing" : m.tool === "Edit" || m.tool === "Write" ? "editing" : m.tool} ${m.target || ""}`;
      t.prepend(line);
    }
    if (m.stage === "delta") { const o = this.el("dev-out"); o.textContent += m.text; o.scrollTop = o.scrollHeight; }
    if (m.stage === "proposed" || m.stage === "diagnosed") {
      this.el("dev-out").textContent = m.plan || this.el("dev-out").textContent;
      this.stage(m.stage === "proposed" ? "FIX PROPOSED · AWAITING YOUR OK" : "DIAGNOSED", m.stage !== "proposed");
      this.actions(m.fixable ? [["apply", "✓ APPLY FIX"], ["dismiss", "DISMISS"]] : [["dismiss", "CLOSE"]]);
    }
    if (m.stage === "applying") { this.stage("APPLYING · NO SHELL ACCESS"); this.actions([]); this.el("dev-tools").innerHTML = ""; }
    if (m.stage === "testing") this.stage("RUNNING TESTS");
    if (m.stage === "applied") {
      const ok = m.tests && m.tests.ok;
      this.stage(ok ? "APPLIED · TESTS PASS" : "APPLIED · TESTS FAILING", ok);
      this.el("dev-result").innerHTML = `<div>Changed: ${(m.changed || []).map(escapeHTML).join(", ") || "nothing"}</div>`
        + `<div class="${ok ? "good" : "bad"}">Tests: ${escapeHTML((m.tests && m.tests.summary) || "")}</div>`
        + (m.restored && m.restored.length ? `<div class="bad">Protected files touched and restored: ${m.restored.map(escapeHTML).join(", ")}</div>` : "")
        + (m.diffstat ? `<div>${escapeHTML(m.diffstat)}</div>` : "")
        + `<div>Front-end changes show after a reload; back-end changes after restarting BUCS.</div>`;
      this.actions(ok ? [["keep", "KEEP"], ["undo", "UNDO"], ["ship", "⇪ SHIP (commit + push)"], ["reload", "↻ RELOAD DASHBOARD"]]
                      : [["undo", "UNDO"], ["keep", "KEEP ANYWAY"]]);
    }
    if (m.stage === "undone") { this.stage("UNDONE", true); this.el("dev-result").textContent = `Reverted: ${(m.reverted || []).join(", ") || "nothing"}`; this.actions([["dismiss", "CLOSE"]]); }
    if (m.stage === "kept") { this.stage("KEPT", true); this.actions([["reload", "↻ RELOAD DASHBOARD"], ["dismiss", "CLOSE"]]); }
    if (m.stage === "shipped") { this.stage(m.pushed ? `SHIPPED · ${m.commit}` : `COMMITTED ${m.commit} · PUSH FAILED`, m.pushed); this.actions([["reload", "↻ RELOAD DASHBOARD"], ["dismiss", "CLOSE"]]); }
  },
  async act(id) {
    if (id === "dismiss") return this.close();
    if (id === "reload") return location.reload();
    this.actions([]);
    const r = await (await fetch(`/api/dev/${id}`, { method: "POST" })).json();
    if (r && r.ok === false) { this.el("dev-result").innerHTML = `<div class="bad">${escapeHTML(r.error || "failed")}</div>`; }
  },
};
document.addEventListener("click", e => {
  const d = e.target && e.target.dataset && e.target.dataset.dev; if (d) DevPanel.act(d);
  if (e.target && e.target.id === "dev-close") DevPanel.close();
});
document.addEventListener("submit", async e => {
  if (!e.target || e.target.id !== "dev-ask") return;
  e.preventDefault(); const i = document.getElementById("dev-input"); const t = i.value.trim(); if (!t) return; i.value = "";
  await fetch("/api/dev/diagnose", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ request: t }) });
});

// ═══ 3D card depth — tilt toward the pointer (±5°), rAF-throttled ═══
// Skipped on touch / coarse pointers and with prefers-reduced-motion. Only
// `transform` changes, so layout, hit-testing and clicks are unaffected.
var Tilt3D = {
  SEL: ".tool-card, .agent-card, .bs-card",
  on: !matchMedia("(pointer: coarse)").matches && !matchMedia("(prefers-reduced-motion: reduce)").matches,
  cur: null, raf: 0,
  move(e) {
    if (!this.on) return;
    const el = e.target.closest && e.target.closest(this.SEL);
    if (el !== this.cur) { this.reset(); this.cur = el; if (el) el.classList.add("tilt-3d", "tilting"); }
    if (!el || this.raf) return;
    this.raf = requestAnimationFrame(() => {
      this.raf = 0; if (!this.cur) return;
      const r = this.cur.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
      const lift = this.cur.classList.contains("bs-card") ? " translateY(-2px)" : "";
      this.cur.style.transform = `perspective(700px) rotateX(${(-y * 8).toFixed(2)}deg) rotateY(${(x * 10).toFixed(2)}deg)${lift}`;
    });
  },
  reset() { if (this.cur) { this.cur.style.transform = ""; this.cur.classList.remove("tilting"); } this.cur = null; },
};
document.addEventListener("pointermove", e => Tilt3D.move(e), { passive: true });
document.addEventListener("pointerleave", () => Tilt3D.reset());

// ═══ COMMANDER PROFILE · long-form private memory (commander_memory.py) ═══
var CommanderProfile = {
  fmt(d) { return d && d.chars ? `${d.chars.toLocaleString()} chars · ${d.sections} sections${d.updated ? " · " + new Date(d.updated * 1000).toLocaleDateString("en-GB", { day: "2-digit", month: "short" }) : ""}` : "not set"; },
  async refresh() {
    try { const d = await (await fetch("/api/memory/profile")).json(); const m = document.getElementById("cp-meta");
      if (m) { m.textContent = this.fmt(d); m.classList.toggle("set", !!d.chars); } return d; } catch (e) { return null; }
  },
  async open(prefill) {
    const modal = document.getElementById("tool-modal"); if (!modal) return;
    let current = "";
    try { current = (await (await fetch("/api/memory/profile/text")).json()).content || ""; } catch (e) {}
    document.getElementById("modal-title").textContent = "COMMANDER PROFILE";
    document.getElementById("modal-sub").textContent = "PRIVATE · STORED ONLY ON THIS MACHINE · NEVER COMMITTED";
    document.getElementById("modal-icon").textContent = "◆";
    document.getElementById("modal-body").innerHTML = `
      <textarea class="cp-editor" id="cp-text" spellcheck="false" placeholder="Paste your full profile / memory protocol here (Markdown or plain text, up to 300,000 characters). JARVIS splits it into sections and uses the relevant ones in every answer."></textarea>
      <div class="cp-row"><span id="cp-count">0 chars</span>
        <label><input type="radio" name="cp-mode" value="replace" checked> replace</label>
        <label><input type="radio" name="cp-mode" value="append"> append</label>
        <button class="cmd-btn" id="cp-save">SAVE PROFILE</button>
        <button class="cmd-btn" id="cp-clear" title="delete the stored profile">CLEAR</button></div>
      <div class="gs-status" id="cp-status" aria-live="polite"></div>
      <div class="cp-titles" id="cp-titles"></div>`;
    modal.hidden = false;
    const ta = document.getElementById("cp-text"), cnt = document.getElementById("cp-count");
    ta.value = prefill != null ? prefill : current;
    const upd = () => { cnt.textContent = `${ta.value.length.toLocaleString()} chars`; }; upd(); ta.addEventListener("input", upd);
    if (prefill != null) document.querySelector('input[name="cp-mode"][value="replace"]').checked = true;
    document.getElementById("cp-save").addEventListener("click", () => this.save(ta.value, document.querySelector('input[name="cp-mode"]:checked').value));
    document.getElementById("cp-clear").addEventListener("click", async () => {
      if (!confirm("Delete the stored commander profile? (Facts and observations are kept.)")) return;
      await fetch("/api/memory/profile/clear", { method: "POST" }); ta.value = ""; upd(); this.status("profile cleared", ""); this.refresh();
    });
    this.titles(await this.refresh());
  },
  status(t, cls) { const s = document.getElementById("cp-status"); if (s) { s.textContent = t; s.className = "gs-status " + (cls || ""); } },
  titles(d) { const el = document.getElementById("cp-titles"); if (el && d && d.titles && d.titles.length) el.textContent = "SECTIONS · " + d.titles.join(" · "); },
  async save(content, mode) {
    this.status("saving…");
    const d = await (await fetch("/api/memory/profile", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ content, mode }) })).json();
    if (!d.ok) return this.status("✗ " + (d.error || "not saved"), "bad");
    this.status(`✓ saved — ${d.chars.toLocaleString()} chars in ${d.sections} sections. Every agent now uses the relevant parts.`, "ok");
    this.titles(d); this.refresh();
    logEvent(`<span class="tag">[memory]</span> commander profile ${mode === "append" ? "extended" : "saved"} · ${d.sections} sections`);
  },
  async upload(f) {
    if (!f) return;
    if (f.size > 1200000) { alert("That file is too large for a profile (limit ~300,000 characters)."); return; }
    this.open(await f.text());
  },
};
document.addEventListener("click", e => { if (e.target && e.target.id === "cp-edit") CommanderProfile.open(); });
document.addEventListener("change", e => { if (e.target && e.target.id === "cp-file") { CommanderProfile.upload(e.target.files[0]); e.target.value = ""; } });
setTimeout(() => CommanderProfile.refresh(), 1200);

// JARVIS summon card — opened by a double clap, shows what was heard and the
// reply, closes itself after 20 s of quiet. Function declaration object built
// lazily so early WS messages can't hit a TDZ.
var JarvisSummon = {
  _t: null,
  el(id) { return document.getElementById(id); },
  open() {
    const c = this.el("jarvis-summon"); if (!c) return;
    c.hidden = false; c.classList.remove("speaking");
    this.state("LISTENING");
    this.el("js-heard").textContent = "Speak now — no wake word needed.";
    this.el("js-reply").textContent = "";
    this.touch();
  },
  active() { const c = this.el("jarvis-summon"); return c && !c.hidden; },
  state(s) { const e = this.el("js-state"); if (e && this.active()) e.textContent = s; },
  heard(t) { if (!this.active() || !t) return; this.el("js-heard").textContent = `“${t}”`; this.touch(); },
  reply(t) { if (!this.active()) return; this.el("js-reply").textContent = t; this.state("ANSWERED"); this.touch(); },
  speaking(on) { const c = this.el("jarvis-summon"); if (c && this.active()) { c.classList.toggle("speaking", on); if (on) this.state("SPEAKING"); this.touch(); } },
  touch() { clearTimeout(this._t); this._t = setTimeout(() => this.close(), 20000); },
  // live pipeline → card: show routing/handoff, stream the reply as it arrives
  fromCmd(m, r) {
    if (!this.active() || !(r.source === "voice" || r.source === "clap")) return;
    if (m.stage === "routed" && m.route === "agent") this.state(`→ ${String(m.agent || "").toUpperCase()}`);
    if (m.stage === "handoff") this.state(`HANDOFF → ${String(m.to || "").toUpperCase()}`);
    if (m.stage === "thinking") this.state("THINKING");
    if (m.stage === "acting") this.state("ACTING");
    if (m.stage === "delta") { this.el("js-reply").textContent = r.reply; this.state("RESPONDING"); this.touch(); }
    if (m.stage === "done" && r.text && r.text !== "(summoned)") { this.el("js-heard").textContent = `“${r.text}”`; this.reply(r.reply); }
    if (m.stage === "cancelled") this.state("STOPPED");
  },
  close() { const c = this.el("jarvis-summon"); if (c) c.hidden = true; clearTimeout(this._t); },
};
document.addEventListener("click", e => { if (e.target && e.target.id === "js-close") JarvisSummon.close(); });

// Vision Digest — server-held (GET /api/digest) + live {"type":"digest"} updates
function renderDigest(d) {
  const el = document.getElementById("digest"); if (!el || !d || !d.msg) return;
  const when = d.ts ? new Date(d.ts * 1000).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }) : "";
  el.innerHTML = `<div class="digest-meta">${d.kind === "briefing" ? "EXECUTIVE BRIEFING" : "VISION SYNTHESIS"}${when ? " · " + when : ""}</div>`
    + d.msg.split("\n").map(l => `<div class="digest-line">${escapeHTML(l)}</div>`).join("");
}
setTimeout(async () => { try { renderDigest(await (await fetch("/api/digest")).json()); } catch (e) {} }, 1500);

function setHeard(text, routeLabel) {
  const t = $("#heard-text"); const r = $("#heard-route");
  if (text) { t.classList.remove("empty"); t.textContent = text; }
  if (r) r.textContent = routeLabel || "";
}

/* ═══ WORLD MAP ═══════════════════════════════════════
   The GLOBAL ACTIVITY MAP panel (#globalmap-mount) is owned by static/globalmap.js,
   which replaces its contents and exposes window.GlobalMap.focus({lat, lon, id, layer}).
   app.js no longer draws into #world-map (the old fixed "NEW YORK / LONDON / TOKYO…"
   arcs were decoration, not activity). Only the projection helpers stay for the side maps. */

let mapProjection = null;
let worldFeatures = null;          // read by disaster.js as a coastline fallback

function fallbackProjection(lat, lon, w = 1000, h = 460) {
  return [(lon + 180) * w / 360, (90 - lat) * h / 180];
}
function projectCity(c) {
  if (mapProjection) { try { return mapProjection([c.lon, c.lat]); } catch (e) {} }
  return fallbackProjection(c.lat, c.lon);
}
async function renderRealWorldMap() {
  // side panels only (India + Telangana, official boundaries from static/geo)
  try { renderIndiaMap(); } catch (e) { console.warn("india map", e); }
  try { renderTelanganaMap(); } catch (e) { console.warn("telangana map", e); }
}

/* Focus the global map on a point. Feature-detected: when globalmap.js has not
   loaded (or has no focus()), scroll to the panel and say so instead of failing. */
function bucsShowOnMap(pt) {
  if (!pt || pt.lat == null || pt.lon == null) return false;
  const panel = document.getElementById("globalmap-mount");
  try { panel?.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (e) {}
  const gm = window.GlobalMap;
  if (gm && typeof gm.focus === "function") {
    try { gm.focus({ lat: +pt.lat, lon: +pt.lon, id: pt.id, layer: pt.layer }); return true; }
    catch (e) { console.warn("GlobalMap.focus failed", e); }
  }
  try { logEvent(`<span class="tag">[map]</span> ${escapeHTML(pt.label || "location")} · ${(+pt.lat).toFixed(2)}, ${(+pt.lon).toFixed(2)} (global map not loaded yet)`, "warn"); } catch (e) {}
  return false;
}
window.bucsShowOnMap = bucsShowOnMap;

/* ═══ INDIA MAP ═══════════════════════════════════════ */

const INDIA_CITIES = [
  { name: "DELHI",     lat: 28.61, lon: 77.21 },
  { name: "MUMBAI",    lat: 19.07, lon: 72.87 },
  { name: "KOLKATA",   lat: 22.57, lon: 88.36 },
  { name: "CHENNAI",   lat: 13.08, lon: 80.27 },
  { name: "BENGALURU", lat: 12.97, lon: 77.59 },
  { name: "HYDERABAD", lat: 17.385, lon: 78.4867, primary: true },
];
let indiaProjection = null;
let tsProjection = null;

/* Accurate India (official boundary, 28 states + 8 UTs) and Telangana
   (33 districts), pre-projected into each panel's viewBox — static/geo/india_ts.json
   (datta07/INDIAN-SHAPEFILES, MIT). "proj" maps lon/lat into the same space so
   city markers sit exactly on the outlines. */
let GEO_MAPS = null;
const geoReady = fetch("/static/geo/india_ts.json").then(r => r.ok ? r.json() : null)
  .then(d => { GEO_MAPS = d; renderIndiaMap(); renderTelanganaMap(); }).catch(() => {});

function mercProj(p) {
  return ([lon, lat]) => {
    const l = lon * Math.PI / 180, f = lat * Math.PI / 180;
    return [p.k * l + p.tx, -p.k * Math.log(Math.tan(Math.PI / 4 + f / 2)) + p.ty];
  };
}
// the source still splits Warangal the pre-2021 way; show today's district names
const TS_RENAME = { "Warangal Urban": "Hanumakonda", "Warangal Rural": "Warangal" };
const svgEl = (tag, attrs) => {
  const e = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  return e;
};

function renderIndiaMap() {
  const host = document.getElementById("india-shape");
  const statesHost = document.getElementById("india-states");
  const citiesHost = document.getElementById("india-cities");
  const arcsHost = document.getElementById("india-arcs");
  if (!host) return;

  // Until the geo file loads, keep the inline fallback outline.
  if (GEO_MAPS && GEO_MAPS.india) {
    indiaProjection = mercProj(GEO_MAPS.india.proj);
    host.innerHTML = "";
    host.appendChild(svgEl("path", { d: GEO_MAPS.india.outline }));
    if (statesHost) {
      statesHost.innerHTML = "";
      for (const s of GEO_MAPS.india.states) {
        const p = svgEl("path", { d: s.d });
        const t = svgEl("title", {}); t.textContent = s.name; p.appendChild(t);
        statesHost.appendChild(p);
      }
    }
  } else {
    indiaProjection = null;
  }

  renderTelanganaHighlightOnIndia();

  if (citiesHost) {
    citiesHost.innerHTML = "";
    for (const c of INDIA_CITIES) {
      const [x, y] = indiaProjection ? indiaProjection([c.lon, c.lat]) : indiaFallbackProject(c.lat, c.lon);
      const r = c.primary ? 3.5 : 2.6;
      const g = svgEl("g", { class: "region-marker" + (c.primary ? " primary" : ""), "data-lat": c.lat, "data-lon": c.lon, "data-name": c.name });
      g.innerHTML = `
        <circle cx="${x}" cy="${y}" r="${r}" class="city-dot"/>
        ${c.primary ? `<circle cx="${x}" cy="${y}" r="${r + 1.5}" class="city-ping"/>` : ""}
        <text x="${x + 6}" y="${y + 2}" class="city-label">${c.name}</text>
        <title>${c.name} · ${c.lat.toFixed(2)}, ${c.lon.toFixed(2)} · click to show on the global map</title>`;
      citiesHost.appendChild(g);
    }
  }

  // (no HQ→city arcs: they suggested a live network that does not exist)
  if (arcsHost) arcsHost.innerHTML = "";
}

function indiaFallbackProject(lat, lon) {
  // pre-load fallback only (matches the inline hand-traced path)
  const x = (lon - 68.5) * (160 / 28.5) + 20;
  const y = 240 - ((lat - 8) * (200 / 29) + 20);
  return [x, y];
}

function renderTelanganaHighlightOnIndia() {
  const host = document.getElementById("india-ts-highlight");
  if (!host) return;
  const ts = GEO_MAPS && GEO_MAPS.india && GEO_MAPS.india.states.find(s => s.name === "Telangana");
  host.innerHTML = ts ? `<path d="${ts.d}"><title>Telangana</title></path>` : "";
}

/* ═══ TELANGANA — 33 districts + Hyderabad pin ═══ */

const TS_CITIES = [
  { name: "HYDERABAD",  lat: 17.385, lon: 78.4867, primary: true },
  { name: "WARANGAL",   lat: 18.00,  lon: 79.58 },
  { name: "NIZAMABAD",  lat: 18.67,  lon: 78.10 },
  { name: "KARIMNAGAR", lat: 18.43,  lon: 79.13 },
  { name: "KHAMMAM",    lat: 17.25,  lon: 80.15 },
];
function renderTelanganaMap() {
  const shape = document.getElementById("ts-shape");
  const distHost = document.getElementById("ts-districts");
  if (!GEO_MAPS || !GEO_MAPS.telangana) return;            // inline fallback until the file loads
  const T = GEO_MAPS.telangana;
  tsProjection = mercProj(T.proj);
  if (shape) shape.setAttribute("d", T.outline);
  if (distHost) {
    distHost.innerHTML = "";
    for (const d of T.districts) {
      const p = svgEl("path", { d: d.d });
      const t = svgEl("title", {}); t.textContent = TS_RENAME[d.name] || d.name; p.appendChild(t);
      distHost.appendChild(p);
    }
  }
  const citiesHost = document.getElementById("ts-cities");
  if (!citiesHost) return;
  citiesHost.innerHTML = "";
  for (const c of TS_CITIES) {
    const [x, y] = tsProjection([c.lon, c.lat]);
    const r = c.primary ? 4 : 2.5;
    const g = svgEl("g", { class: "region-marker" + (c.primary ? " primary" : ""), "data-lat": c.lat, "data-lon": c.lon, "data-name": c.name });
    g.innerHTML = `
      <circle cx="${x}" cy="${y}" r="${r}" class="city-dot"/>
      ${c.primary ? `<circle cx="${x}" cy="${y}" r="${r + 2}" class="city-ping"/>` : ""}
      <text x="${x + 6}" y="${y + 2}" class="city-label">${c.name}</text>
      <title>${c.name} · click to show on the global map</title>`;
    citiesHost.appendChild(g);
  }
}

renderRealWorldMap();

// ── weather ──────────────────────────────────────────
let userLat = null, userLon = null;
let weatherCity = "HYDERABAD";
// module-scope live-data stashes — declared HERE (early) so functions called
// during load (refreshWeather via initGeo, etc.) never hit a temporal-dead-zone
// ReferenceError, which would halt all remaining top-level init.
let lastAgenda = null, lastThreat = null, lastMemorySnap = null, lastWeatherOk = null;

function setWeatherState(state, message) {
  const card = $("#weather-card"); if (!card) return;
  card.classList.remove("loading", "error");
  if (state) card.classList.add(state);
  if (message != null) $("#weather-label").textContent = message;
}

let _weatherBusy = false, _weatherQueued = false;
async function refreshWeather(force = false) {
  if (_weatherBusy) { _weatherQueued = true; return; }   // one at a time; a newer location re-runs after
  _weatherBusy = true;
  try { await _refreshWeather(force); } finally {
    _weatherBusy = false;
    if (_weatherQueued) { _weatherQueued = false; refreshWeather(true); }
  }
}
async function _refreshWeather(force = false) {
  setWeatherState("loading", "acquiring signal…");
  $("#weather-update").textContent = "FETCHING…";
  try {
    let url = "/api/weather";
    if (userLat != null && userLon != null) {
      url += `?lat=${userLat.toFixed(4)}&lon=${userLon.toFixed(4)}`;
    }
    const ctl = new AbortController();
    const timeout = setTimeout(() => ctl.abort(), 15000);   // server gives up at ~8 s, so this never fires first
    const r = await fetch(url, { signal: ctl.signal, cache: force ? "no-store" : "default" });
    clearTimeout(timeout);
    const d = await r.json();
    if (!d || d.error) {
      lastWeatherOk = false;
      setWeatherState("error", "unavailable");
      $("#weather-update").textContent = "ERR · " + new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false });
      return;
    }
    lastWeatherOk = true;
    setWeatherState(null, (d.label || "").toUpperCase() || "—");
    $("#weather-glyph").textContent = d.glyph || "◐";
    $("#weather-temp").textContent  = d.temp_c != null ? Math.round(d.temp_c) : "--";
    $("#weather-humid").textContent = d.humidity ?? "--";
    $("#weather-wind").textContent  = d.wind_kmh != null ? Math.round(d.wind_kmh) : "--";
    $("#weather-feels").textContent = d.feels_c != null ? Math.round(d.feels_c) : "--";
    $("#weather-update").textContent = (d.stale ? "CACHED · " : "OK · ") + new Date((d.fetched_at || Date.now() / 1000) * 1000).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false });
    const hg = $("#hw-glyph"); if (hg) hg.textContent = d.glyph || "◐";        // header readout removed (v8); guarded
    const ht = $("#hw-temp"); if (ht) ht.textContent = d.temp_c != null ? `${Math.round(d.temp_c)}°` : "--°";
    if (d.city) {
      $("#weather-city").textContent = `${(weatherCity || d.city || "").toUpperCase()} · WEATHER`;
    }
  } catch (e) {
    setWeatherState("error", e.name === "AbortError" ? "timeout" : "fetch failed");
    $("#weather-update").textContent = "ERR";
    console.warn("weather fetch failed:", e);
  }
}
refreshWeather();
setInterval(() => refreshWeather(false), 5 * 60 * 1000);   // refresh every 5 min
$("#weather-refresh")?.addEventListener("click", () => refreshWeather(true));

// ── connectivity ─────────────────────────────────────
async function refreshConnectivity() {
  try {
    const r = await fetch("/api/connectivity"); const d = await r.json();
    const wifi = d.wifi || {};
    const link = d.link || null;
    const wifiRow = $("#conn-wifi"); const wifiVal = $("#wifi-val");
    const linkLabel = $("#conn-link-label");
    if (wifi.connected) {                          // on WiFi
      if (linkLabel) linkLabel.textContent = "WIFI";
      wifiVal.textContent = `${wifi.ssid || "WIFI"} · ${wifi.signal || "—"}`;
      wifiRow.classList.remove("bad"); wifiRow.classList.add("ok");
    } else if (link && link.up) {                  // WiFi down but wired/other uplink is live
      if (linkLabel) linkLabel.textContent = link.type === "wifi" ? "WIFI" : "ETHERNET";
      const spd = link.speed_mbps ? ` · ${link.speed_mbps} Mbps` : "";
      wifiVal.textContent = `${link.name.slice(0, 14)}${spd}`;
      wifiRow.classList.remove("bad"); wifiRow.classList.add("ok");
    } else {                                        // genuinely offline
      if (linkLabel) linkLabel.textContent = "LINK";
      wifiVal.textContent = "offline";
      wifiRow.classList.remove("ok"); wifiRow.classList.add("bad");
    }
    const ble = d.bluetooth || {};
    $("#ble-val").textContent = ble.count == null ? "n/a" : (ble.count ? `${ble.count} paired` : "none");
    $("#conn-ble").classList.toggle("ok", ble.count > 0);

    const p = d.ping_ms ?? -1;
    // orb flank: real link latency + probe loss
    const fv = $("#fl-vector"); if (fv) fv.textContent = fmtLatency(p);
    // packet loss comes from the rolling probe window (d.net), not one ping
    const loss = d.net && d.net.loss_pct != null ? d.net.loss_pct : null;
    const fp = $("#fl-pkt"); if (fp) fp.textContent = loss != null ? `${loss}%` : (p >= 0 ? "—" : "100%");
    const pingRow = $("#conn-net");
    if (p < 0)        { $("#ping-val").textContent = "—";       pingRow.classList.add("bad");  pingRow.classList.remove("ok","warn"); }
    else if (p < 100) { $("#ping-val").textContent = `${p} ms`; pingRow.classList.add("ok");   pingRow.classList.remove("warn","bad"); }
    else if (p < 300) { $("#ping-val").textContent = `${p} ms`; pingRow.classList.add("warn"); pingRow.classList.remove("ok","bad"); }
    else              { $("#ping-val").textContent = `${p} ms`; pingRow.classList.add("bad");  pingRow.classList.remove("ok","warn"); }

    if (d.net) applyNetSnapshot(d.net);
  } catch (e) {}
}
refreshConnectivity(); setInterval(refreshConnectivity, 30000);

// ── battery (real, from server psutil — browser getBattery is dead in Chrome) ─
async function refreshBattery() {
  try {
    const d = await (await fetch("/api/hardware")).json();
    const p = d.power || {};
    const row = $("#conn-bat"); const val = $("#bat-val");
    if (!row || !val) return;
    row.classList.remove("ok", "warn", "bad");
    if (!p.present) { val.textContent = "AC POWER ⚡"; row.classList.add("ok"); return; }
    const pct = p.percent;
    val.textContent = `${pct}%${p.plugged ? " ⚡" : ""}`;
    if (pct > 30 || p.plugged) row.classList.add("ok");
    else if (pct > 15) row.classList.add("warn");
    else row.classList.add("bad");
  } catch (e) {}
}
refreshBattery(); setInterval(refreshBattery, 30000);

// ── location: real IP geolocation baseline, refined by precise GPS ───
function updateLocation(text, coords) {
  if (text) $("#location-value").textContent = text;
  if (coords) $("#location-coords").textContent = coords;
}
// live network truth (netspeed.py): measured internet speed beats the Wi-Fi
// PHY rate, which is only the radio link and not what the internet delivers
function applyNetSnapshot(n) {
  if (!n) return;
  const fv = $("#fl-vector"); if (fv && n.latency_ms != null) fv.textContent = fmtLatency(n.latency_ms);
  const fp = $("#fl-pkt"); if (fp && n.loss_pct != null) fp.textContent = `${n.loss_pct}%`;
  const tc = $("#tc-net"); const sp = n.speed;
  if (tc && sp && sp.ok) {
    window._netSpeedShown = true;
    tc.textContent = `${Math.round(sp.down_mbps)}↓ ${Math.round(sp.up_mbps)}↑ Mbps · ${n.latency_ms != null ? Math.round(n.latency_ms) + " ms" : ""}`;
    tc.title = `internet speed measured ${_ago(sp.ts)} (speed.cloudflare.com) — click for details / re-test`;
  } else if (tc && n.testing) {
    tc.textContent = "speed test running…";
  }
}
// fits inside the flank ring: ≤3 digits in ms, otherwise seconds
function fmtLatency(p) {
  if (p == null || p < 0) return "---";
  return p < 1000 ? String(Math.round(p)) : (p / 1000).toFixed(1) + "s";
}
function fmtCoords(lat, lon) {
  return `${Math.abs(lat).toFixed(2)}°${lat >= 0 ? "N" : "S"} · ${Math.abs(lon).toFixed(2)}°${lon >= 0 ? "E" : "W"}`;
}
async function initGeo() {
  try {
    const g = await (await fetch("/api/geo")).json();
    if (g && g.lat != null) {
      userLat = g.lat; userLon = g.lon;
      window._geo = g;
      const parts = [g.city, g.region, g.country].filter(Boolean);
      if (parts.length) updateLocation(parts.map(s => String(s).toUpperCase()).join(" · "));
      updateLocation(null, fmtCoords(g.lat, g.lon));
      if (g.city) {
        weatherCity = String(g.city).toUpperCase();
        const wc = $("#weather-city"); if (wc) wc.textContent = `${weatherCity} · WEATHER`;
      }
      const isp = $("#isp-value");
      if (isp) { isp.textContent = g.isp || "—"; isp.title = [g.isp, g.ip].filter(Boolean).join(" · "); }
      refreshWeather(true);
    }
  } catch (e) {}
  detectLocation();   // refine with precise browser GPS if the user grants it
}
function detectLocation() {
  if (!navigator.geolocation) return;
  navigator.geolocation.getCurrentPosition(async (pos) => {
    const { latitude, longitude } = pos.coords;
    userLat = latitude; userLon = longitude;
    updateLocation(null, `${latitude.toFixed(2)}°${latitude>=0?"N":"S"} · ${longitude.toFixed(2)}°${longitude>=0?"E":"W"}`);
    // re-fetch weather for the detected coords
    refreshWeather(true);
    try {
      const r = await fetch(`https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`);
      const d = await r.json();
      const parts = [d.locality, d.principalSubdivision, d.countryName].filter(Boolean);
      if (parts.length) {
        updateLocation(parts.map(s => s.toUpperCase()).join(" · "));
        weatherCity = (d.locality || d.principalSubdivision || "your area").toUpperCase();
        const wc = $("#weather-city");
        if (wc) wc.textContent = `${weatherCity} · WEATHER`;
      }
    } catch (e) {}
  }, (err) => {
    console.warn("geolocation denied/unavailable:", err && err.message);
  }, { timeout: 8000, maximumAge: 60_000 });
}
initGeo();

// ── agenda + inbox ───────────────────────────────────
function fmtTime(ts) { return new Date(ts * 1000).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false }); }
function fmtCountdown(mins) {
  if (mins < 0) return "NOW";
  if (mins < 1) return "<1 MIN";
  if (mins < 60) return `${Math.round(mins)} MIN`;
  return `${Math.floor(mins/60)}H ${Math.round(mins%60)}M`;
}
function renderAgenda(events, source) {
  const host = $("#agenda-list"); host.innerHTML = "";
  $("#agenda-badge").textContent = `${events.length} TODAY`;
  if (!events.length) {
    host.innerHTML = source === "google"
      ? '<div class="agenda-empty">calendar clear — no upcoming events</div>'
      : '<div class="agenda-empty">no data — connect Google Calendar via the <b>G</b> button</div>';
    return;
  }
  for (const e of events) {
    const div = document.createElement("div");
    div.className = "agenda-item" + (e.priority === "high" ? " high" : "") + (e.minutes_until <= 10 && e.minutes_until > 0 ? " imminent" : "")
      + (e.response === "declined" ? " declined" : "");
    const who = e.attendee_count > 0
      ? `${e.attendee_count} guest${e.attendee_count > 1 ? "s" : ""}` + ((e.attendees || [])[0] ? ` · ${e.attendees[0]}` : "")
      : (e.location || `${e.duration_min} min`);
    const rsvp = { declined: "DECLINED", tentative: "MAYBE", needsAction: "RSVP?" }[e.response] || "";
    // only http(s) join links are rendered — never javascript: or other schemes
    const join = /^https:\/\//.test(e.meet_link || "")
      ? `<a class="agenda-join" href="${escapeHTML(e.meet_link)}" target="_blank" rel="noopener noreferrer"
            title="join on ${escapeHTML(e.meet_provider || "video call")}">JOIN</a>` : "";
    div.innerHTML = `
      <div class="agenda-time">
        ${fmtTime(e.start_ts)}
        <span class="agenda-countdown">${fmtCountdown(e.minutes_until)}</span>
      </div>
      <div class="agenda-body">
        <div class="agenda-title">${escapeHTML(e.title)}</div>
        <div class="agenda-meta">${e.calendar && e.calendar !== "Primary" ? `<span class="agenda-cal">${escapeHTML(e.calendar)}</span>` : ""}${rsvp ? `<span class="agenda-rsvp">${rsvp}</span>` : ""}${escapeHTML(who)}</div>
      </div>${join}`;
    div.querySelector(".agenda-join")?.addEventListener("click", ev => ev.stopPropagation());
    host.appendChild(div);
  }
}
function renderTasks(tasks) {
  const host = $("#agenda-list"); if (!host || !tasks || !tasks.length) return;
  const today = new Date().toISOString().slice(0, 10);
  const head = document.createElement("div");
  head.className = "agenda-tasks-head";
  head.textContent = `TASKS · ${tasks.length} OPEN`;
  host.appendChild(head);
  for (const t of tasks.slice(0, 5)) {
    const div = document.createElement("div");
    const overdue = t.due && t.due < today;
    div.className = "agenda-task" + (overdue ? " overdue" : "");
    div.innerHTML = `<span class="agenda-task-box" aria-hidden="true"></span>
      <span class="agenda-task-title">${escapeHTML(t.title)}</span>
      <span class="agenda-task-due">${t.due ? (overdue ? "OVERDUE " : "DUE ") + escapeHTML(t.due.slice(5)) : escapeHTML(t.list || "")}</span>`;
    host.appendChild(div);
  }
}
function renderInbox(emails, priorityCount, source) {
  const host = $("#inbox-list"); host.innerHTML = "";
  $("#inbox-badge").textContent = priorityCount ? `${priorityCount} PRIORITY` : `${emails.length} RECENT`;
  if (!emails.length) {
    host.innerHTML = source === "google"
      ? '<div class="inbox-empty">no recent mail</div>'
      : '<div class="inbox-empty">no data — connect Gmail via the <b>G</b> button</div>';
    return;
  }
  for (const m of emails) {
    const div = document.createElement("div");
    div.className = "inbox-item" + (m.priority === "priority" ? " priority" : "");
    div.innerHTML = `
      <div class="inbox-sender">${escapeHTML(m.sender)}</div>
      <div class="inbox-subject">${escapeHTML(m.subject)}</div>
      <div class="inbox-snippet">${escapeHTML(m.snippet || "")}</div>`;
    host.appendChild(div);
  }
}
async function refreshAgenda() {
  try {
    const r = await fetch("/api/agenda"); const d = await r.json();
    renderAgenda(d.events || [], d.source);
    renderTasks(d.tasks || []);
    renderInbox(d.emails || [], d.priority_unread || 0, d.source);
    try {
      pendingActions = (d.events || []).length + (d.priority_unread || 0);
      renderPriorityAlerts(d);
      renderCalIntel(d);
      if (d.source === "google") {
        const b = $("#agenda-badge");
        if (b) b.textContent = `${(d.events || []).length} · GOOGLE`;
      }
      lastAgenda = d; updateLiveOps();
    } catch (e) {}
  } catch (e) {}
}
refreshAgenda(); setInterval(refreshAgenda, 30000);

// ── resource bars ────────────────────────────────────
function updateResource(cpu, mem, disk) {
  if (cpu != null) { $("#res-cpu").textContent = `${Math.round(cpu)}%`; $("#res-cpu-bar").style.width = `${Math.min(100, cpu)}%`; }
  if (mem != null) { $("#res-mem").textContent = `${Math.round(mem)}%`; $("#res-mem-bar").style.width = `${Math.min(100, mem)}%`; }
  if (disk != null){ $("#res-disk2").textContent = `${Math.round(disk)}%`; $("#res-disk-bar").style.width = `${Math.min(100, disk)}%`; }
}

// ── AI PERFORMANCE card (r=36, circumference ≈ 226) ─
// The gauge is the measured command success rate (refreshAiPerf); while an agent
// is thinking the card only gets a "busy" glow, the number is never animated.
const AI_CIRC = 2 * Math.PI * 36;
function animateAiGauge(active) {
  document.getElementById("ai-perf-card")?.classList.toggle("busy", !!active);
}

// ── quick access buttons ─────────────────────────────
document.querySelectorAll(".quick-btn").forEach(btn => {
  btn.addEventListener("click", async () => {
    if (btn.classList.contains("busy")) return;
    btn.classList.add("busy");
    const action = btn.dataset.action;
    try {
      if (action === "worldmonitor") {
        await fetch("/api/browser/open", {
          method: "POST", headers: { "content-type": "application/json" },
          body: JSON.stringify({ url: "https://www.worldmonitor.app", fullscreen: false, app_mode: true }),
        });
        logEvent('<span class="tag">[quick]</span> launching worldmonitor.app');
      } else if (action === "refresh-news") {
        await fetch("/api/news/refresh", { method: "POST" });
        logEvent('<span class="tag">[quick]</span> world feed refresh queued');
      } else if (action === "system-scan") {
        const r = await fetch("/api/ask", {
          method: "POST", headers: { "content-type": "application/json" },
          body: JSON.stringify({ prompt: "Run a system scan and report any concerns in one sentence.", agent: "stark" }),
        });
        const d = await r.json();
        if (d.reply) logEvent(`<span class="tag">[stark]</span> ${escapeHTML(d.reply)}`);
      } else if (action === "briefing") {
        logEvent('<span class="tag">[quick]</span> compiling executive briefing…');
        const r = await fetch("/api/briefing", { method: "POST" });
        const d = await r.json();
        if (d.insight) logEvent(`<span class="tag">[briefing]</span> ${escapeHTML(d.insight)}`);
      } else if (action === "network-diag") {
        await refreshConnectivity();
        logEvent('<span class="tag">[quick]</span> network diagnostic complete');
      } else if (action === "security-sweep") {
        const r = await fetch("/api/ask", {
          method: "POST", headers: { "content-type": "application/json" },
          body: JSON.stringify({ prompt: "Security sweep: any anomalies on your end? One sentence.", agent: "hawkeye" }),
        });
        const d = await r.json();
        if (d.reply) logEvent(`<span class="tag">[hawkeye]</span> ${escapeHTML(d.reply)}`);
      }
    } catch (e) {
      logEvent("quick-action failed: " + escapeHTML(e.message), "error");
    } finally {
      setTimeout(() => btn.classList.remove("busy"), 800);
    }
  });
});

/* ═══ TOOL MODAL ═══════════════════════════════════ */

// Every figure below comes from a live endpoint. When a source has no data the
// panel says so; nothing here is invented (PROJECT_CONTEXT §1: real data only).
// function declarations (hoisted) — applyNetSnapshot, higher up the file, can
// run during load; a `const` here would throw a TDZ ReferenceError (PROJECT_CONTEXT §5)
function _ago(ts) { if (!ts) return "—"; const s = Math.max(0, Date.now() / 1000 - ts);
  return s < 60 ? `${Math.round(s)} s ago` : s < 3600 ? `${Math.round(s / 60)} min ago` : `${Math.round(s / 3600)} h ago`; }
function _hm(ts) { return ts ? new Date(ts * 1000).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false }) : "—"; }
function _stat(lbl, val, cls = "") { return `<div class="mb-stat"><span class="lbl">${lbl}</span><span class="val ${cls}">${escapeHTML(String(val ?? "—"))}</span></div>`; }
function _row(txt, meta) { return `<div class="mb-row">${txt}<div class="mb-row-meta">${meta}</div></div>`; }
function _none(msg) { return `<div class="mb-row" style="color:var(--text-dim)">${msg}</div>`; }
function _fmtMbps(v) { return v == null ? "—" : `${v >= 100 ? Math.round(v) : v} Mbps`; }

async function gatherToolSnapshot() {
  const j = async p => { try { const r = await fetch(p); return r.ok ? await r.json() : {}; } catch (e) { return {}; } };
  const [status, models, aiops, threats, orch, ent, auth, fleet, conn, procs] = await Promise.all(
    ["/api/status", "/api/models", "/api/aiops", "/api/threats", "/api/orchestrator", "/api/enterprise",
     "/api/auth/status", "/api/fleet", "/api/connectivity", "/api/processes"].map(j));
  return { status, models, aiops, threats, orch, ent, auth, fleet, conn, procs };
}

const TOOL_DATA = {
  "ai-diagnostics": {
    title: "AI DIAGNOSTICS", sub: "LIVE BRAIN & AGENT TELEMETRY",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 3 L12 21 M3 12 L21 12"/><path d="M5 5 L19 19 M5 19 L19 5" opacity="0.45"/><circle cx="12" cy="12" r="2.6" fill="currentColor"/></svg>`,
    render: s => {
      const m = s.models || {}, eng = (s.aiops || {}).engine || {}, agents = (s.status || {}).agents || [];
      const busy = agents.filter(a => a.status && a.status !== "idle").length;
      const local = (m.local || []).map(x => `${x.name} · ${x.param_size || ""} ${x.quant || ""}`.trim()).join(", ") || "none installed";
      return `<div class="mb-grid">
        ${_stat("ACTIVE BRAIN", (m.active_brain || (s.status || {}).brain_mode || "—").toUpperCase(), m.active_brain ? "ok" : "warn")}
        ${_stat("CLAUDE CLI", m.cloud_claude ? "REACHABLE" : "UNAVAILABLE", m.cloud_claude ? "ok" : "warn")}
        ${_stat("LOCAL LLM", m.local_available ? (m.selected || "online") : "OFFLINE", m.local_available ? "ok" : "warn")}
        ${_stat("INSIGHT LATENCY", eng.latency_ms != null ? (eng.latency_ms / 1000).toFixed(1) + " s" : "—")}
        ${_stat("INSIGHT CONFIDENCE", eng.confidence != null ? eng.confidence + "%" : "—")}
        ${_stat("AGENTS BUSY", `${busy} / ${agents.length}`)}
      </div><div class="mb-list">
        ${_row(`Local models: ${escapeHTML(local)}`, `ENDPOINT · ${escapeHTML(m.endpoint || "—")}`)}
        ${_row(`Insights engine: ${escapeHTML(eng.source || "—")} ${eng.model ? "· " + escapeHTML(eng.model) : ""}`, `LAST RUN · ${_ago(eng.last_run)}`)}
        ${agents.map(a => _row(`${escapeHTML(a.codename || a.name)} — ${escapeHTML(a.status || "idle")}`, `${escapeHTML((a.current_task || "—").slice(0, 60))} · CONF ${a.confidence ?? "—"}%`)).join("")}
      </div>`;
    },
  },
  "satellite-feed": {
    title: "FLEET UPLINK", sub: "COMMAND FLEET · LIVE NODE REPORTS",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 5 19 L 19 5"/><path d="M 4 14 A 10 10 0 0 0 14 4"/><circle cx="6" cy="18" r="2" fill="currentColor"/><path d="M 11 11 L 14 14"/></svg>`,
    render: s => {
      const f = s.fleet || {}, agg = f.aggregate || {}, nodes = f.nodes || [];
      return `<div class="mb-grid">
        ${_stat("NODES ONLINE", `${agg.online ?? 0} / ${agg.nodes ?? nodes.length}`, agg.online ? "ok" : "warn")}
        ${_stat("TOTAL CORES", agg.cpu_cores ?? "—")}
        ${_stat("TOTAL RAM", agg.mem_total_gb != null ? agg.mem_total_gb + " GB" : "—")}
        ${_stat("AVG CPU", agg.avg_cpu != null ? agg.avg_cpu + "%" : "—")}
        ${_stat("REPORTS", f.reports_total ?? "—")}
        ${_stat("SITE", (f.site || {}).name || "local")}
      </div><div class="mb-list">
        ${nodes.length ? nodes.map(n => _row(`<strong>${escapeHTML(n.name || n.node_id)}</strong> · ${escapeHTML(n.platform || "")} · CPU ${n.cpu ?? "—"}% · MEM ${n.mem ?? "—"}%`,
          `${escapeHTML(n.status || "online").toUpperCase()} · LAST REPORT ${_ago(n.ts)} · UP ${n.uptime_min != null ? Math.round(n.uptime_min / 60) + " h" : "—"}`)).join("")
          : _none("No fleet nodes reporting yet. Add one from the COMMAND FLEET panel.")}
      </div>`;
    },
  },
  "threat-scanner": {
    title: "THREAT SCANNER", sub: "LIVE RISK ENGINE · 6-DOMAIN",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 12 2 L 20 5 V 12 Q 20 18 12 22 Q 4 18 4 12 V 5 Z"/><circle cx="12" cy="12" r="2.5" fill="currentColor"/></svg>`,
    render: s => {
      const t = s.threats || {}, soc = t.soc || {}, open = (t.events || []).filter(e => e.stage === "active");
      const lvl = (t.level || "—").toUpperCase(), cls = t.level === "secure" ? "ok" : "warn";
      return `<div class="mb-grid">
        ${_stat("RISK SCORE", t.risk_score != null ? `${t.risk_score} / 100` : "—", cls)}
        ${_stat("LEVEL", lvl, cls)}
        ${_stat("OPEN INCIDENTS", open.length, open.length ? "warn" : "ok")}
        ${_stat("EVENTS ANALYZED", soc.analyzed ?? "—")}
        ${_stat("ALERTS", soc.alerts ?? "—", soc.alerts ? "warn" : "ok")}
        ${_stat("ACKNOWLEDGED", t.acked ?? 0)}
      </div><div class="mb-list">
        ${open.length ? open.slice(0, 6).map(e => _row(`${escapeHTML(e.title)}`, `${escapeHTML((e.severity || "").toUpperCase())} · ${escapeHTML((e.category || "").toUpperCase())} · ${escapeHTML(e.stage || "")} · ${_hm(e.ts)}`)).join("")
          : _none("No open incidents. Signals are drawn from live telemetry, news and agenda.")}
      </div>`;
    },
  },
  "mission-files": {
    title: "MISSION BOARD", sub: "ORCHESTRATOR DIRECTIVES · LIVE",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 3 8 V 19 H 21 V 8 H 13 L 11 6 H 3 Z"/><line x1="3" y1="12" x2="21" y2="12"/></svg>`,
    render: s => {
      const o = s.orch || {}, act = (o.directives || []).filter(d => d.status === "active"), done = o.recent_done || [];
      const pl = o.priority_labels || {};
      return `<div class="mb-grid">
        ${_stat("ACTIVE", act.length, act.length ? "" : "ok")}
        ${_stat("DELEGATIONS", o.delegations_total ?? 0)}
        ${_stat("PREEMPTIONS", o.preemptions_total ?? 0)}
        ${_stat("CONSULTS", o.collabs_total ?? 0)}
        ${_stat("CYCLES", o.cycles ?? 0)}
        ${_stat("COORDINATOR", (o.coordinator || "—").toUpperCase())}
      </div><div class="mb-list">
        ${act.map(d => _row(`<strong>${escapeHTML(d.title)}</strong>`, `ACTIVE · ${escapeHTML((d.agent || "").toUpperCase())}${d.consult ? " + " + escapeHTML(d.consult.toUpperCase()) : ""} · ${escapeHTML(pl[d.priority] || "P" + d.priority)} · SINCE ${_hm(d.ts)}`)).join("")}
        ${done.slice(0, 5).map(d => _row(escapeHTML(d.title), `${escapeHTML((d.status || "done").toUpperCase())} · ${escapeHTML((d.agent || "").toUpperCase())} · ${_hm(d.done_ts || d.ts)}`)).join("")}
        ${!act.length && !done.length ? _none("No directives yet. The orchestrator raises them from live conditions every 20 s.") : ""}
      </div>`;
    },
  },
  "security-logs": {
    title: "SECURITY LOGS", sub: "APPEND-ONLY AUDIT TRAIL",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="10" rx="1"/><path d="M 8 11 V 7 A 4 4 0 0 1 16 7 V 11"/><circle cx="12" cy="15" r="1.6" fill="currentColor"/></svg>`,
    render: s => {
      const au = (s.ent || {}).audit || {}, a = s.auth || {}, rec = au.recent || [];
      return `<div class="mb-grid">
        ${_stat("AUDIT ENTRIES", au.entries_total ?? 0)}
        ${_stat("ROLE", ((s.ent || {}).role || "—").toUpperCase())}
        ${_stat("OPERATOR", (s.ent || {}).operator || "—")}
        ${_stat("REMOTE ACCESS", a.password_set ? "PASSWORD SET" : "DISABLED", a.password_set ? "" : "ok")}
        ${_stat("BINDING", a.binding || "—", a.binding === "127.0.0.1" ? "ok" : "warn")}
        ${_stat("COMMAND PIN", (s.ent || {}).pin_required ? "REQUIRED" : "OFF")}
      </div><div class="mb-list">
        ${rec.length ? rec.slice(0, 8).map(e => _row(`${_hm(e.ts)} — ${escapeHTML(e.action)} · ${escapeHTML((e.detail || "").slice(0, 80))}`, `${escapeHTML(e.operator || "")} · ${escapeHTML((e.role || "").toUpperCase())}`)).join("")
          : _none("No audit entries yet.")}
      </div>`;
    },
  },
  "network-activity": {
    title: "NETWORK ACTIVITY", sub: "LIVE LINK · MEASURED INTERNET SPEED",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/><circle cx="12" cy="12" r="2.5" fill="currentColor"/><path d="M 7.5 7.5 L 10.5 10.5 M 16.5 7.5 L 13.5 10.5 M 7.5 16.5 L 10.5 13.5 M 16.5 16.5 L 13.5 13.5"/></svg>`,
    render: s => {
      const c = s.conn || {}, w = c.wifi || {}, net = c.net || {}, sp = net.speed || null, link = c.link || {};
      const top = ((s.procs || {}).top_cpu || [])[0];
      const secure = w.auth && !/open/i.test(w.auth);
      const spd = sp && sp.ok ? `${_fmtMbps(sp.down_mbps)} ↓ · ${_fmtMbps(sp.up_mbps)} ↑` : net.testing ? "testing…" : sp ? "test failed" : "not run yet";
      return `<div class="mb-grid">
        ${_stat("INTERNET SPEED", spd, sp && sp.ok ? "ok" : "")}
        ${_stat("LATENCY", net.latency_ms != null ? `${net.latency_ms} ms` : "—", net.latency_ms != null && net.latency_ms < 60 ? "ok" : "warn")}
        ${_stat("JITTER · LOSS", `${net.jitter_ms ?? "—"} ms · ${net.loss_pct ?? "—"}%`, net.loss_pct ? "warn" : "ok")}
        ${_stat("LINK", link.type ? `${String(link.type).toUpperCase()} · ${link.name || ""}` : "—")}
        ${_stat("WI-FI RATE (PHY)", w.speed_rx_mbps ? `${w.speed_rx_mbps} Mbps` : "—")}
        ${_stat("SIGNAL", w.signal || "—")}
      </div><div class="mb-list">
        ${_row(`SSID ${escapeHTML(w.ssid || "—")} · channel ${escapeHTML(w.channel || "—")} · security <b style="color:var(${secure ? "--success" : "--warn"})">${escapeHTML(w.auth || "unknown")}</b>`, secure ? "ENCRYPTED LINK" : "UNENCRYPTED WI-FI · USE A VPN ON THIS NETWORK")}
        ${sp && sp.ok ? _row(`Speed test · ${escapeHTML(sp.server)} · ${Math.round(sp.bytes_used / 1e6)} MB used`, `MEASURED ${_ago(sp.ts)}`) : ""}
        ${top ? _row(`Busiest process: ${escapeHTML(top.name)} · CPU ${top.cpu}% · ${Math.round(top.mem_mb)} MB`, "LIVE PROCESS SWEEP") : ""}
        ${_row(`Bluetooth: ${((c.bluetooth || {}).count ?? "unknown")} paired device(s)`, "ADAPTER")}
      </div>
      <button class="cmd-btn" id="speedtest-btn" ${net.testing ? "disabled" : ""}>${net.testing ? "SPEED TEST RUNNING…" : "RUN SPEED TEST NOW (~33 MB)"}</button>`;
    },
  },
};

async function openToolModal(toolKey) {
  const def = TOOL_DATA[toolKey]; if (!def) return;
  const modal = $("#tool-modal"); if (!modal) return;
  $("#modal-title").textContent = def.title;
  $("#modal-sub").textContent = def.sub;
  $("#modal-icon").innerHTML = def.icon;
  $("#modal-body").innerHTML = '<div style="color:var(--text-dim);font-style:italic">acquiring live data…</div>';
  modal.hidden = false;
  const seq = ++window._mSeq;

  const state = await gatherToolSnapshot();
  if (seq !== window._mSeq) return;           // the operator opened something else meanwhile
  try {
    $("#modal-body").innerHTML = def.render(state);
    $("#speedtest-btn")?.addEventListener("click", async (ev) => {
      ev.target.disabled = true; ev.target.textContent = "SPEED TEST RUNNING…";
      try { await fetch("/api/network/speedtest", { method: "POST" }); } catch (e) {}
      openToolModal(toolKey);           // re-render with the measured result
    });
  } catch (e) {
    $("#modal-body").innerHTML = `<div style="color:var(--error)">render error: ${escapeHTML(e.message)}</div>`;
  }
}
function closeToolModal() {
  window._mSeq = (window._mSeq || 0) + 1;
  const modal = $("#tool-modal"); if (modal) modal.hidden = true;
}

document.querySelectorAll(".tool-card").forEach(btn => {
  btn.addEventListener("click", () => {
    btn.classList.add("flash");
    setTimeout(() => btn.classList.remove("flash"), 700);
    openToolModal(btn.dataset.tool);
  });
});
$("#modal-close")?.addEventListener("click", closeToolModal);
$("#modal-backdrop")?.addEventListener("click", closeToolModal);
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeToolModal(); });

// header tool-cards: one live figure each (all from real endpoints)
async function refreshToolCardStats() {
  const s = await gatherToolSnapshot();
  const set = (id, txt) => { const el = $(id); if (el && txt) el.textContent = txt; };
  const agents = (s.status || {}).agents || [];
  const brain = (window._brainShort || (s.models || {}).active_brain || (s.status || {}).brain_mode || "—").toUpperCase();
  set("#tc-ai", `BRAIN · ${brain} · ${agents.filter(a => a.status !== "idle").length}/${agents.length} BUSY`);
  const agg = (s.fleet || {}).aggregate || {};
  set("#tc-fleet", `${agg.online ?? 0}/${agg.nodes ?? 0} NODES · ${agg.cpu_cores ?? "—"} CORES`);
  const t = s.threats || {};
  const open = (t.events || []).filter(e => e.stage === "active").length;
  set("#tc-threat", `RISK ${t.risk_score ?? "—"} · ${open} OPEN`);
  const o = s.orch || {};
  set("#tc-missions", `${o.active ?? 0} ACTIVE · ${(o.recent_done || []).length} DONE`);
  const au = (s.ent || {}).audit || {};
  set("#tc-sec", `${au.entries_total ?? 0} AUDIT · ${(s.auth || {}).password_set ? "REMOTE ON" : "LOCAL ONLY"}`);
  // globe readouts: real fleet + mission counts and the IP-geolocated latitude
  set("#og-sats", String(agg.online ?? 0));
  set("#og-nodes", String(o.active ?? 0));
  const g = window._geo;
  if (g && g.lat != null) set("#og-coord", `${Math.abs(g.lat).toFixed(1)}°${g.lat >= 0 ? "N" : "S"}`);
  // orb flank: real Wi-Fi channel + link security (was hardcoded SEC-7 / AES-256)
  const w = (s.conn || {}).wifi || {};
  set("#fl-chan", w.channel ? `CH ${w.channel}` : ((s.conn || {}).link || {}).type ? String(s.conn.link.type).toUpperCase() : "—");
  const enc = $("#fl-enc");
  if (enc) { enc.textContent = w.auth ? String(w.auth).toUpperCase().slice(0, 12) : "WIRED";
             enc.classList.toggle("ok", !!w.auth && !/open/i.test(w.auth));
             enc.classList.toggle("warn", !!w.auth && /open/i.test(w.auth)); }
}
refreshToolCardStats();
setInterval(refreshToolCardStats, 20000);

// ── operator camera ──────────────────────────────────
const camRoot   = $("#operator-cam");
const camVideo  = $("#cam-video");
const camStatus = $("#cam-status");
const camToggle = $("#cam-toggle");
const camResEl  = $("#cam-res");
let camStream   = null;

/* Phase 3 · multi-camera situational awareness */
// "" = default camera. The chosen camera is remembered per browser; a remembered id is only
// a preference ("ideal") so a camera that was unplugged never blocks the stream.
let camDeviceId = (() => { try { return localStorage.getItem("bucs.camera") || ""; } catch (e) { return ""; } })();
let camDeviceExact = false;      // true once the operator picks one in this session
function camLabel() {
  const sel = $("#cam-select");
  const opt = sel && sel.selectedOptions[0];
  return (opt && opt.value ? opt.textContent : "primary").slice(0, 40);
}
async function enumerateCameras() {
  try {
    const devs = await navigator.mediaDevices.enumerateDevices();
    const cams = devs.filter(d => d.kind === "videoinput");
    const sel = $("#cam-select"); if (!sel) return;
    const cur = camDeviceId;
    sel.innerHTML = cams.map((c, i) =>
      `<option value="${escapeHTML(c.deviceId)}"${c.deviceId === cur ? " selected" : ""}>` +
      `${escapeHTML((c.label || `CAMERA ${i + 1}`).toUpperCase().slice(0, 28))}</option>`).join("")
      || '<option value="">DEFAULT CAMERA</option>';
    if (cams.length > 1)
      logEvent(`<span class="tag">[cam]</span> ${cams.length} cameras available — multi-camera awareness armed`);
  } catch (e) {}
}
$("#cam-select")?.addEventListener("change", async () => {
  camDeviceId = $("#cam-select").value || "";
  camDeviceExact = true;
  try { localStorage.setItem("bucs.camera", camDeviceId); } catch (e) {}
  if (camStream) {          // hot-switch: restart the stream on the new device
    const aiWasOn = VisionAI.on;               // stopCamera() turns AI vision off; a switch shouldn't
    stopCamera();
    await startCamera();
    if (aiWasOn && camStream && !VisionAI.on) VisionAI.toggle();
    logEvent(`<span class="tag">[cam]</span> switched to ${escapeHTML(camLabel())}`);
  }
});

async function startCamera() {
  if (camStream) return;
  logEvent('<span class="tag">[cam]</span> requesting camera access…');

  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    camStatus.textContent = "✕ UNSUPPORTED";
    camRoot.classList.add("error");
    logEvent('<span class="tag">[cam]</span> camera API not available — http:// origin may block it. Try http://127.0.0.1:8765 (not 0.0.0.0 / LAN ip)', "warn");
    return;
  }
  camRoot.classList.remove("error");
  camRoot.classList.add("requesting");
  camStatus.textContent = "◌ REQUESTING…";
  try {
    const vidConstraints = {
      width:  { ideal: 480 },
      height: { ideal: 360 },
    };
    if (camDeviceId) vidConstraints.deviceId = camDeviceExact ? { exact: camDeviceId } : { ideal: camDeviceId };
    else vidConstraints.facingMode = "user";
    const stream = await navigator.mediaDevices.getUserMedia({
      video: vidConstraints,
      audio: false,
    });
    camStream = stream;
    camVideo.srcObject = stream;
    enumerateCameras();   // labels become available once permission is granted

    // Explicit play() — autoplay can silently fail on display:none or unfocused tabs.
    try {
      await camVideo.play();
    } catch (playErr) {
      console.warn("[cam] play() failed:", playErr);
      logEvent(`<span class="tag">[cam]</span> play blocked: ${escapeHTML(playErr.message || playErr.name)}`, "warn");
    }

    camRoot.classList.remove("requesting");
    camRoot.classList.add("live");
    camStatus.textContent = "◉ LIVE";

    // Read actual stream dimensions once metadata arrives
    const showRes = () => {
      const w = camVideo.videoWidth, h = camVideo.videoHeight;
      if (w && h && camResEl) camResEl.textContent = `${w}×${h}`;
    };
    if (camVideo.readyState >= 1) showRes();
    else camVideo.addEventListener("loadedmetadata", showRes, { once: true });

    logEvent('<span class="tag">[cam]</span> operator view online');
    try { Presence.start(); } catch (e) { console.warn("[presence] start failed:", e); }

    // If the user revokes permission or the device disappears, clean up.
    stream.getVideoTracks().forEach(t => {
      t.addEventListener("ended", () => stopCamera());
    });
  } catch (e) {
    console.error("[cam] getUserMedia failed:", e);
    camRoot.classList.remove("requesting", "live");
    camRoot.classList.add("error");
    const msg = e.name === "NotAllowedError" ? "PERMISSION DENIED"
              : e.name === "NotFoundError"   ? "NO CAMERA FOUND"
              : e.name === "NotReadableError"? "CAMERA IN USE"
              : e.name === "OverconstrainedError" ? "CONSTRAINTS UNMET"
              : e.name === "SecurityError"   ? "BLOCKED · USE HTTPS OR 127.0.0.1"
              : (e.name || "ERROR");
    camStatus.textContent = "✕ " + msg;
    logEvent(`<span class="tag">[cam]</span> ${escapeHTML(msg)} · ${escapeHTML(e.message || "")}`, "warn");
  }
}

function stopCamera() {
  if (camStream) {
    try { camStream.getTracks().forEach(t => t.stop()); } catch (e) {}
    camStream = null;
  }
  if (camVideo) camVideo.srcObject = null;
  camRoot.classList.remove("live", "requesting", "error");
  camStatus.textContent = "◌ OFFLINE";
  if (camResEl) camResEl.textContent = "--×--";
  try { Presence.stop(); } catch (e) {}
  try { if (VisionAI.on) VisionAI.toggle(); } catch (e) {}   // disable AI vision with the camera
  logEvent('<span class="tag">[cam]</span> operator view offline');
}

camToggle?.addEventListener("click", () => {
  if (camStream) stopCamera(); else startCamera();
});

/* ═══ AI VISION — Claude describes the webcam feed ═══════════
   Opt-in (protects Claude usage): when ON and the camera is live, a frame is
   captured every VISION_INTERVAL and sent to /api/vision/analyze; Claude's
   one-line observation is displayed + spoken. Also fires on demand (voice
   "what do you see", the AI button, or the manual analyze). */
const VisionAI = {
  on: false, timer: null, busy: false,
  interval: 45000,              // 45 s between auto-analyses — frequent operator comments
  canvas: document.createElement("canvas"),

  toggle() {
    this.on = !this.on;
    const btn = $("#cam-ai-toggle");
    if (btn) btn.classList.toggle("on", this.on);
    try { localStorage.setItem("vision-ai", this.on ? "1" : "0"); } catch (e) {}
    if (this.on) {
      if (!camStream) { logEvent('<span class="tag">[vision-ai]</span> enable the camera first', "warn"); }
      else { logEvent('<span class="tag">[vision-ai]</span> Claude vision ON — commenting every 45s'); this.analyze(); }
      this.timer = setInterval(() => { if (camStream) this.analyze(); }, this.interval);
    } else {
      if (this.timer) { clearInterval(this.timer); this.timer = null; }
      logEvent('<span class="tag">[vision-ai]</span> Claude vision OFF');
    }
  },

  async analyze(force = false) {
    if (this.busy) return;
    if (!camStream || camVideo.readyState < 2) {
      if (force) logEvent('<span class="tag">[vision-ai]</span> camera not ready', "warn");
      return;
    }
    this.busy = true;
    const btn = $("#cam-ai-toggle"); if (btn) btn.classList.add("busy");
    const vo = $("#vision-obs"); if (vo) vo.textContent = "◍ Claude is analysing the feed…";
    try {
      this.canvas.width = 320; this.canvas.height = 240;
      this.canvas.getContext("2d").drawImage(camVideo, 0, 0, 320, 240);
      const frame = this.canvas.toDataURL("image/jpeg", 0.6);
      const r = await fetch("/api/vision/analyze", {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ frame, speak: true, camera: camLabel() }),
      });
      const d = await r.json();
      if (!d.ok) {
        if (vo) vo.textContent = d.error === "rate-limited"
          ? `◍ cooling down (${d.retry_in}s)…` : `◍ ${d.error}`;
      }
      // success arrives via WS "vision-obs" + "insight"
    } catch (e) {
      if (vo) vo.textContent = "◍ vision request failed";
    } finally {
      this.busy = false;
      if (btn) btn.classList.remove("busy");
    }
  },
};
$("#cam-ai-toggle")?.addEventListener("click", () => VisionAI.toggle());

// Tidy up if the user navigates away
window.addEventListener("beforeunload", () => { if (camStream) stopCamera(); });

/* ═══ PRESENCE MONITOR — motion-based, identity-free ═══
   Samples the live video onto a 64×48 canvas every 450 ms, computes
   frame-to-frame luminance difference (motion) and scene variance
   (signal check). No face detection, no identification, no frames
   leave the machine — only an abstract state string is reported. */

function setChip(sel, base, text, cls) {
  const el = $(sel); if (!el) return;
  el.textContent = text;
  el.className = base + (cls ? " " + cls : "");
}

const Presence = {
  canvas: document.createElement("canvas"),
  ctx: null, prev: null, timer: null,
  ema: 0, lastMotion: 0, state: "offline",
  zones: new Array(9).fill(0),        // Phase 3: per-sector motion EMA (3×3)
  zoneHeat: new Array(9).fill(0),     // cumulative activity analytics
  _lastZoneAlert: 0,

  start() {
    this.canvas.width = 64; this.canvas.height = 48;
    this.ctx = this.canvas.getContext("2d", { willReadFrequently: true });
    this.prev = null; this.ema = 0; this.lastMotion = Date.now();
    setChip("#v-cam", "v-chip", "CAM ONLINE", "ok");
    this.setState("idle");
    this.timer = setInterval(() => { try { this.sample(); } catch (e) {} }, 450);
  },

  stop() {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    this.prev = null; this.ema = 0;
    setChip("#v-cam", "v-chip", "CAM OFFLINE", "dim");
    setChip("#chip-motion", "cam-chip", "MOTION 0", "dim");
    const mf = $("#motion-fill"); if (mf) mf.style.width = "0%";
    const mv = $("#motion-val"); if (mv) mv.textContent = "0";
    this.setState("offline");
  },

  sample() {
    if (!camStream || camVideo.readyState < 2) return;
    this.ctx.drawImage(camVideo, 0, 0, 64, 48);
    const d = this.ctx.getImageData(0, 0, 64, 48).data;
    const N = 64 * 48;
    const gray = new Uint8Array(N);
    let sum = 0;
    for (let i = 0; i < N; i++) {
      const j = i * 4;
      const g = (d[j] * 0.299 + d[j + 1] * 0.587 + d[j + 2] * 0.114) | 0;
      gray[i] = g; sum += g;
    }
    const mean = sum / N;
    let varSum = 0;
    for (let i = 0; i < N; i += 4) { const dv = gray[i] - mean; varSum += dv * dv; }
    const variance = varSum / (N / 4);

    let motion = 0;
    if (this.prev) {
      let diff = 0;
      const zdiff = new Array(9).fill(0);
      for (let i = 0; i < N; i += 2) {
        const d0 = Math.abs(gray[i] - this.prev[i]);
        diff += d0;
        // zone monitoring: map pixel → 3×3 sector (64×48 → 21px × 16px cells)
        const zx = Math.min(2, ((i % 64) / 21.34) | 0);
        const zy = Math.min(2, ((i / 64) / 16) | 0);
        zdiff[zy * 3 + zx] += d0;
      }
      motion = diff / (N / 2);
      const perZone = (N / 2) / 9;
      for (let z = 0; z < 9; z++) {
        const zm = zdiff[z] / perZone;
        this.zones[z] = this.zones[z] * 0.6 + zm * 0.4;
        this.zoneHeat[z] += zm > 3 ? zm : 0;   // activity analytics accumulator
      }
      this.renderZones();
      this.zoneWatch();
    }
    this.prev = gray;
    this.ema = this.ema * 0.6 + motion * 0.4;

    // live UI
    const mv = $("#motion-val");  if (mv) mv.textContent = this.ema.toFixed(1);
    const mf = $("#motion-fill"); if (mf) mf.style.width = Math.min(100, this.ema * 8) + "%";
    setChip("#chip-motion", "cam-chip", "MOTION " + Math.round(this.ema),
            this.ema > 3.5 ? "ok" : "dim");

    const now = Date.now();
    let next;
    // Hysteresis: enter ACTIVE above 3.5, only drop out below 2.0 — kills
    // boundary oscillation that would otherwise spam state changes.
    const activeThresh = this.state === "active" ? 2.0 : 3.5;
    if (variance < 60) next = "no-user";                 // covered lens / black frame
    else if (this.ema > activeThresh) { this.lastMotion = now; next = "active"; }
    else if (now - this.lastMotion < 45000) next = "idle";
    else next = "away";
    this.setState(next);
  },

  /* Phase 3 · zone monitoring — render the 3×3 sector heat + intrusion watch */
  ZONE_NAMES: ["TOP-LEFT", "TOP-CENTER", "TOP-RIGHT",
               "MID-LEFT", "CENTER", "MID-RIGHT",
               "LOW-LEFT", "LOW-CENTER", "LOW-RIGHT"],

  renderZones() {
    const grid = $("#zone-grid"); if (!grid) return;
    const cells = grid.children;
    for (let z = 0; z < 9 && z < cells.length; z++) {
      const v = this.zones[z];
      cells[z].className = v > 8 ? "z-hot" : v > 3.5 ? "z-warm" : v > 1.2 ? "z-low" : "";
    }
  },

  zoneWatch() {
    // while the operator is away, motion in any sector is a security signal:
    // raise a real alert naming the zone (rate-limited to one per 2 min)
    if (this.state !== "away" && this.state !== "no-user") return;
    let hot = -1, hotV = 0;
    for (let z = 0; z < 9; z++) if (this.zones[z] > hotV) { hotV = this.zones[z]; hot = z; }
    if (hotV < 7) return;
    const now = Date.now();
    if (now - this._lastZoneAlert < 120000) return;
    this._lastZoneAlert = now;
    const zone = this.ZONE_NAMES[hot] || "UNKNOWN";
    logEvent(`<span class="tag">[zone]</span> motion in ${zone} sector while operator away`, "warn");
    fetch("/api/alert", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({
        severity: "warning",
        title: `Zone monitor: motion in ${zone} sector`,
        detail: `Movement detected on ${camLabel()} while the operator is away (intensity ${hotV.toFixed(1)}).`,
        source: "vision · zone monitor",
        action: "Check the operator view feed.",
      }),
    }).catch(() => {});
  },

  setState(s) {
    if (s === this.state) return;
    const now = Date.now();
    // Min dwell of 2s between transitions (offline always allowed through)
    if (s !== "offline" && now - (this._lastChange || 0) < 2000) return;
    this._lastChange = now;
    this.state = s;
    const labels = {
      active: "USER DETECTED · ACTIVE", idle: "USER PRESENT · IDLE",
      away: "NO USER · AWAY", "no-user": "NO SIGNAL", offline: "CAM OFFLINE",
    };
    const cls = s === "active" ? "ok" : s === "idle" ? "warn" : "dim";
    setChip("#chip-presence", "cam-chip", labels[s] || s, cls);
    setChip("#v-presence", "v-chip", labels[s] || s, cls);
    const obs = {
      active: "operator in frame — session active",
      idle: "operator still — attention idle",
      away: "frame vacant — operator away",
      "no-user": "no usable signal from camera",
      offline: "camera feed offline — presence monitoring paused",
    }[s];
    const vo = $("#vision-obs"); if (vo) vo.textContent = obs;
    logEvent(`<span class="tag">[vision]</span> ${obs}`);
    fetch("/api/presence", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ state: s, motion: Math.round(this.ema * 10) / 10 }),
    }).catch(() => {});
  },
};

/* ═══ AI OPERATIONS CENTER ═══════════════════════════ */

const CONF_CIRC = 2 * Math.PI * 36;  // ≈ 226 (matches conf-arc r=36)

function setConfidence(pct) {
  const v = $("#conf-val");
  if (v) v.textContent = pct != null ? Math.round(pct) : "—";
  const lbl = document.querySelector("#aiops-reasoning .conf-lbl");
  if (lbl) lbl.textContent = pct != null ? "MODEL-REPORTED CONFIDENCE" : "RULE-BASED · NO CONFIDENCE";
  const arc = $("#conf-arc");
  if (arc && pct == null) arc.setAttribute("stroke-dashoffset", CONF_CIRC.toFixed(1));
  if (arc && pct != null) {
    const p = Math.max(0, Math.min(100, pct)) / 100;
    arc.setAttribute("stroke-dasharray", CONF_CIRC.toFixed(1));  // keep dasharray in sync with JS circumference
    arc.setAttribute("stroke-dashoffset", String((CONF_CIRC * (1 - p)).toFixed(1)));
  }
}

function setReasonState(stateStr) {
  const card = $("#aiops-reasoning");
  const el = $("#reason-state");
  if (el) el.textContent = stateStr.toUpperCase();
  if (card) card.classList.toggle("analyzing", stateStr === "analyzing");
}

/* — ACTIVE BRAIN badges (orb LLM CORE tile + insights MODEL chip): one source of truth —
   the provider registry (/api/llm/providers) + the selected local model (/api/models).
   Refreshed at boot, on every "models-updated" broadcast and every 30 s. */
function _brainLabel(reg, m) {
  const act = (reg.providers || []).find(p => p.active) || {};
  const id = reg.active || act.id || "auto";
  if (id === "ollama") return { short: String(m.selected || "ollama").split(":")[0], full: "Ollama · " + (m.selected || "—") };
  if (id === "smart") return { short: "SMART", full: "Smart router (per-task)" };
  if (id === "claude") return { short: "CLAUDE", full: "Claude (CLI)" };
  if (id === "auto") {
    if (m.force_local) return { short: String(m.selected || "local").split(":")[0], full: "Local · " + (m.selected || "—") };
    return m.cloud_claude ? { short: "CLAUDE", full: "Auto → Claude" }
         : m.local_available ? { short: String(m.selected || "local").split(":")[0], full: "Auto → local · " + (m.selected || "—") }
         : { short: "RULES", full: "Auto → rules (no model reachable)" };
  }
  return { short: String(act.model || act.name || id).split(/[:/]/).pop(), full: (act.name || id) + (act.model ? " · " + act.model : "") };
}
let _brainSeq = 0;
async function refreshBrainBadges() {
  const seq = ++_brainSeq;
  try {
    const mP = fetch("/api/models").then(r => r.json()).catch(() => null);
    const reg = await fetch("/api/llm/providers").then(r => r.json());
    if (seq !== _brainSeq) return;                 // a newer refresh already won
    _paintBrain(_brainLabel(reg, window._lastModels || {}));   // instant: registry is fast
    const m = await mP;
    if (!m || seq !== _brainSeq) return;
    window._lastModels = m;
    _paintBrain(_brainLabel(reg, m));
  } catch (e) {}
}
function _paintBrain(b) {
  try {
    const sl = $("#st-llm");
    if (sl) { sl.textContent = b.short.toUpperCase().slice(0, 9); sl.parentElement.title = "Active brain: " + b.full + " — click to switch"; }
    const rm = $("#reason-model");
    if (rm) { rm.textContent = b.short.toUpperCase().slice(0, 20); rm.title = b.full; }
    window._brainShort = b.short.toUpperCase().slice(0, 20);
    const tc = $("#tc-ai");                         // AI DIAGNOSTICS tool card: same label
    if (tc && /^BRAIN · .*? · /.test(tc.textContent)) tc.textContent = tc.textContent.replace(/^BRAIN · .*? · /, `BRAIN · ${window._brainShort} · `);
  } catch (e) {}
}
refreshBrainBadges();
setInterval(refreshBrainBadges, 30000);

/* Every place that shows the active brain re-reads it from here: the orb LLM CORE tile,
   the insights MODEL chip, LOCAL AI, the AI BRAIN ROUTER, the service grid, AI PERFORMANCE,
   the cluster list and (when open and idle) the LLM SWITCH modal. Triggered by the server's
   "models-updated" broadcast (any tab, typed/spoken switch) and right after a local switch. */
let _llmBusy = 0;                    // LLM SWITCH modal mid-action: don't re-render under it
function onBrainChanged(skipModal) {
  const run = f => { try { f(); } catch (e) {} };
  run(refreshBrainBadges); run(refreshLocalAI); run(refreshRouter); run(pollServiceGrid);
  run(refreshAiPerf); run(refreshCluster);
  try {
    const modal = document.getElementById("tool-modal"), form = document.getElementById("llm-form");
    if (!skipModal && modal && !modal.hidden && form && !_llmBusy && !form.contains(document.activeElement)) {
      Promise.all([fetch("/api/models").then(r => r.json()), fetch("/api/llm/providers").then(r => r.json())])
        .then(([m, p]) => { if (document.getElementById("llm-form") && !_llmBusy) renderModelManager(m, p); })
        .catch(() => {});
    }
  } catch (e) {}
}

/* Shared settings changed on the server ({"type":"sync","topic":…} from main._sync):
   every open dashboard re-reads that setting through the same refresh function. */
function uiSyncRun(topic) {
  const map = {
    notes: () => refreshNotes(),
    productivity: () => refreshProd(),
    enterprise: () => refreshEnterprise(),
    decisions: () => refreshDecisions(),
    licence: () => refreshBilling(),
    profile: () => CommanderProfile.refresh(),
    fleet: () => renderFleetJoin(),
  };
  const f = map[topic];
  if (f) { try { f(); } catch (e) {} }
  else { try { window.dispatchEvent(new CustomEvent("bucs:sync", { detail: { topic } })); } catch (e) {} }
}

function setEngineInfo(engine) {
  if (!engine) return;
  const lat = $("#reason-latency");
  if (lat) lat.textContent = engine.latency_ms != null ? engine.latency_ms + " ms" : "—";
  const src = $("#insight-source");
  if (src && engine.source) src.textContent = engine.source.toUpperCase();
  setConfidence(engine.confidence ?? null);
}

function addInsight(d, animate = true) {
  const feed = $("#insights-feed"); if (!feed) return;
  const empty = feed.querySelector(".insight-empty"); if (empty) empty.remove();
  const div = document.createElement("div");
  div.className = "insight-item " + (d.severity || "info");
  div._data = d; div.tabIndex = 0; div.setAttribute("role", "button"); div.title = "Open insight detail";
  const t = new Date((d.ts || Date.now() / 1000) * 1000)
    .toTimeString().slice(0, 5);
  div.innerHTML = `
    <div class="insight-text"></div>
    <div class="insight-rec">${d.recommendation ? "→ " + escapeHTML(d.recommendation) : ""}</div>
    <div class="insight-meta">${t} · ${escapeHTML((d.source || "").toUpperCase())}${d.confidence != null ? ` · CONF ${d.confidence}% (model)` : " · RULE"}</div>`;
  feed.prepend(div);
  while (feed.children.length > 8) {
    const old = feed.lastChild;
    if (old && old._typeInterval) clearInterval(old._typeInterval);  // no orphaned typewriters
    feed.removeChild(old);
  }
  const textEl = div.querySelector(".insight-text");
  const full = d.insight || "";
  if (animate) {
    div.classList.add("typing");
    let i = 0;
    const iv = setInterval(() => {
      i += 2;
      textEl.textContent = full.slice(0, i);
      if (i >= full.length) { clearInterval(iv); div._typeInterval = null; div.classList.remove("typing"); }
    }, 24);
    div._typeInterval = iv;
  } else {
    textEl.textContent = full;
  }
}

async function seedAiops() {
  try {
    const r = await fetch("/api/insights"); const d = await r.json();
    (d.insights || []).slice().reverse().forEach(it => addInsight(it, false));
    setEngineInfo(d.engine);
  } catch (e) {}
}
seedAiops();
setInterval(async () => {
  try {
    const r = await fetch("/api/insights"); const d = await r.json();
    setEngineInfo(d.engine);
  } catch (e) {}
}, 60000);

/* — activity heatmap: 60 one-minute buckets of event volume — */
const hmBuckets = new Array(60).fill(0);
let hmDirty = true;
function bumpActivity() { hmBuckets[0]++; hmDirty = true; }
function renderHeatmap() {
  const host = $("#activity-heatmap"); if (!host) return;
  if (!host.children.length) {
    for (let i = 0; i < 60; i++) {
      const c = document.createElement("div");
      c.className = "hm-cell";
      host.appendChild(c);
    }
  }
  const cells = host.children;
  for (let i = 0; i < 60; i++) {
    const v = hmBuckets[59 - i];   // oldest left, newest right
    const cls = v === 0 ? "" : v === 1 ? "h1" : v < 4 ? "h2" : v < 7 ? "h3" : "h4";
    cells[i].className = "hm-cell" + (cls ? " " + cls : "");
  }
}
setInterval(() => { hmBuckets.pop(); hmBuckets.unshift(0); hmDirty = true; }, 60000);
setInterval(() => { if (hmDirty) { renderHeatmap(); hmDirty = false; } }, 1500);
renderHeatmap();

/* — readiness / anomaly from live metrics — */
function updateAiopsTele(msg) {
  const ready = Math.max(0, Math.min(100, Math.round(
    100 - Math.max(0, msg.cpu - 70) * 0.8
        - Math.max(0, msg.mem - 80) * 1.2
        - Math.max(0, msg.disk - 85) * 1.6)));
  const anom = Math.min(100, Math.round(
    Math.max(0, msg.cpu - 85) * 1.5
    + Math.max(0, msg.mem - 88) * 2.0
    + Math.max(0, msg.disk - 92) * 2.5));
  const rv = $("#readiness-val"); if (rv) rv.textContent = ready + "%";
  const rb = $("#readiness-bar"); if (rb) rb.style.width = ready + "%";
  const av = $("#anomaly-val");  if (av) av.textContent = anom;
  const ab = $("#anomaly-bar");  if (ab) ab.style.width = anom + "%";
  // orb flank: CORE INTEGRITY = real stability (100 - anomaly index)
  const fc = $("#fl-core"); if (fc) fc.textContent = Math.round(100 - anom) + "%";
  // feed predictive analytics + mission readiness
  metricHist.cpu.push(msg.cpu); metricHist.mem.push(msg.mem);
  if (metricHist.cpu.length > 120) { metricHist.cpu.shift(); metricHist.mem.shift(); }
  try { updateMissionReadiness(ready, anom); } catch (e) {}
}

/* ═══ STRATEGIC INTEL · PREDICTIVE · READINESS ═══════ */

let agentsOnline = 0;          // set by renderAgents (snapshot)
let pendingActions = 0;        // set by refreshAgenda

const metricHist = { cpu: [], mem: [] };
let forecastChart = null;

function ensureForecastChart() {
  if (forecastChart || typeof Chart === "undefined") return;
  const el = document.getElementById("forecast-chart");
  if (!el) return;
  forecastChart = new Chart(el, {
    type: "line",
    data: { labels: [], datasets: [
      { data: [], borderColor: "#00d9ff", backgroundColor: "rgba(0,217,255,0.10)",
        borderWidth: 1.5, fill: true, tension: 0.3, pointRadius: 0 },
      { data: [], borderColor: "#ffb86c", borderDash: [4, 3],
        borderWidth: 1.4, fill: false, tension: 0.3, pointRadius: 0 },
    ]},
    options: { responsive: true, maintainAspectRatio: false, animation: false,
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      scales: { x: { display: false }, y: { min: 0, max: 100, display: false } } },
  });
}

function slopePerMin(arr) {
  // least-squares slope over ~2s samples → % per minute
  const n = arr.length;
  if (n < 8) return 0;
  let sx = 0, sy = 0, sxy = 0, sxx = 0;
  for (let i = 0; i < n; i++) { sx += i; sy += arr[i]; sxy += i * arr[i]; sxx += i * i; }
  const slope = (n * sxy - sx * sy) / (n * sxx - sx * sx || 1);
  return slope * 30;   // 30 samples per minute at 2s cadence
}
// d15 = projected change in percentage points over 15 min, clamped to what is
// physically possible from the current value (0-100 %)
const trendGlyph = (d15, now) => {
  if (now != null) d15 = Math.max(-now, Math.min(100 - now, d15));
  return d15 > 2 ? `↗ +${d15.toFixed(0)} pts` : d15 < -2 ? `↘ ${d15.toFixed(0)} pts` : "→ STABLE";
};

function updateForecast() {
  ensureForecastChart();
  if (!forecastChart) return;
  const hist = metricHist.cpu.slice(-45);
  if (hist.length < 8) return;
  const cpuPerMin = slopePerMin(hist);
  const memPerMin = slopePerMin(metricHist.mem.slice(-45));
  const cpu15 = cpuPerMin * 15, mem15 = memPerMin * 15;
  const last = hist[hist.length - 1];
  const proj = [];
  for (let i = 1; i <= 15; i++) proj.push(Math.max(0, Math.min(100, last + cpuPerMin * i)));
  forecastChart.data.labels = new Array(hist.length + 15).fill("");
  forecastChart.data.datasets[0].data = [...hist, ...new Array(15).fill(null)];
  forecastChart.data.datasets[1].data = [...new Array(hist.length - 1).fill(null), last, ...proj];
  forecastChart.update("none");

  const tc = $("#trend-cpu"); if (tc) tc.textContent = trendGlyph(cpu15, last);
  const tm = $("#trend-mem"); if (tm) tm.textContent = trendGlyph(mem15, metricHist.mem[metricHist.mem.length - 1]);
  const ft = $("#forecast-text");
  if (ft) {
    const memNow = metricHist.mem[metricHist.mem.length - 1] || 0;
    const cpuMsg = Math.abs(cpu15) < 2
      ? `CPU holding near ${last.toFixed(0)}%`
      : `CPU ${cpu15 > 0 ? "rising toward" : "easing toward"} ${Math.max(0, Math.min(100, last + cpu15)).toFixed(0)}%`;
    const memMsg = Math.abs(mem15) < 2
      ? `memory steady near ${memNow.toFixed(0)}%`
      : `memory ${mem15 > 0 ? "climbing to" : "falling to"} ~${Math.max(0, Math.min(100, memNow + mem15)).toFixed(0)}%`;
    ft.textContent = `Projection: ${cpuMsg}, ${memMsg} within 15 minutes.`;
  }
}
setInterval(updateForecast, 10000);

const MR_CIRC = 2 * Math.PI * 40;  // ≈ 251.3 (matches mr-arc r=40)
function updateMissionReadiness(ready, anomaly) {
  const val = $("#mr-val"); if (val) val.textContent = ready;
  const arc = $("#mr-arc");
  if (arc) {
    arc.setAttribute("stroke-dasharray", MR_CIRC.toFixed(1));
    arc.setAttribute("stroke-dashoffset", String((MR_CIRC * (1 - ready / 100)).toFixed(1)));
  }
  const g = document.querySelector(".mr-gauge");
  if (g) {
    g.classList.toggle("warn", ready < 75 && ready >= 50);
    g.classList.toggle("bad", ready < 50);
  }
  const sys = $("#mr-systems");
  if (sys) sys.textContent = agentsOnline ? `${agentsOnline} AGENTS` : "—";
  const pen = $("#mr-pending"); if (pen) pen.textContent = String(pendingActions);
  const stab = $("#mr-stability"); if (stab) stab.textContent = `${Math.max(0, 100 - anomaly)}%`;
  const up = $("#mr-uptime"); const ops = $("#ops-timer");
  if (up && ops) up.textContent = ops.textContent;
}

function renderPriorityAlerts(d) {
  const host = $("#priority-alerts"); if (!host) return;
  const items = [];
  for (const e of (d.events || [])) {
    if (e.minutes_until != null && e.minutes_until > 0 && e.minutes_until <= 30) {
      items.push({ tag: "MEETING", critical: e.minutes_until <= 10,
                   text: `${e.title} · in ${Math.round(e.minutes_until)} min` });
    }
  }
  for (const m of (d.emails || [])) {
    if (m.priority === "priority")
      items.push({ tag: "MAIL", critical: false,
                   text: `${(m.sender || "").split("@")[0]} — ${m.subject}` });
  }
  host.innerHTML = items.length
    ? items.slice(0, 4).map(a =>
        `<div class="alert-item${a.critical ? " critical" : ""}">` +
        `<span class="al-tag">${a.tag}</span>` +
        `<span class="al-text">${escapeHTML(a.text)}</span></div>`).join("")
    : '<div class="alert-empty">no priority alerts</div>';
}

/* ═══ THREAT INTELLIGENCE BOARD ══════════════════════ */

function addThreatEvent(ev, prepend = true) {
  const feed = $("#threat-feed"); if (!feed) return;
  const empty = feed.querySelector(".tf-empty"); if (empty) empty.remove();
  const div = document.createElement("div");
  div.className = "tf-item " + (ev.severity || "low");
  if (ev.id) { div.dataset.incident = ev.id; div.tabIndex = 0; div.setAttribute("role", "button"); div.title = "Open incident detail"; }
  const t = new Date((ev.ts || Date.now() / 1000) * 1000).toTimeString().slice(0, 5);
  div.innerHTML =
    `<span class="tf-cat">${escapeHTML(({ cyber: "CYBR" })[ev.category] || (ev.category || "sys").toUpperCase().slice(0, 4))}</span>` +
    `<span class="tf-title">${escapeHTML(ev.title || "")}</span>` +
    `<span class="tf-time">${t}</span>`;
  if (prepend) feed.prepend(div); else feed.appendChild(div);
  while (feed.children.length > 5) feed.removeChild(feed.lastChild);
}

function updateRisk(score, level) {
  const rs = $("#risk-score"); if (rs) rs.textContent = score;
  const tileVal = $("#st-threat");
  if (tileVal) {
    tileVal.textContent = score;
    const tile = tileVal.closest(".scan-tile");
    if (tile) {
      tile.classList.toggle("hot", level === "high");
      tile.classList.toggle("warm", level === "elevated");
    }
  }
  const st = $("#threat-state");
  const sh = $("#threat-shield");
  const label = level === "secure" ? "SECURE" : level === "elevated" ? "ELEVATED" : "HIGH RISK";
  if (st) { st.textContent = label; st.className = "threat-state " + level; }
  if (sh) { sh.className.baseVal = "threat-shield " + level; }
  // orb flank: SHIELD state mirrors the live risk level
  const fs = $("#fl-shield");
  // "HIGH RISK" (not "BREACH"): high risk is usually resource pressure, not an intrusion
  if (fs) fs.textContent = level === "secure" ? "ACTIVE" : level === "elevated" ? "ELEVATED" : "HIGH RISK";
  const fr = $("#fl-risk-lbl"); if (fr) fr.textContent = `RISK ${score}/100`;
}

async function seedThreats() {
  try {
    const r = await fetch("/api/threats"); const d = await r.json();
    const feed = $("#threat-feed");
    if (feed && !feed.querySelector(".tf-item")) {
      (d.events || []).slice(0, 5).reverse().forEach(ev => addThreatEvent(ev));
    }
    updateRisk(d.risk_score ?? 5, d.level || "secure");
    renderThreatCenter(d);
    try { lastThreat = d; updateLiveOps(); } catch (e2) {}
  } catch (e) {}
}
seedThreats();
setInterval(seedThreats, 45000);   // reconcile matrix/SOC/timeline; live events via WS

/* ═══ THREAT INTELLIGENCE CENTER (matrix · SOC · timeline) ═══ */

let threatRadar = null;
const MX_LABELS = ["OPS", "INFRA", "NET", "AI", "RES", "SEC"];
const MX_KEYS = ["operational", "infrastructure", "network", "ai", "resource", "security"];

function ensureRadar() {
  if (threatRadar || typeof Chart === "undefined") return;
  const el = document.getElementById("threat-radar"); if (!el) return;
  threatRadar = new Chart(el, {
    type: "radar",
    data: { labels: MX_LABELS, datasets: [{
      data: [0, 0, 0, 0, 0, 0],
      backgroundColor: "rgba(0,217,255,0.15)",
      borderColor: "#00d9ff", borderWidth: 1.5,
      pointRadius: 2.5, pointBackgroundColor: "#00d9ff",
    }]},
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 700 },
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      scales: { r: {
        min: 0, max: 100,
        ticks: { display: false },
        grid: { color: "rgba(0,217,255,0.14)" },
        angleLines: { color: "rgba(0,217,255,0.1)" },
        pointLabels: { color: "#7e96b3", font: { family: "Orbitron", size: 8 } },
      }},
    },
  });
}

function renderThreatCenter(d) {
  // matrix
  ensureRadar();
  const mx = d.matrix || {};
  if (threatRadar) {
    threatRadar.data.datasets[0].data = MX_KEYS.map(k => (mx[k] || {}).score || 0);
    threatRadar.update();
  }
  const rows = $("#matrix-rows");
  if (rows) {
    rows.innerHTML = MX_KEYS.map((k, i) => {
      const m = mx[k] || { score: 0, trend: "flat", signals: 0, basis: "" };
      const heat = m.score >= 60 ? "hot" : m.score >= 35 ? "warm" : "";
      const arrow = m.trend === "up" ? "▲" : m.trend === "down" ? "▼" : "—";
      const sig = m.signals ?? 0;
      return `<button type="button" class="mx-row ${heat}" data-domain="${k}" title="${escapeHTML(m.basis || "")} · click for detail">
        <span class="mx-name">${MX_LABELS[i]} · ${k.toUpperCase().slice(0, 9)}</span>
        <span class="mx-score">${m.score}</span>
        <span class="mx-trend ${m.trend}">${arrow}</span>
        <span class="mx-conf" title="incidents in this domain, last 30 min">${sig} SIG</span></button>`;
    }).join("");
  }
  // SOC
  const soc = d.soc || {};
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v ?? 0; };
  set("#soc-analyzed", soc.analyzed); set("#soc-alerts", soc.alerts);
  set("#soc-resolved", soc.resolved); set("#soc-invest", soc.investigations);
  // incident response timeline
  const tl = $("#ir-timeline");
  if (tl) {
    const evs = (d.events || []).slice(0, 6);
    tl.innerHTML = evs.length ? evs.map(ev => {
      const t = new Date(ev.ts * 1000).toTimeString().slice(0, 5);
      return `<div class="ir-item" data-incident="${escapeHTML(ev.id)}" tabindex="0" role="button" title="Open incident detail">
        <span class="ir-time">${t}</span>
        <span class="ir-main">
          <div class="ir-title">${escapeHTML(ev.title)}</div>
          <div class="ir-meta">${escapeHTML(ev.severity.toUpperCase())} · ASSIGNED <b>${escapeHTML((ev.agent || "jarvis").toUpperCase())}</b></div>
        </span>
        <span class="ir-stage ${ev.stage || "active"}">${(ev.stage || "active").toUpperCase()}</span>
      </div>`;
    }).join("") : '<div class="tf-empty">no incidents in the response pipeline</div>';
  }
  renderThreatAnalytics(d);
}

/* ═══ THREAT 2.0 — trend graph · alert distribution · response queue ═══ */

function renderThreatAnalytics(d) {
  // risk trend sparkline (raw canvas — no chart lib needed at this size)
  const cv = document.getElementById("risk-trend");
  if (cv) {
    const hist = d.history || [];
    const ctx = cv.getContext("2d");
    const W = cv.width = cv.clientWidth || 260, H = cv.height = 46;
    ctx.clearRect(0, 0, W, H);
    if (hist.length >= 2) {
      const scores = hist.map(h => h.score);
      const max = Math.max(25, ...scores);
      ctx.beginPath();
      hist.forEach((h, i) => {
        const x = (i / (hist.length - 1)) * (W - 4) + 2;
        const y = H - 4 - (h.score / max) * (H - 10);
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      });
      const last = scores[scores.length - 1];
      ctx.strokeStyle = last >= 50 ? "#ff3c3c" : last >= 20 ? "#facc15" : "#00d9ff";
      ctx.lineWidth = 1.6; ctx.stroke();
      // soft fill under the line
      ctx.lineTo(W - 2, H - 2); ctx.lineTo(2, H - 2); ctx.closePath();
      ctx.fillStyle = last >= 50 ? "rgba(255,60,60,0.12)"
                    : last >= 20 ? "rgba(250,204,21,0.10)" : "rgba(0,217,255,0.10)";
      ctx.fill();
    } else {
      ctx.fillStyle = "rgba(126,150,179,0.6)";
      ctx.font = "9px monospace";
      ctx.fillText("collecting risk samples…", 6, H / 2 + 3);
    }
  }
  // alert distribution by severity
  const dist = $("#ta-dist");
  if (dist) {
    const by = d.by_severity || {};
    const total = Math.max(1, Object.values(by).reduce((a, b) => a + b, 0));
    dist.innerHTML = ["critical", "high", "medium", "low"].map(sev => {
      const n = by[sev] || 0;
      return `<div class="ta-d-row">
        <span class="ta-d-name">${sev.toUpperCase()}</span>
        <div class="ta-d-bar"><div class="ta-d-fill ${sev}" style="width:${Math.round(n * 100 / total)}%"></div></div>
        <span class="ta-d-n">${n}</span></div>`;
    }).join("");
  }
  // response queue — incidents awaiting operator acknowledgement
  const q = $("#ta-queue"); const qn = $("#ta-queue-n");
  if (q) {
    const items = d.response_queue || [];
    if (qn) qn.textContent = items.length;
    q.innerHTML = items.length ? items.map(ev => `
      <div class="ta-q-item ${ev.severity}">
        <span class="ta-q-title" data-incident="${escapeHTML(ev.id)}" role="button" tabindex="0" title="${escapeHTML(ev.detail || "open incident detail")}">${escapeHTML(ev.title)}${ev.stage === "resolved" ? ' <em class="ta-q-cleared">CLEARED</em>' : ""}</span>
        <button class="ta-q-ack" data-id="${escapeHTML(ev.id)}">ACK</button>
      </div>`).join("")
      : '<div class="tf-empty">queue clear — nothing awaiting acknowledgement</div>';
    q.querySelectorAll(".ta-q-ack").forEach(btn => btn.addEventListener("click", async () => {
      btn.disabled = true; btn.textContent = "…";
      try {
        const r = await (await fetch("/api/threats/ack/" + encodeURIComponent(btn.dataset.id), { method: "POST" })).json();
        if (r.ok === false) logEvent(`<span class="tag">[threat]</span> ACK refused: ${escapeHTML(r.error || "observer role")}`, "warn");
      } catch (e) { logEvent('<span class="tag">[threat]</span> ACK failed (server unreachable)', "warn"); }
      seedThreats();
    }));
  }
}

/* ═══ INTELLIGENCE TICKER ════════════════════════════ */

const tickerItems = [];
function pushTicker(text, cls = "") {
  tickerItems.unshift(cls ? `<span class="${cls}">${escapeHTML(text)}</span>` : escapeHTML(text));
  if (tickerItems.length > 8) tickerItems.pop();
  const el = $("#ticker-content");
  if (el) el.innerHTML = tickerItems.join("&nbsp;&nbsp;<b>···</b>&nbsp;&nbsp;");
}

/* ═══ EMERGENCY ALERT SYSTEM ═════════════════════════ */

const AlertSystem = {
  ctx: null, unlocked: false, siren: null,
  active: { warning: 0, critical: 0, emergency: 0 },

  init() {
    const unlock = () => {
      try {
        this.ctx = this.ctx || new (window.AudioContext || window.webkitAudioContext)();
        this.ctx.resume(); this.unlocked = true;
      } catch (e) {}
    };
    document.addEventListener("pointerdown", unlock, { once: true });
    document.addEventListener("keydown", unlock, { once: true });
  },

  beep(freq, dur, delay = 0, type = "sine", vol = 0.07) {
    if (!this.unlocked || !this.ctx || window.dashAudioMuted) return;
    try {
      const t = this.ctx.currentTime + delay;
      const o = this.ctx.createOscillator(), g = this.ctx.createGain();
      o.type = type; o.frequency.value = freq;
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      o.connect(g); g.connect(this.ctx.destination);
      o.start(t); o.stop(t + dur);
    } catch (e) {}
  },

  sound(sev) {
    if (sev === "info") this.beep(880, 0.12);
    else if (sev === "warning") { this.beep(620, 0.14); this.beep(480, 0.16, 0.16); }
    else if (sev === "critical") { for (let i = 0; i < 3; i++) this.beep(900, 0.11, i * 0.18, "square", 0.06); }
    else if (sev === "emergency") this.startSiren();
  },

  startSiren() {
    if (!this.unlocked || !this.ctx || this.siren || window.dashAudioMuted) return;
    try {
      const o = this.ctx.createOscillator(), g = this.ctx.createGain(),
            lfo = this.ctx.createOscillator(), lg = this.ctx.createGain();
      o.type = "sawtooth"; o.frequency.value = 800;
      lfo.frequency.value = 0.9; lg.gain.value = 320;
      lfo.connect(lg); lg.connect(o.frequency);
      g.gain.value = 0.05;
      o.connect(g); g.connect(this.ctx.destination);
      o.start(); lfo.start();
      this.siren = { o, lfo, g };
    } catch (e) {}
  },
  stopSiren() {
    if (!this.siren) return;
    try { this.siren.o.stop(); this.siren.lfo.stop(); } catch (e) {}
    this.siren = null;
  },

  vibrate(sev) {
    if (!navigator.vibrate) return;
    try {
      if (sev === "warning") navigator.vibrate(120);
      else if (sev === "critical") navigator.vibrate([140, 90, 140]);
      else if (sev === "emergency") navigator.vibrate([220, 100, 220, 100, 220, 100, 220]);
    } catch (e) {}
  },

  release(sev) {
    if (this.active[sev] != null) this.active[sev] = Math.max(0, this.active[sev] - 1);
  },

  raise(a) {
    // Emergency renders as a persistent critical card — no full-screen
    // takeover, no edge glow, no siren. Corner cards only.
    let sev = ["info", "warning", "critical", "emergency"].includes(a.severity) ? a.severity : "info";
    if (sev === "emergency") sev = "critical";
    this.sound(sev); this.vibrate(sev);
    pushTicker(`[${sev.toUpperCase()}] ${a.title}`, sev === "critical" ? "tk-crit" : sev === "warning" ? "tk-warn" : "");
    if (this.active[sev] != null) this.active[sev]++;

    const stack = $("#alert-stack"); if (!stack) return;
    const card = document.createElement("div");
    card.className = "alert-card " + sev;
    const t = new Date().toTimeString().slice(0, 5);
    card.innerHTML = `
      <div class="ac-head"><span class="ac-sev">◢ ${sev.toUpperCase()}</span><span class="ac-time">${t}</span></div>
      <div class="ac-title">${escapeHTML(a.title || "")}</div>
      ${a.detail ? `<div class="ac-detail">${escapeHTML(a.detail)}</div>` : ""}
      ${a.action ? `<div class="ac-action">→ ${escapeHTML(a.action)}</div>` : ""}
      <div class="ac-src">SOURCE · ${escapeHTML((a.source || "system").toUpperCase())}</div>
      <div class="ac-btns">
        <button class="ac-btn" data-act="view">VIEW DETAILS</button>
        <button class="ac-btn" data-act="dismiss">DISMISS</button>
        <button class="ac-btn ack" data-act="ack">ACKNOWLEDGE</button>
      </div>`;
    const close = (acked) => {
      if (card._closed) return; card._closed = true;
      this.release(sev);
      if (sev === "critical") {
        this.criticalActive = Math.max(0, this.criticalActive - 1);
        this.stopLoopIfClear();
        if (acked) logEvent('<span class="tag">[alert]</span> critical acknowledged');
      }
      card.classList.add("out");
      setTimeout(() => card.remove(), 380);
    };
    card._close = close;
    card.querySelector('[data-act="ack"]').addEventListener("click", () => close(true));
    card.querySelector('[data-act="dismiss"]').addEventListener("click", () => close(false));
    card.querySelector('[data-act="view"]').addEventListener("click", () => { execDashCmd("threats"); });
    stack.prepend(card);
    while (stack.children.length > 3) {
      const old = stack.lastChild;
      if (old._close) old._close(false); else old.remove();
      if (stack.lastChild === old) break;   // safety
    }
    if (sev === "info") setTimeout(() => close(false), 6000);
    else if (sev === "warning") setTimeout(() => close(false), 12000);
    else { this.criticalActive++; this.startLoop(); }   // critical: persists + loops until user acts
  },

  criticalActive: 0, loopTimer: null,
  startLoop() {
    if (this.loopTimer) return;
    this.loopTimer = setInterval(() => {
      if (this.criticalActive > 0) {
        this.beep(900, 0.1, 0, "square", 0.05);
        this.beep(900, 0.1, 0.16, "square", 0.05);
      }
    }, 2200);
  },
  stopLoopIfClear() {
    if (this.criticalActive <= 0 && this.loopTimer) {
      clearInterval(this.loopTimer); this.loopTimer = null;
    }
  },
};
AlertSystem.init();

/* ═══ DASHBOARD VOICE CONTROL ════════════════════════ */

const DASH_TARGETS = {
  threats: ".bs-threat", map: ".map-panel", agenda: "#agenda-list",
  insights: "#aiops-insights", news: "#news-list", camera: "#operator-cam",
  roster: "#avengers-panel", readiness: "#intel-readiness",
};
function execDashCmd(target) {
  const sel = DASH_TARGETS[target]; if (!sel) return;
  const el = document.querySelector(sel); if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "center" });
  el.classList.add("flash-target");
  setTimeout(() => el.classList.remove("flash-target"), 2200);
  logEvent(`<span class="tag">[voice]</span> dashboard control → ${target}`);
}

/* ═══ CALENDAR INTELLIGENCE ══════════════════════════ */

let calIntelLive = null;   // intel stash for the 1-second countdown ticker

function renderCalIntel(d) {
  const el = $("#cal-intel"); if (!el) return;
  const intel = d.intel || {};
  calIntelLive = intel;
  if (!intel.meetings_today && intel.meetings_today !== 0) {
    el.textContent = "analyzing schedule…"; return;
  }
  const bits = [];
  bits.push(`${intel.meetings_today} mtgs today`);
  if (intel.density) bits.push(`${intel.density} load`);
  if (intel.largest_free_block_min != null) bits.push(`focus block ${intel.largest_free_block_min}m`);
  if (intel.conflicts) bits.push(`⚠ ${intel.conflicts} conflict${intel.conflicts > 1 ? "s" : ""}`);
  if (intel.readiness != null) bits.push(`readiness ${intel.readiness}%`);
  el.innerHTML = bits.join(" · ") +
    `<span class="cal-src${d.source === "google" ? " ok" : ""}">${(d.source || "mock").toUpperCase()}</span>`;
  el.classList.toggle("warn", !!intel.conflicts);

  // current meeting banner (live)
  const nowEl = $("#cal-now");
  if (nowEl) {
    if (intel.current_title) {
      nowEl.hidden = false;
      $("#cal-now-txt").textContent =
        `IN SESSION: ${intel.current_title} — ends in ${intel.current_ends_min} min`;
    } else nowEl.hidden = true;
  }
  // preparation suggestions (real rule-based, from the backend)
  const prep = $("#cal-prep");
  if (prep) {
    const items = intel.prep || [];
    prep.hidden = !items.length;
    prep.innerHTML = items.map(p => `<div>${escapeHTML(p)}</div>`).join("");
  }
  tickCalCountdown();
}

// 1-second countdown to the next meeting (uses next_start_ts from the intel)
function tickCalCountdown() {
  const cd = $("#cal-countdown"); if (!cd) return;
  const ts = calIntelLive && calIntelLive.next_start_ts;
  if (!ts || !calIntelLive.next_title) { cd.hidden = true; return; }
  const secs = Math.floor(ts - Date.now() / 1000);
  if (secs <= 0 || secs > 6 * 3600) { cd.hidden = true; return; }
  cd.hidden = false;
  const h = Math.floor(secs / 3600), m = Math.floor((secs % 3600) / 60), s = secs % 60;
  const t = (h ? `${h}h ` : "") + `${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
  cd.textContent = `T-MINUS ${t} → ${calIntelLive.next_title}`;
  cd.classList.toggle("soon", secs < 600);
}
setInterval(tickCalCountdown, 1000);

// AI schedule summary (only when Google is connected; cached server-side)
async function refreshCalSummary() {
  const el = $("#cal-summary"); if (!el) return;
  try {
    const d = await (await fetch("/api/agenda/summary")).json();
    if (d.summary) { el.hidden = false; el.textContent = "❝ " + d.summary + " ❞"; }
    else el.hidden = true;
  } catch (e) {}
}
setTimeout(refreshCalSummary, 12000); setInterval(refreshCalSummary, 600000);

// Google setup — guided, inside the dashboard (G button)
var GoogleSetup = {
  link: (href, label) => `<a href="${href}" target="_blank" rel="noopener noreferrer" class="gs-link">${label} ↗</a>`,
  open() {
    const modal = document.getElementById("tool-modal"); if (!modal) return;
    document.getElementById("modal-title").textContent = "CONNECT GOOGLE";
    document.getElementById("modal-sub").textContent = "ONE SIGN-IN · CALENDAR · GMAIL · TASKS · READ-ONLY";
    document.getElementById("modal-icon").textContent = "G";
    const L = this.link;
    document.getElementById("modal-body").innerHTML = `
      <ol class="gs-steps">
        <li>Create a Google Cloud project — ${L("https://console.cloud.google.com/projectcreate", "new project")}</li>
        <li>Enable the three APIs in that project — ${L("https://console.cloud.google.com/apis/library/calendar-json.googleapis.com", "Calendar")} ·
            ${L("https://console.cloud.google.com/apis/library/gmail.googleapis.com", "Gmail")} ·
            ${L("https://console.cloud.google.com/apis/library/tasks.googleapis.com", "Tasks")}</li>
        <li>OAuth consent screen → <b>External</b> → add <b>your own Gmail</b> as a test user — ${L("https://console.cloud.google.com/apis/credentials/consent", "consent screen")}</li>
        <li>Credentials → <b>Create OAuth client ID</b> → type <b>Desktop app</b> → <b>Download JSON</b> — ${L("https://console.cloud.google.com/apis/credentials", "credentials")}</li>
        <li>Choose that downloaded file here — BUCS checks it and stores it locally (never uploaded anywhere, never committed):
          <label class="gs-drop" id="gs-drop"><input type="file" id="gs-file" accept=".json,application/json" hidden>
            <span id="gs-drop-txt">⇪ choose or drop <b>client_secret_….json</b></span></label></li>
        <li><button class="cmd-btn" id="gs-connect" disabled>SIGN IN WITH GOOGLE</button> — your browser opens Google's own sign-in; approve once.</li>
      </ol>
      <div class="gs-status" id="gs-status" aria-live="polite"></div>`;
    modal.hidden = false;
    const file = document.getElementById("gs-file"), drop = document.getElementById("gs-drop");
    const take = f => f && this.upload(f);
    file.addEventListener("change", () => take(file.files[0]));
    drop.addEventListener("dragover", e => { e.preventDefault(); drop.classList.add("over"); });
    drop.addEventListener("dragleave", () => drop.classList.remove("over"));
    drop.addEventListener("drop", e => { e.preventDefault(); drop.classList.remove("over"); take(e.dataTransfer.files[0]); });
    document.getElementById("gs-connect").addEventListener("click", () => this.connect());
    fetch("/api/google/setup").then(r => r.json()).then(d => {
      if (d.credentials_present) { this.status("✓ OAuth client already stored — sign in below (or choose a new file to replace it).", "ok"); document.getElementById("gs-connect").disabled = false; }
    }).catch(() => {});
  },
  openEnable(issues) {
    const modal = document.getElementById("tool-modal"); if (!modal) return;
    const names = { calendar: "Google Calendar API", gmail: "Gmail API", tasks: "Google Tasks API" };
    const project = (Object.values(issues || {})[0] || {}).project;
    document.getElementById("modal-title").textContent = "ENABLE GOOGLE APIS";
    document.getElementById("modal-sub").textContent = `SIGNED IN ✓ · TURN ON ${Object.keys(issues).length} API${Object.keys(issues).length > 1 ? "S" : ""}${project ? " · PROJECT " + project : ""}`;
    document.getElementById("modal-icon").textContent = "G";
    document.getElementById("modal-body").innerHTML = `
      <p class="gs-note">Your sign-in worked and all permissions were granted — but these APIs are switched off in the Google Cloud project your client belongs to. Open each, click <b>ENABLE</b>, then come back and re-check.</p>
      <div class="gs-enable">${Object.entries(issues).map(([k, v]) =>
        `<a class="cmd-btn gs-en" href="${escapeHTML(v.enable_url)}" target="_blank" rel="noopener noreferrer">ENABLE ${escapeHTML(names[k] || k).toUpperCase()} ↗</a>`).join("")}</div>
      <p class="gs-note">Google can take 1–5 minutes to apply it.</p>
      <button class="cmd-btn" id="gs-recheck">↻ RE-CHECK &amp; SYNC</button>
      <div class="gs-status" id="gs-status" aria-live="polite"></div>`;
    modal.hidden = false;
    document.getElementById("gs-recheck").addEventListener("click", async () => {
      this.status("Checking with Google…");
      const d = await GoogleConnect.run();
      const left = Object.keys((d && d.api_issues) || {});
      if (d && d.ok && !left.length) { this.status(`✓ All set — ${d.synced ?? 0} events, ${d.emails ?? 0} emails, ${d.tasks ?? 0} tasks.`, "ok"); setTimeout(closeToolModal, 2500); }
      else this.status(left.length ? `Still disabled: ${left.map(k => names[k]).join(", ")} — Google may need a few more minutes.` : "✗ " + ((d && d.error) || "sync failed"), "bad");
    });
  },
  status(t, cls = "") { const s = document.getElementById("gs-status"); if (s) { s.textContent = t; s.className = "gs-status " + cls; } },
  async upload(f) {
    if (f.size > 20000) return this.status("That file is too large to be an OAuth client JSON.", "bad");
    const content = await f.text();
    const d = await (await fetch("/api/google/credentials", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ content }) })).json();
    if (!d.ok) return this.status("✗ " + (d.error || "rejected"), "bad");
    document.getElementById("gs-drop-txt").textContent = `✓ ${f.name}`;
    document.getElementById("gs-connect").disabled = false;
    this.status(`✓ ${d.client_type} client stored${d.project ? " for project " + d.project : ""}. Now sign in.`, "ok");
  },
  async connect() {
    this.status("Opening Google sign-in in your browser… approve, then come back here.", "");
    document.getElementById("gs-connect").disabled = true;
    const d = await GoogleConnect.run();
    if (d && d.ok) { this.status(`✓ Connected${d.account ? " as " + d.account : ""} — ${d.synced ?? 0} events, ${d.emails ?? 0} emails, ${d.tasks ?? 0} tasks.`, "ok"); setTimeout(closeToolModal, 2500); }
    else { this.status("✗ " + ((d && d.error) || "sign-in did not complete") , "bad"); document.getElementById("gs-connect").disabled = false; }
  },
};
var GoogleConnect = { async run() {
  try {
    const d = await (await fetch("/api/calendar/connect", { method: "POST" })).json();
    if (d.ok) {
      const cals = (d.calendars || []).length;
      logEvent(`<span class="tag">[google]</span> ${d.reused ? "already signed in — re-synced" : "connected ✓"}`
        + `${d.account ? " as " + escapeHTML(d.account) : ""} — ${d.synced ?? 0} events from ${cals} calendar${cals === 1 ? "" : "s"}`
        + ` · ${d.emails ?? 0} emails · ${d.tasks ?? 0} tasks`);
      const b = $("#gcal-btn"); if (b && d.account) b.title = `Google: ${d.account} — click to re-sync`;
      refreshAgenda();
    } else logEvent(`<span class="tag">[google]</span> ${escapeHTML(d.error || "connect failed")}`, "warn");
    return d;
  } catch (e) { logEvent("google connect failed: " + escapeHTML(e.message), "error"); return { ok: false, error: e.message }; }
} };

$("#gcal-btn")?.addEventListener("click", async () => {
  // no OAuth client yet → guided setup; APIs disabled → one-click enable
  // panel; otherwise sign in / re-sync directly
  try {
    const s = await (await fetch("/api/google/setup")).json();
    if (!s.credentials_present) return GoogleSetup.open();
    if (s.next === "enable_apis") return GoogleSetup.openEnable(s.api_issues);
  } catch (e) {}
  logEvent('<span class="tag">[google]</span> signing in / syncing — check your browser if Google asks…');
  await GoogleConnect.run();
});
/* ═══ SESSION TRACKING (vision) ══════════════════════ */

let sessionStart = null;
function updateSessionVal() {
  const el = $("#session-val"); if (!el) return;
  const present = Presence.state === "active" || Presence.state === "idle";
  if (present && !sessionStart) sessionStart = Date.now();
  if (!present) sessionStart = null;
  if (sessionStart) {                       // live camera session
    const m = Math.floor((Date.now() - sessionStart) / 60000);
    el.textContent = m >= 60 ? `LIVE ${Math.floor(m / 60)}H ${m % 60}M` : `LIVE ${m}M`;
    return;
  }
  // camera off → show today's REAL tracked presence from operator memory
  const mins = (lastMemorySnap && lastMemorySnap.active_minutes_today) || 0;
  el.textContent = mins ? `TODAY ${Math.floor(mins / 60)}H ${mins % 60}M` : "STANDBY";
}
setInterval(updateSessionVal, 5000); updateSessionVal();

/* ═══ PROCESS MONITOR + NETWORK TRAFFIC ══════════════ */

let trafficChart = null;
function ensureTraffic() {
  if (trafficChart || typeof Chart === "undefined") return;
  const el = document.getElementById("traffic-chart"); if (!el) return;
  trafficChart = new Chart(el, {
    type: "line",
    data: { labels: [], datasets: [
      { data: [], borderColor: "#00d9ff", backgroundColor: "rgba(0,217,255,0.12)",
        borderWidth: 1.4, fill: true, tension: 0.3, pointRadius: 0 },
      { data: [], borderColor: "#ff7a00", backgroundColor: "rgba(255,122,0,0.10)",
        borderWidth: 1.4, fill: true, tension: 0.3, pointRadius: 0 },
    ]},
    options: {
      responsive: true, maintainAspectRatio: false, animation: false,
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      scales: {
        x: { display: false },
        y: { min: 0, ticks: { color: "#6b94b4", font: { size: 8, family: "Share Tech Mono" }, maxTicksLimit: 4 },
             grid: { color: "rgba(13,58,90,0.3)" } },
      },
    },
  });
}
function pushTraffic(up, down) {
  ensureTraffic(); if (!trafficChart) return;
  const d = trafficChart.data;
  d.labels.push(""); d.datasets[0].data.push(up); d.datasets[1].data.push(down);
  if (d.labels.length > 90) { d.labels.shift(); d.datasets[0].data.shift(); d.datasets[1].data.shift(); }
  trafficChart.update("none");
}

async function refreshProcs() {
  try {
    const r = await fetch("/api/processes"); const d = await r.json();
    window._lastProcs = d;
    const host = $("#proc-list"); if (!host) return;
    // show as many real processes as the card has room for (5–12)
    const fit = Math.max(5, Math.min(12, Math.floor((host.clientHeight || 120) / 22)));
    const rows = (d.top_cpu || []).slice(0, fit);
    if (!rows.length) return;
    const maxc = Math.max(...rows.map(p => p.cpu), 1);
    const sp = $("#st-proc");
    if (sp && rows[0]) sp.textContent = `${Math.round(rows[0].cpu)}%`;
    // real GPU utilization (nvidia-smi); N/A on machines without one
    const gv = $("#res-gpu"); const gb = document.querySelector(".res-fill.gpu");
    if (gv) {
      if (d.gpu == null) { gv.textContent = "N/A"; if (gb) gb.style.width = "0%"; }
      else { gv.textContent = `${Math.round(d.gpu)}%`; if (gb) gb.style.width = `${Math.min(100, d.gpu)}%`; }
    }
    host.innerHTML = rows.map((p, i) => `
      <div class="proc-row" data-i="${i}" role="button" tabindex="0" title="Process detail">
        <span class="proc-name">${escapeHTML(p.name)}${p.count > 1 ? " ×" + p.count : ""}</span>
        <span class="proc-cpu">${p.cpu.toFixed(0)}%</span>
        <span class="proc-mem">${p.mem_mb >= 1024 ? (p.mem_mb / 1024).toFixed(1) + " GB" : p.mem_mb.toFixed(0) + " MB"}</span>
        <span class="proc-bar"><i style="width:${Math.min(100, p.cpu / maxc * 100)}%"></i></span>
      </div>`).join("");
  } catch (e) {}
}
refreshProcs();
setInterval(refreshProcs, 6000);

/* ═══ INTERACTIVE LAYER — modals, scanners, model manager ═══ */

let lastMetrics = {};

function makeInteractive(el, fn, label) {
  if (!el) return;
  el.setAttribute("tabindex", "0");
  el.setAttribute("role", "button");
  if (label) el.title = label;
  el.addEventListener("click", fn);
  el.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fn(); }
  });
}

// every open bumps the sequence, so a slow async fill can tell it was superseded
window._mSeq = 0;
function openCustomModal(title, sub, iconSvg, bodyHTML) {
  window._mSeq++;
  const modal = $("#tool-modal"); if (!modal) return;
  $("#modal-title").textContent = title;
  $("#modal-sub").textContent = sub;
  $("#modal-icon").innerHTML = iconSvg ||
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>';
  $("#modal-body").innerHTML = bodyHTML;
  modal.hidden = false;
}

async function openProcModal(kind) {
  openCustomModal(
    kind === "cpu" ? "PROCESS MONITOR" : "MEMORY SCANNER",
    kind === "cpu" ? "TOP CPU CONSUMERS · LIVE" : "TOP MEMORY CONSUMERS · LIVE",
    null, '<div style="color:var(--text-dim);font-style:italic">scanning…</div>');
  const seq = window._mSeq;
  try {
    const d = await (await fetch("/api/processes")).json();
    if (seq !== window._mSeq) return;
    const rows = (kind === "cpu" ? d.top_cpu : d.top_mem) || [];
    const max = Math.max(...rows.map(p => kind === "cpu" ? p.cpu : p.mem_mb), 1);
    $("#modal-body").innerHTML = '<div class="mb-list">' + rows.map(p => {
      const v = kind === "cpu" ? p.cpu : p.mem_mb;
      const vs = kind === "cpu" ? p.cpu.toFixed(1) + "%"
        : (p.mem_mb >= 1024 ? (p.mem_mb / 1024).toFixed(2) + " GB" : p.mem_mb.toFixed(0) + " MB");
      return `<div class="mb-row"><strong>${escapeHTML(p.name)}${p.count > 1 ? " ×" + p.count : ""}</strong> — ${vs}
        <div class="proc-bar" style="margin-top:4px"><i style="width:${Math.min(100, v / max * 100)}%"></i></div></div>`;
    }).join("") + "</div>";
  } catch (e) {
    $("#modal-body").innerHTML = `<div style="color:var(--error)">scan failed: ${escapeHTML(e.message)}</div>`;
  }
}

function openDiskModal() {
  const dsk = lastMetrics.disk ?? 0;
  openCustomModal("DISK SCANNER", "STORAGE · C:\\ VOLUME", null, `
    <div class="mb-grid">
      <div class="mb-stat"><span class="lbl">USED</span><span class="val ${dsk > 90 ? "warn" : ""}">${dsk.toFixed ? dsk.toFixed(1) : dsk}%</span></div>
      <div class="mb-stat"><span class="lbl">STATUS</span><span class="val ${dsk > 92 ? "warn" : "ok"}">${dsk > 92 ? "CRITICAL" : dsk > 85 ? "FILLING" : "HEALTHY"}</span></div>
    </div>
    <div class="mb-list">
      <div class="mb-row">${dsk > 90
        ? "Storage critically full. Run Windows Disk Cleanup, empty Downloads, or archive old projects — update installs may fail below 5% free."
        : "Storage within operating tolerance. No action required."}
        <div class="mb-row-meta">LIVE · ${new Date().toTimeString().slice(0, 8)}</div></div>
    </div>`);
}

function openVoiceEngineModal() {
  const eng = $("#vr-engine")?.textContent || "—";
  const mic = $("#vr-mic")?.textContent || "—";
  const tts = $("#sp-tts .sp-val")?.textContent || "—";
  openCustomModal("VOICE ENGINE", "STT · WAKE PHRASES · TTS", null, `
    <div class="mb-grid">
      <div class="mb-stat"><span class="lbl">RECOGNITION</span><span class="val ok">${escapeHTML(eng)}</span></div>
      <div class="mb-stat"><span class="lbl">MICROPHONES</span><span class="val">${escapeHTML(mic)}</span></div>
      <div class="mb-stat"><span class="lbl">TTS OUTPUT</span><span class="val ok">${escapeHTML(tts)}</span></div>
      <div class="mb-stat"><span class="lbl">STT MODEL</span><span class="val">WHISPER SMALL</span></div>
    </div>
    <div class="mb-list">
      <div class="mb-row">Wake phrases: Hey Jarvis · Hey Stark/Tony · Hey Cap/Captain · Hey Widow/Natasha · Hey Hawkeye/Clint · Hey Hulk/Bruce · Hey Thor · Hey Vision
        <div class="mb-row-meta">FUZZY MATCH · INDIAN-ENGLISH BIASED</div></div>
      <div class="mb-row"><button class="quick-btn" id="tts-test-btn" style="width:auto;padding:.45rem .9rem">RUN SPEAKER TEST</button></div>
    </div>`);
  $("#tts-test-btn")?.addEventListener("click", () => {
    fetch("/api/speak", { method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ text: "Voice engine test. All channels operational, sir." }) }).catch(() => {});
  });
}

async function openAgentModal(name) {
  openCustomModal((name || "").toUpperCase(), "AGENT OPERATIONS FILE", null,
    '<div style="color:var(--text-dim);font-style:italic">pulling agent telemetry…</div>');
  const seq = window._mSeq;
  try {
    const d = await (await fetch("/api/status")).json();
    if (seq !== window._mSeq) return;
    const a = (d.agents || []).find(x => x.name === name);
    if (!a) throw new Error("agent not found");
    $("#modal-title").textContent = a.codename;
    $("#modal-sub").textContent = a.role.toUpperCase();
    const hist = (a.history || []).slice(-4).reverse().map(h =>
      `<div class="mb-row">${escapeHTML((h.a || "").slice(0, 160))}
        <div class="mb-row-meta">${new Date(h.ts * 1000).toTimeString().slice(0, 5)} · RE: ${escapeHTML((h.q || "").slice(0, 60))}</div></div>`).join("");
    $("#modal-body").innerHTML = `
      <div class="mb-grid">
        <div class="mb-stat"><span class="lbl">STATUS</span><span class="val ${a.status === "idle" ? "ok" : "warn"}">${escapeHTML(a.status.toUpperCase())}</span></div>
        <div class="mb-stat"><span class="lbl">CONFIDENCE</span><span class="val">${a.confidence}%</span></div>
        <div class="mb-stat"><span class="lbl">CURRENT TASK</span><span class="val">${escapeHTML((a.current_task || "—").slice(0, 22))}</span></div>
        <div class="mb-stat"><span class="lbl">ACTIONS DONE</span><span class="val">${a.actions_completed}</span></div>
      </div>
      <div class="mb-list">${hist || '<div class="mb-row">no recent actions logged.</div>'}</div>`;
  } catch (e) {
    $("#modal-body").innerHTML = `<div style="color:var(--error)">${escapeHTML(e.message)}</div>`;
  }
}

/* — LLM SWITCH: provider registry + local Ollama models (llm_providers.py) — */
async function openModelManager() {
  openCustomModal("LLM SWITCH", "CHOOSE THE BRAIN · PLUG IN ANY OPENAI-COMPATIBLE MODEL",
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2l8 4.5v9L12 20l-8-4.5v-9z"/><circle cx="12" cy="11" r="3" fill="currentColor"/></svg>',
    '<div style="color:var(--text-dim);font-style:italic">querying providers…</div>');
  const seq = window._mSeq;
  try {
    const [m, p] = await Promise.all([
      fetch("/api/models").then(r => r.json()),
      fetch("/api/llm/providers").then(r => r.json())]);
    if (seq !== window._mSeq) return;           // the operator opened something else meanwhile
    renderModelManager(m, p);
  } catch (e) {
    $("#modal-body").innerHTML = `<div style="color:var(--error)">provider query failed: ${escapeHTML(e.message)}</div>`;
  }
}
const _llmPost = (url, body) => fetch(url, { method: "POST",
  headers: { "content-type": "application/json" }, body: JSON.stringify(body || {}) }).then(r => r.json());

function renderModelManager(d, reg) {
  const body = $("#modal-body"); if (!body) return;
  const provs = reg.providers || [];
  const anyLocked = provs.some(p => p.locked);
  let html = `<div class="mb-row" style="margin-bottom:.5rem">ACTIVE: <b style="color:var(--success)">${escapeHTML((provs.find(p => p.active) || {}).name || reg.active)}</b>
    — every reply uses it; if it fails BUCS falls back to Claude → local → rules, so it never goes silent.</div>`;
  if (anyLocked) html += `<div class="llm-lock-note">🔒 Cloud brains are a <b>Pro</b> feature on this install — local models stay free. <a href="#" data-act="licence">Activate a licence →</a></div>`;
  html += `<div class="model-section">— PROVIDERS</div><div class="llm-list">`;
  for (const p of provs) {
    const h = p.health;
    const health = h ? (h.ok ? `<span class="llm-ok">✓ ${h.latency_ms} ms</span>`
      : `<span class="llm-bad" title="${escapeHTML(h.reply || "")}">✕ failed</span>`) : "";
    const avail = p.available === false ? '<span class="llm-bad">offline</span>' : "";
    const spec = [p.tier.toUpperCase(), p.model, p.api_key ? "key " + p.api_key : ""].filter(Boolean).join(" · ");
    html += `<div class="llm-row${p.active ? " selected" : ""}${p.locked ? " locked" : ""}" data-id="${escapeHTML(p.id)}">
      <div class="llm-main">
        <span class="mr-name">${escapeHTML(p.name)}</span>
        <span class="mr-spec">${escapeHTML(spec)}</span>
        <span class="llm-meta">${health} ${avail}</span>
      </div>
      <div class="llm-acts">
        ${p.active ? '<span class="mr-status loaded">ACTIVE</span>'
          : `<button class="cmd-btn" data-act="use" ${p.locked ? 'disabled title="needs a Pro licence"' : ""}>${p.locked ? "🔒 PRO" : "USE"}</button>`}
        <button class="ghost-btn" data-act="test" title="send a real test prompt">TEST</button>
        ${p.builtin ? "" : '<button class="ghost-btn" data-act="edit" title="edit">✎</button><button class="ghost-btn" data-act="del" title="remove">×</button>'}
      </div></div>`;
  }
  html += `</div>`;

  // add / edit form — presets fill base URL + model; keys are stored locally, shown masked
  const presets = reg.presets || {};
  html += `<div class="model-section">— CONNECT ANOTHER MODEL</div>
    <form class="llm-form" id="llm-form" autocomplete="off">
      <select id="llm-preset">${Object.entries(presets).map(([k, v]) => `<option value="${k}">${escapeHTML(v.name)}</option>`).join("")}</select>
      <input id="llm-name" placeholder="display name" maxlength="40" required/>
      <input id="llm-url" placeholder="base URL (…/v1)" required/>
      <input id="llm-model" placeholder="model id" required/>
      <input id="llm-key" type="password" placeholder="API key (stored on this machine only)"/>
      <input id="llm-id" type="hidden"/>
      <div class="llm-form-acts"><button class="cmd-btn" type="submit">SAVE + TEST</button><span class="llm-msg" id="llm-msg"></span></div>
    </form>
    <div class="mb-row-meta">Any OpenAI-compatible API works: OpenAI, Anthropic, Gemini, Groq, OpenRouter, DeepSeek, Mistral, Together, LM Studio, vLLM. Remote endpoints must use https.</div>`;

  // local Ollama models (picks the model the "Ollama" provider uses)
  const locals = d.local || [];
  html += `<div class="model-section">— LOCAL OLLAMA MODELS · ${escapeHTML(d.endpoint || "")}</div>`;
  if (!locals.length) html += `<div class="mb-row">no local models detected — install one with <b style="color:var(--accent)">ollama pull llama3.2</b>. <div class="mb-row-meta">ENDPOINT OFFLINE — run \`ollama serve\`</div></div>`;
  for (const m of locals) {
    const mspec = [m.param_size, m.quant, m.size_gb ? m.size_gb + " GB" : null].filter(Boolean).join(" · ") || (m.family || "local model");
    const isActive = d.force_local && m.name === d.selected;
    html += `<div class="model-row${isActive ? " selected" : ""}" data-model="${escapeHTML(m.name)}" tabindex="0" role="button">
      <span class="mr-name">${escapeHTML(m.name)}</span><span class="mr-spec">${escapeHTML(mspec.toUpperCase())}</span>
      <span class="mr-status ${isActive ? "loaded" : "available"}">${isActive ? "ACTIVE" : "USE"}</span></div>`;
  }
  body.innerHTML = html;

  const reload = async () => {
    try {
      const [m2, p2] = await Promise.all([fetch("/api/models").then(r => r.json()), fetch("/api/llm/providers").then(r => r.json())]);
      renderModelManager(m2, p2);
    } catch (e) {}
    onBrainChanged(true);                        // every other brain display (this modal is fresh)
  };
  const busy = async (fn) => { _llmBusy++; try { return await fn(); } finally { _llmBusy = Math.max(0, _llmBusy - 1); } };
  const form = $("#llm-form"), msg = $("#llm-msg");
  const fill = (k) => {
    const v = presets[k] || {};
    $("#llm-name").value = k === "custom" ? "" : (v.name || "");
    $("#llm-url").value = v.base_url || ""; $("#llm-model").value = v.model || ""; $("#llm-id").value = "";
    $("#llm-key").placeholder = v.key ? "API key (required · stored on this machine only)" : "API key (optional)";
  };
  $("#llm-preset").addEventListener("change", e => fill(e.target.value));
  fill($("#llm-preset").value);
  form.addEventListener("submit", (e) => {
    e.preventDefault(); msg.textContent = "saving…";
    busy(async () => {
      const r = await _llmPost("/api/llm/providers", { name: $("#llm-name").value, base_url: $("#llm-url").value,
        model: $("#llm-model").value, api_key: $("#llm-key").value || null, id: $("#llm-id").value || null })
        .catch(err => ({ ok: false, error: err.message }));
      if (!r.ok) { msg.textContent = r.error || "refused"; return; }
      msg.textContent = "saved — testing…";
      const t = await _llmPost(`/api/llm/providers/${encodeURIComponent(r.id)}/test`).catch(err => ({ ok: false, error: err.message }));
      msg.textContent = t.ok ? `✓ reachable · ${t.latency_ms} ms` : `✕ ${t.reply || t.error || "no reply"}`;
      await new Promise(res => setTimeout(res, 1200));          // let the operator read the result
      reload();
    });
  });
  body.querySelector('[data-act="licence"]')?.addEventListener("click", (e) => {
    e.preventDefault(); $("#tool-modal").hidden = true;
    $("#license-card")?.scrollIntoView({ behavior: "smooth", block: "center" });
    $("#lic-key")?.focus();
  });
  body.querySelectorAll(".llm-row").forEach(row => row.addEventListener("click", async (e) => {
    const b = e.target.closest("button[data-act]"); if (!b) return;
    const id = row.dataset.id, act = b.dataset.act;
    const fail = err => ({ ok: false, error: err.message });
    if (act === "use") {
      b.textContent = "SWITCHING…";
      const r = await busy(() => _llmPost("/api/llm/active", { id }).catch(fail));
      if (!r.ok) {
        b.textContent = "REFUSED"; b.title = r.error || "";
        logEvent(`<span class="tag">[llm]</span> ${escapeHTML(r.error || "switch refused")}`, "warn");
        return;
      }
      reload();
    } else if (act === "test") {
      b.textContent = "…";
      await busy(() => _llmPost(`/api/llm/providers/${encodeURIComponent(id)}/test`).catch(fail));
      reload();
    } else if (act === "del") {
      if (!confirm("Remove this provider? Its stored API key is deleted too.")) return;
      const r = await busy(() => _llmPost(`/api/llm/providers/${encodeURIComponent(id)}/delete`).catch(fail));
      if (r.ok === false && r.error) logEvent(`<span class="tag">[llm]</span> ${escapeHTML(r.error)}`, "warn");
      reload();
    } else if (act === "edit") {
      const p = provs.find(x => x.id === id) || {};
      $("#llm-preset").value = "custom"; $("#llm-name").value = p.name || ""; $("#llm-url").value = p.base_url || "";
      $("#llm-model").value = p.model || ""; $("#llm-id").value = id;
      $("#llm-key").placeholder = p.api_key ? `keep ${p.api_key} (leave blank)` : "API key (optional)";
      $("#llm-name").focus();
    }
  }));
  body.querySelectorAll(".model-row[data-model]").forEach(r => {
    const pick = async () => {
      r.querySelector(".mr-status").textContent = "SWITCHING…";
      const res = await busy(() => _llmPost("/api/models/select", { model: r.dataset.model }).catch(err => ({ ok: false, error: err.message })));
      if (!res.ok) logEvent(`<span class="tag">[llm]</span> ${escapeHTML(res.error || "switch refused")}`, "warn");
      await reload();
    };
    r.addEventListener("click", pick);
    r.addEventListener("keydown", (e) => { if (e.key === "Enter") pick(); });
  });
}
makeInteractive($("#model-row"), openModelManager, "Click to switch the AI brain or connect another model");

/* — scanner tiles — */
function updateScanTiles(m) {
  const set = (id, v, level) => {
    const el = $(id); if (!el) return;
    el.textContent = v;
    const tile = el.closest(".scan-tile");
    if (tile) { tile.classList.toggle("hot", level === "hot"); tile.classList.toggle("warm", level === "warm"); }
  };
  set("#st-net", `${Math.round(m.net_down)}↓`, m.net_down > 2000 ? "warm" : "");
  set("#st-pkt", `${Math.round(m.net_up + m.net_down)}/s`, "");
  set("#st-mem", `${Math.round(m.mem)}%`, m.mem > 92 ? "hot" : m.mem > 85 ? "warm" : "");
}
document.querySelectorAll(".scan-tile").forEach(t => {
  t.addEventListener("click", () => {
    const k = t.dataset.scan;
    if (k === "network" || k === "packets") openToolModal("network-activity");
    else if (k === "threat") openToolModal("threat-scanner");
    else if (k === "memory") openProcModal("mem");
    else if (k === "process") openProcModal("cpu");
    else if (k === "llm") openModelManager();
  });
});

/* — status pills, diag cards, agent cards: clickable + keyboard — */
makeInteractive($("#sp-brain"), () => openToolModal("ai-diagnostics"), "Brain — click for AI diagnostics");
makeInteractive($("#sp-tts"), openVoiceEngineModal, "TTS — click for voice engine status");
makeInteractive($("#sp-voice"), openVoiceEngineModal, "Voice — click for voice engine status");
makeInteractive($("#sp-news"), () => execDashCmd("news"), "Feed — click to jump to World Feed");
{
  const cards = document.querySelectorAll(".diag-strip .strip-card");
  const acts = [() => openProcModal("cpu"), () => openProcModal("mem"), openDiskModal,
                () => openToolModal("network-activity")];
  const labels = ["CPU — click for top processes", "Memory — click for top consumers",
                  "Disk — click for storage detail", "Network — click for traffic detail"];
  cards.forEach((c, i) => makeInteractive(c, acts[i] || (() => {}), labels[i]));
}
$("#avengers-list")?.addEventListener("click", (e) => {
  const card = e.target.closest(".agent-card");
  if (card) openAgentModal(card.dataset.agent);
});
$("#avengers-list")?.addEventListener("keydown", (e) => {
  if (e.key !== "Enter") return;
  const card = e.target.closest(".agent-card");
  if (card) openAgentModal(card.dataset.agent);
});

/* — voice command reference: click-to-run + engine status — */
document.querySelectorAll(".vr-row[data-cmd]").forEach(b => {
  b.addEventListener("click", () => {
    const inp = $("#ask-input"); if (!inp) return;
    inp.value = b.dataset.cmd; inp.focus();
    $("#ask-form").requestSubmit();   // same engine pipeline as typing / voice
  });
});
async function checkMic() {
  const el = $("#vr-mic"); if (!el) return;
  try {
    const devs = await navigator.mediaDevices.enumerateDevices();
    const mics = devs.filter(d => d.kind === "audioinput");
    el.textContent = mics.length ? `${mics.length} DEVICE${mics.length > 1 ? "S" : ""}` : "NONE FOUND";
    el.className = mics.length ? "ok" : "dim";
  } catch (e) { el.textContent = "N/A"; el.className = "dim"; }
}
checkMic();
try { navigator.mediaDevices.addEventListener("devicechange", checkMic); } catch (e) {}

/* ═══ OPERATOR MEMORY + VISION INTELLIGENCE ══════════ */

let memRefreshTs = 0;

function fmtClock(ts) {
  return new Date(ts * 1000).toTimeString().slice(0, 5);
}

function renderMemory(d) {
  // — recognition card —
  const st = $("#recog-status"), nm = $("#recog-name"),
        sk = $("#recog-sketch"), meta = $("#recog-meta");
  if (st && !st.dataset.liveHold) {
    if (d.enrolled) {
      st.textContent = "ENROLLED"; st.className = "recog-status enrolled";
    } else {
      st.textContent = "NOT ENROLLED"; st.className = "recog-status dim";
    }
  }
  if (nm) nm.textContent = d.enrolled
    ? `operator: ${d.name || "unnamed"} · enrolled ${d.enrolled_at ? new Date(d.enrolled_at * 1000).toLocaleDateString() : ""}`
    : "enable camera + AI ◍, then enroll";
  if (sk) sk.textContent = d.appearance ||
    "JARVIS stores a short written sketch of you — words in a JSON file you own, never face data.";
  if (meta) meta.textContent =
    `guest sightings: ${d.guest_sightings || 0} · syntheses: ${d.syntheses || 0} · memory file: operator_memory.json`;

  // — observation log (server-driven, consistent across refreshes) —
  const log = $("#obslog");
  if (log) {
    const obs = d.observations || [];
    log.innerHTML = obs.length ? obs.map(o => `
      <div class="obs-item ${o.who || "unknown"}">
        <span class="ob-who">${escapeHTML((o.who || "?").toUpperCase())}</span>
        <span class="ob-text">${escapeHTML(o.text)}</span>
        <span class="ob-time">${fmtClock(o.ts)}</span>
      </div>`).join("")
      : '<div class="tf-empty">no observations yet — turn on AI ◍ vision</div>';
  }

  // — activity timeline —
  const bars = $("#atl-bars");
  if (bars) {
    const hours = d.hourly_activity || new Array(24).fill(0);
    const max = Math.max(...hours, 1);
    const nowH = new Date().getHours();
    bars.innerHTML = hours.map((v, h) =>
      `<div class="atl-bar${h === nowH ? " now" : ""}" title="${h}:00 — ${v} min" style="height:${v ? Math.max(6, v / max * 100) : 3}%"></div>`
    ).join("");
  }
  const setT = (id, v) => { const el = $(id); if (el) el.textContent = v; };
  const mins = d.active_minutes_today || 0;
  setT("#atl-active", mins >= 60 ? `${Math.floor(mins / 60)}H ${mins % 60}M` : `${mins}M`);
  setT("#atl-arrivals", d.arrivals_today ?? 0);
  setT("#atl-sessions", d.sessions_total ?? 0);

  // — facts —
  const fc = $("#mem-count"); if (fc) fc.textContent = (d.facts || []).length;
  const facts = $("#mem-facts");
  if (facts) {
    facts.innerHTML = (d.facts || []).length ? d.facts.map(f => `
      <div class="mem-fact${f.source === "ai-synthesis" ? " ai" : ""}">
        ${escapeHTML(f.text)}
        <div class="mf-src">${escapeHTML((f.source || "").toUpperCase())} · ${new Date(f.ts * 1000).toLocaleDateString()}</div>
      </div>`).join("")
      : '<div class="tf-empty">memory is empty — it fills as JARVIS observes you</div>';
  }
}

async function refreshMemory(force = false) {
  const now = Date.now();
  if (!force && now - memRefreshTs < 2000) return;   // throttle WS bursts
  memRefreshTs = now;
  try {
    const d = await (await fetch("/api/memory")).json();
    renderMemory(d);
    try { lastMemorySnap = d; updateLiveOps(); } catch (e2) {}
  } catch (e) {}
}
refreshMemory(true);
setInterval(() => refreshMemory(true), 120000);

// live recognition status from vision results (overrides for 60s, then
// falls back to the enrolled/not-enrolled baseline)
function setRecogLive(who) {
  const st = $("#recog-status"); if (!st || !who || who === "unknown") return;
  const map = {
    operator: ["OPERATOR VERIFIED", "operator"],
    guest: ["UNKNOWN PERSON", "guest"],
    multiple: ["MULTIPLE PEOPLE", "multiple"],
    none: ["NOBODY IN FRAME", "dim"],
  };
  const m = map[who]; if (!m) return;
  st.textContent = m[0]; st.className = "recog-status " + m[1];
  st.dataset.liveHold = "1";
  clearTimeout(st._holdTimer);
  st._holdTimer = setTimeout(() => { delete st.dataset.liveHold; refreshMemory(true); }, 60000);
}

// — enroll ("remember me") —
$("#btn-enroll")?.addEventListener("click", async () => {
  const btn = $("#btn-enroll");
  if (!camStream || camVideo.readyState < 2) {
    logEvent('<span class="tag">[memory]</span> enable the camera first, then enroll', "warn");
    return;
  }
  btn.disabled = true; btn.textContent = "◍ LOOKING…";
  try {
    const cv = document.createElement("canvas");
    cv.width = 480; cv.height = 360;
    cv.getContext("2d").drawImage(camVideo, 0, 0, 480, 360);
    const frame = cv.toDataURL("image/jpeg", 0.7);
    const name = ($("#enroll-name")?.value || "").trim();
    const r = await fetch("/api/memory/enroll", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ frame, name: name || null }),
    });
    const d = await r.json();
    if (d.ok) {
      logEvent('<span class="tag">[memory]</span> enrolled ✓ — JARVIS will recognize you');
      refreshMemory(true);
    } else {
      logEvent(`<span class="tag">[memory]</span> enroll failed: ${escapeHTML(d.error || "")}`, "warn");
    }
  } catch (e) {
    logEvent("enroll failed: " + escapeHTML(e.message), "error");
  } finally {
    btn.disabled = false; btn.textContent = "◍ REMEMBER ME";
  }
});

// — forget (wipe memory file) —
$("#btn-forget")?.addEventListener("click", async () => {
  if (!confirm("Wipe operator_memory.json? JARVIS forgets everything about you.")) return;
  try {
    await fetch("/api/memory/forget", { method: "POST" });
    refreshMemory(true);
  } catch (e) {}
});

// — teach a fact manually —
$("#mem-add-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const inp = $("#mem-add-input");
  const text = (inp?.value || "").trim();
  if (!text) return;
  inp.value = "";
  try {
    await fetch("/api/memory/fact", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ text }),
    });
    logEvent(`<span class="tag">[memory]</span> learned: ${escapeHTML(text)}`);
    refreshMemory(true);
  } catch (e2) {}
});

// — "what do you know about me?" (spoken) —
$("#btn-mem-speak")?.addEventListener("click", async () => {
  try {
    const d = await (await fetch("/api/memory/speak", { method: "POST" })).json();
    if (d.summary) logEvent(`<span class="tag">[memory]</span> ${escapeHTML(d.summary)}`);
  } catch (e) {}
});

/* ═══ REAL-DATA BRIDGES — no mock anywhere ═══════════
   Live Operations, personal Notes (disk-persisted), Service Grid, and the
   orb-flank readouts all bind to real endpoints/telemetry. */


function updateLiveOps() {
  const set = (id, txt, barId, pct) => {
    const el = $(id); if (el) el.textContent = txt;
    const b = $(barId); if (b) b.style.width = Math.max(0, Math.min(100, pct)) + "%";
  };
  if (lastAgenda) {
    const n = (lastAgenda.intel || {}).meetings_today ?? (lastAgenda.events || []).length;
    set("#ops-meetings", String(n), "#ops-meetings-bar", n ? Math.min(100, n / 8 * 100) : 0);
  }
  if (lastThreat) {
    const soc = lastThreat.soc || {};
    const total = (lastThreat.events || []).length || 0;
    set("#ops-threats", `${soc.resolved ?? 0}/${total}`, "#ops-threats-bar",
        total ? (soc.resolved || 0) / total * 100 : 0);
  }
  if (lastMemorySnap) {
    const mins = lastMemorySnap.active_minutes_today || 0;
    const txt = mins >= 60 ? `${Math.floor(mins / 60)}h ${mins % 60}m` : `${mins}m`;
    set("#ops-presence", txt, "#ops-presence-bar", mins / 480 * 100);
  }
}

/* — personal notes (notes.json on disk) — */
async function refreshNotes() {
  try {
    const d = await (await fetch("/api/notes")).json();
    const host = $("#notes-list"); if (!host) return;
    const notes = d.notes || [];
    host.innerHTML = notes.length ? notes.map(n => `
      <div class="note" data-id="${n.id}">
        <div class="note-text">${escapeHTML(n.text)}
          <span class="note-del" title="delete">×</span></div>
        <div class="note-ts">${new Date(n.ts * 1000).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</div>
      </div>`).join("")
      : '<div class="tf-empty">no notes yet — add one below</div>';
  } catch (e) {}
}
refreshNotes();
$("#note-add-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const inp = $("#note-add-input");
  const text = (inp?.value || "").trim();
  if (!text) return;
  inp.value = "";
  try {
    const r = await (await fetch("/api/notes", { method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ text }) })).json();
    if (!r.ok) { inp.value = text; logEvent(`<span class="tag">[notes]</span> note not saved`, "warn"); }
    refreshNotes();
  } catch (e2) { inp.value = text; logEvent(`<span class="tag">[notes]</span> note not saved: ${escapeHTML(e2.message)}`, "warn"); }
});
$("#notes-list")?.addEventListener("click", async (e) => {
  const del = e.target.closest(".note-del"); if (!del) return;
  const id = del.closest(".note")?.dataset.id; if (!id) return;
  try {
    const r = await (await fetch(`/api/notes/${encodeURIComponent(id)}`, { method: "DELETE" })).json();
    if (!r.ok && r.error) logEvent(`<span class="tag">[notes]</span> ${escapeHTML(r.error)}`, "warn");
    refreshNotes();
  } catch (e2) {}
});

/* — service grid: real health of every integration — */
function setSvc(id, ok, label) {
  const row = $(id); if (!row) return;
  const dot = row.querySelector(".rr-dot"), st = row.querySelector(".rr-state");
  if (dot) dot.className = "rr-dot" + (ok ? " ok" : "");
  if (st) { st.textContent = label; st.className = "rr-state" + (ok ? " ok" : ""); }
}
async function pollServiceGrid() {
  try {
    const [sr, cr, mr] = await Promise.allSettled([
      fetch("/api/status").then(r => r.json()),
      fetch("/api/calendar/status").then(r => r.json()),
      fetch("/api/models").then(r => r.json()),
    ]);
    if (sr.status === "fulfilled") {
      const s = sr.value;
      setSvc("#svc-claude", s.brain_mode === "llm", s.brain_mode === "llm" ? "ONLINE" : "OFFLINE");
      setSvc("#svc-news", (s.news_count || 0) > 0, (s.news_count || 0) > 0 ? `${s.news_count} · ${s.news_source === "newsapi" ? "NEWSAPI" : "OPEN FEEDS"}` : "NO FEED");
    }
    if (cr.status === "fulfilled") {
      const c = cr.value;
      setSvc("#svc-gcal", !!c.connected,
             c.connected ? "SYNCED" : c.credentials_present ? "AUTH NEEDED" : "NO CREDS");
    }
    if (mr.status === "fulfilled") {
      const m = mr.value;
      setSvc("#svc-ollama", !!m.local_available,
             m.local_available ? (m.selected || "READY") : "OFFLINE");
    }
    setSvc("#svc-weather", lastWeatherOk === true, lastWeatherOk ? "LIVE" : "NO DATA");
  } catch (e) {}
}
pollServiceGrid();
setInterval(pollServiceGrid, 60000);

/* ═══ EXTRA INTERACTIVITY — clickable detail across the board ═══ */

function initExtraInteractions() {
  // Weather card → detail modal
  const wc = $("#weather-card");
  makeInteractive(wc, async () => {
    openCustomModal("HYDERABAD WEATHER", "OPEN-METEO · LIVE", null,
      '<div style="color:var(--text-dim);font-style:italic">fetching…</div>');
    try {
      const d = await (await fetch("/api/weather" + (userLat != null ? `?lat=${userLat}&lon=${userLon}` : ""))).json();
      $("#modal-body").innerHTML = `
        <div class="mb-grid">
          <div class="mb-stat"><span class="lbl">CONDITION</span><span class="val">${escapeHTML((d.label||"—").toUpperCase())}</span></div>
          <div class="mb-stat"><span class="lbl">TEMPERATURE</span><span class="val">${d.temp_c ?? "--"}°C</span></div>
          <div class="mb-stat"><span class="lbl">FEELS LIKE</span><span class="val">${d.feels_c ?? "--"}°C</span></div>
          <div class="mb-stat"><span class="lbl">HUMIDITY</span><span class="val">${d.humidity ?? "--"}%</span></div>
          <div class="mb-stat"><span class="lbl">WIND</span><span class="val">${d.wind_kmh != null ? Math.round(d.wind_kmh) : "--"} km/h</span></div>
          <div class="mb-stat"><span class="lbl">LOCATION</span><span class="val">${escapeHTML(d.city || "—")}</span></div>
        </div>`;
    } catch (e) { $("#modal-body").innerHTML = '<div style="color:var(--error)">weather unavailable</div>'; }
  }, "Weather detail");

  // Agenda items → event detail
  $("#agenda-list")?.addEventListener("click", (e) => {
    const item = e.target.closest(".agenda-item"); if (!item) return;
    const title = item.querySelector(".agenda-title")?.textContent || "Event";
    const time = item.querySelector(".agenda-time")?.textContent.trim() || "";
    const meta = item.querySelector(".agenda-meta")?.textContent || "";
    openCustomModal(title, "CALENDAR EVENT", null,
      `<div class="mb-grid"><div class="mb-stat"><span class="lbl">WHEN</span><span class="val">${escapeHTML(time)}</span></div></div>
       <div class="mb-list"><div class="mb-row">${escapeHTML(meta)}</div></div>`);
  });

  // Inbox items → email detail
  $("#inbox-list")?.addEventListener("click", (e) => {
    const item = e.target.closest(".inbox-item"); if (!item) return;
    const sender = item.querySelector(".inbox-sender")?.textContent || "";
    const subj = item.querySelector(".inbox-subject")?.textContent || "";
    const snip = item.querySelector(".inbox-snippet")?.textContent || "";
    openCustomModal(subj || "Email", "INBOX MESSAGE", null,
      `<div class="mb-list"><div class="mb-row"><b>From:</b> ${escapeHTML(sender)}</div>
       <div class="mb-row">${escapeHTML(snip)}</div></div>`);
  });

  // Service-grid rows → what each integration is + how to connect
  const svcInfo = {
    "svc-claude": ["CLAUDE CLI", "The cloud brain — powers agent replies, insights, and webcam vision. Set CLAUDE_BIN in .env."],
    "svc-ollama": ["OLLAMA · LOCAL AI", "On-device models for fully offline replies. Run `ollama serve` + `ollama pull`, then pick a model in the AI MODEL MANAGER."],
    "svc-gcal": ["GOOGLE CALENDAR + GMAIL", "Real events & mail (readonly). Click the G button by AGENDA to connect via OAuth."],
    "svc-news": ["NEWS FEED", "Live headlines from open feeds (BBC World, The Hindu, Al Jazeera, The Hacker News, Hacker News) every 10 min, no key needed. Optional NEWSAPI_KEY in .env switches to NewsAPI."],
    "svc-weather": ["WEATHER", "Live Hyderabad weather via Open-Meteo (no key needed)."],
  };
  Object.entries(svcInfo).forEach(([id, [t, desc]]) => {
    const row = $("#" + id);
    makeInteractive(row, () => {
      const state = row.querySelector(".rr-state")?.textContent || "—";
      openCustomModal(t, "SERVICE STATUS", null,
        `<div class="mb-grid"><div class="mb-stat"><span class="lbl">STATUS</span><span class="val">${escapeHTML(state)}</span></div></div>
         <div class="mb-list"><div class="mb-row">${escapeHTML(desc)}</div></div>`);
    }, t + " info");
  });

  // Live-operations & AI-ops cards → jump to their detailed rows
  makeInteractive($("#aiops-vision"), () => execDashCmd("camera"), "Vision — jump to operator view");
  makeInteractive($("#intel-readiness"), () => openSectionInfo("MISSION READINESS"), "Mission readiness: how it is computed");
  makeInteractive($(".bs-mission"), () => execDashCmd("agenda"), "Live ops — jump to agenda");
  makeInteractive($(".bs-threat"), () => bucsJump("#tic-matrix"), "Threats: jump to the threat matrix");
}
initExtraInteractions();

// ── websocket (self-healing) ─────────────────────────
let ws = null;
let wsLastMsg = 0;
let wsReconnecting = false;

function scheduleReconnect(reason) {
  if (window._bucsStopping) return;    // shut down / updating: the overlay owns the screen
  if (wsReconnecting) return;          // dedup: never stack reconnects
  wsReconnecting = true;
  $("#status-pill").classList.add("offline");
  $("#status-text").textContent = "RECONNECTING";
  try { LinkState.down(); } catch (e) {}
  try { if (ws) ws.close(); } catch (e) {}
  setTimeout(() => { wsReconnecting = false; connect(); }, 1200);
}

function connect() {
  try { ws = new WebSocket(`ws://${location.host}/ws`); }
  catch (e) { scheduleReconnect("ctor"); return; }
  ws.onopen = () => {
    wsLastMsg = Date.now();
    $("#status-pill").classList.remove("offline");
    $("#status-text").textContent = "ONLINE";
    try { LinkState.up(); } catch (e) {}
    logEvent('<span class="tag">[net]</span> uplink established');
    refreshPills();
    setPill("#sp-voice", "OFF", "warn");
    // broadcasts sent while the link was down are lost: re-read the shared settings once
    if (window._wsWasUp) {
      try { ConversationMode.load(); AudioCtl.load(); onBrainChanged(true); } catch (e) {}
      ["notes", "productivity", "enterprise", "decisions"].forEach(uiSyncRun);
    }
    window._wsWasUp = true;
  };
  ws.onclose = () => {
    logEvent('<span class="tag">[net]</span> uplink lost — reconnecting', "warn");
    scheduleReconnect("close");
  };
  ws.onerror = () => { try { ws.close(); } catch (e) {} };  // → triggers onclose
  ws.onmessage = (m) => {
    wsLastMsg = Date.now();
    try { handle(JSON.parse(m.data)); } catch (e) {}
  };
}

// Watchdog: server pushes metrics every ~2s. If nothing arrives for 12s the
// socket is half-dead (common under heavy CPU/disk load) — force a reconnect.
setInterval(() => {
  if (!ws) return;
  if (ws.readyState === WebSocket.OPEN && Date.now() - wsLastMsg > 12000) {
    logEvent('<span class="tag">[net]</span> link stalled — resetting', "warn");
    scheduleReconnect("watchdog");
  }
}, 4000);

function handle(msg) {
  switch (msg.type) {
    case "snapshot":
      renderAgents(msg.agents); break;
    case "net":
      applyNetSnapshot(msg);
      break;
    case "conversation":
      ConversationMode.set(!!msg.on);
      break;
    case "dev":
    case "dev-open":
      DevPanel.on(msg);
      break;
    case "mic": {
      if (document.getElementById("voice-orb")?.classList.contains("listening")) OrbMic.set(msg.peak, msg.trigger);
      // log scale so quiet speech is visible: 100 → 0 %, 32767 → 100 %
      const pct = v => Math.max(0, Math.min(100, (Math.log10(Math.max(v, 100)) - 2) / (Math.log10(32767) - 2) * 100));
      const f = document.getElementById("mm-fill"), t = document.getElementById("mm-trig"), st = document.getElementById("mm-state");
      if (f) f.style.width = pct(msg.peak) + "%";
      if (t) t.style.left = pct(msg.trigger) + "%";
      if (st) {
        // judge only actual speech (rms over the trigger); room noise just reads as listening
        const s = msg.rms < msg.trigger ? ["listening", ""] : msg.peak < 3000 ? ["QUIET · closer", "quiet"] : ["GOOD", "good"];
        st.textContent = s[0]; st.className = "mm-state " + s[1];
      }
      break;
    }
    case "cmd":
      CommandConsole.on(msg);
      if (msg.stage === "interrupt") { JarvisSummon.state("INTERRUPTED"); logEvent(`<span class="tag">[engine]</span> ■ interrupted — ${escapeHTML(msg.reason || "")}`); }
      if (msg.stage === "handoff") logEvent(`<span class="tag">[engine]</span> handoff ${escapeHTML(msg.from)} → ${escapeHTML(msg.to)}`);
      break;
    case "metrics":
      $("#m-cpu").textContent = msg.cpu.toFixed(0);
      $("#m-mem").textContent = msg.mem.toFixed(0);
      $("#m-disk").textContent = msg.disk.toFixed(0);
      $("#m-disk-fill").style.width = msg.disk + "%";
      $("#m-up").textContent = msg.net_up;
      $("#m-down").textContent = msg.net_down;
      // network tool-card: real live throughput (was a hardcoded placeholder)
      try {
        const tot = Math.round(msg.net_up + msg.net_down);
        const tc = $("#tc-net");
        if (tc && !window._netSpeedShown)
          tc.textContent = `${tot} KB/s · ${Math.round(msg.net_down)}↓ ${Math.round(msg.net_up)}↑`;
      } catch (e) {}
      pushChart(cpuChart, msg.cpu); pushChart(memChart, msg.mem);
      updateResource(msg.cpu, msg.mem, msg.disk);
      try { updateAiopsTele(msg); } catch (e) {}
      try { pushTraffic(msg.net_up, msg.net_down); } catch (e) {}
      try { lastMetrics = msg; updateScanTiles(msg); } catch (e) {}
      try {   // orb flank: real uplink rate + CPU flux
        const fu = $("#fl-uplink"); if (fu) fu.textContent = Math.round(msg.net_down + msg.net_up);
        const ff = $("#fl-flux");
        if (ff) {
          const prev = window._prevCpu ?? msg.cpu;
          const d = msg.cpu - prev;
          ff.textContent = (d >= 0 ? "+" : "") + d.toFixed(1);
          window._prevCpu = msg.cpu;
        }
      } catch (e) {}
      break;
    case "agent":
      if (msg.event === "status") {
        updateAgentStatus(msg.agent, msg.status, msg.task);
        if (msg.status === "thinking" || msg.status === "working") animateAiGauge(true);
        else animateAiGauge(false);
      }
      if (msg.event === "reply") logEvent(`<span class="tag">[${msg.agent}]</span> ${escapeHTML(msg.a || msg.q)}`);
      if (msg.event === "reply" && msg.agent === "jarvis") JarvisSummon.reply(msg.a || "");
      if (msg.event === "tick")  logEvent(`<span class="tag">[${msg.agent}]</span> ${escapeHTML(msg.msg)}`);
      if (msg.event === "alert") logEvent(`<span class="tag">[${msg.agent}]</span> ${escapeHTML(msg.msg)}`, "warn");
      if (msg.event === "pulled-news") logEvent(`<span class="tag">[${msg.agent}]</span> intel pulled · ${msg.count} items`);
      break;
    case "news":
      renderNews(msg.items);
      setPill("#sp-news", `${msg.items.length} ITEMS`, msg.items.length > 0 ? "ok" : "warn");
      logEvent(`<span class="tag">[widow]</span> world feed refreshed · ${msg.items.length} headlines`);
      break;
    case "digest":
      renderDigest(msg);
      logEvent(`<span class="tag">[${msg.kind === "briefing" ? "captain" : "vision"}]</span> digest updated`);
      break;
    case "voice":
      if (msg.event === "ready")      setPill("#sp-voice", "READY", "ok");
      if (msg.event === "wake")       setVoiceState("listening");
      if (msg.event === "listening")  { setVoiceState("listening"); setPill("#sp-voice", "LISTENING", "ok"); }
      if (msg.event === "processing") { setVoiceState("processing"); setPill("#sp-voice", "PROCESSING", "warn"); }
      if (msg.event === "heard")      { setHeard(msg.text, ""); logEvent(`<span class="tag">[heard]</span> "${escapeHTML(msg.text)}"`); }
      if (msg.event === "routed")     { setHeard(null, `→ ${(msg.agent || "").toUpperCase()}`); logEvent(`<span class="tag">[voice]</span> → ${escapeHTML(msg.agent)} · ${escapeHTML(msg.command)}`); }
      if (msg.event === "speak")      { setVoiceState("speaking"); setPill("#sp-voice", "SPEAKING", "ok"); logEvent(`<span class="tag">[voice]</span> ◉ ${escapeHTML(msg.text || "")}`); }
      if (msg.event === "idle")       { setVoiceState("idle"); setPill("#sp-voice", "READY", "ok"); }
      if (msg.event === "engaged")    OrbEngage.on(msg.seconds);
      if (msg.event === "unrouted")   setHeard(msg.text, "no wake word — start with “Hey Jarvis…” or double-clap");
      if (msg.event === "summon")     { JarvisSummon.open(); logEvent(`<span class="tag">[voice]</span> 👏👏 double clap — JARVIS summoned`); }
      if (msg.event === "heard")      JarvisSummon.heard(msg.text);
      if (msg.event === "processing") JarvisSummon.state("THINKING");
      if (msg.event === "speak")      JarvisSummon.speaking(true);
      { // mirror into the voice-ref engine status block
        const ve = $("#vr-engine");
        const map = { ready: ["READY", "ok"], listening: ["LISTENING", "ok"],
                      processing: ["PROCESSING", ""], speak: ["SPEAKING", "ok"], idle: ["READY", "ok"] };
        const m = map[msg.event];
        if (ve && m) { ve.textContent = m[0]; ve.className = m[1]; }
        if (msg.event === "routed") {
          const vl = $("#vr-last");
          if (vl) vl.textContent = (msg.command || "—").slice(0, 24);
        }
      }
      break;
    case "browser":
      if (msg.event === "opened") logEvent(`<span class="tag">[browser]</span> opened ${escapeHTML(msg.name || msg.url)}${msg.fullscreen ? " · fullscreen" : ""}`);
      break;
    case "threat-event":
      addThreatEvent(msg);
      pushTicker(`[${(msg.category || "sys").toUpperCase()}] ${msg.title}`,
                 msg.severity === "high" || msg.severity === "critical" ? "tk-crit"
                 : msg.severity === "medium" ? "tk-warn" : "");
      if (msg.severity === "high" || msg.severity === "critical")
        logEvent(`<span class="tag">[threat]</span> ${escapeHTML(msg.title)}`, "warn");
      break;
    case "alert":
      AlertSystem.raise(msg);
      logEvent(`<span class="tag">[alert]</span> ${escapeHTML((msg.severity || "info").toUpperCase())} · ${escapeHTML(msg.title || "")}`,
               msg.severity === "critical" || msg.severity === "emergency" ? "error"
               : msg.severity === "warning" ? "warn" : "info");
      break;
    case "risk":
      updateRisk(msg.score, msg.level);
      break;
    case "dash-cmd":
      execDashCmd(msg.target);
      break;
    case "vision-request":                 // voice "what do you see" → capture a frame
      try { VisionAI.analyze(true); } catch (e) {}
      break;
    case "vision-obs":                      // Claude's webcam observation
      { const vo = $("#vision-obs"); if (vo) vo.textContent = "◉ " + (msg.text || ""); }
      try { setRecogLive(msg.who); } catch (e) {}
      try { refreshMemory(); } catch (e) {}
      break;
    case "memory-updated":                  // operator memory changed on disk
      try { refreshMemory(); } catch (e) {}
      break;
    case "models-updated":                  // brain/model/provider switched (any tab, voice or command)
      onBrainChanged();
      try { window.dispatchEvent(new CustomEvent("bucs:sync", { detail: { topic: "models" } })); } catch (e) {}
      break;
    case "sync":                            // a shared setting changed (server-side, any tab)
      uiSyncRun(msg.topic);
      break;
    case "web3":                            // web3 module toggled
      try { refreshWeb3(); } catch (e) {}
      break;
    case "audio":                           // mute/volume changed (sync viewers)
      try { AudioCtl.muted = !!msg.muted; AudioCtl.volume = msg.volume ?? 100; AudioCtl.paint(); } catch (e) {}
      break;
    case "audit":                           // live append to the audit feed
      try { prependAudit(msg); } catch (e) {}
      break;
    case "orch":                            // orchestrator cycle summary
      try {
        const os = $("#orch-stat");
        if (os) os.textContent =
          `${msg.active} ACTIVE · ${msg.delegations_total} DELEGATED · ${msg.preemptions_total} PREEMPTED`;
      } catch (e) {}
      break;
    case "insight":
      addInsight(msg);
      pushTicker(`AI: ${msg.insight || ""}`.slice(0, 140));
      setConfidence(msg.confidence ?? null);
      { const src = $("#insight-source");
        if (src) src.textContent = (msg.source || "—").toUpperCase(); }
      logEvent(`<span class="tag">[jarvis-ai]</span> ${escapeHTML(msg.insight)}`,
               msg.severity === "critical" ? "error" : msg.severity === "warn" ? "warn" : "info");
      break;
    case "ai-state":
      setReasonState(msg.state === "analyzing" ? "analyzing" : "idle");
      break;
    case "presence":
      // server-side echo (greetings, cross-client sync) — local monitor owns the UI
      break;
    case "agenda-alert":
      logEvent(`<span class="tag">[agenda]</span> ${escapeHTML(msg.msg)}`, "warn");
      refreshAgenda(); break;
    case "inbox-alert":
      logEvent(`<span class="tag">[inbox]</span> ${escapeHTML(msg.msg)}`, "warn");
      refreshAgenda(); break;
    case "log":
      logEvent(`<span class="tag">[sys]</span> ${escapeHTML(msg.msg)}`, msg.level || "info"); break;
    case "system":
      logEvent(`<span class="tag">[sys]</span> ${escapeHTML(msg.msg)}`); break;
    case "update":
      renderVersion(msg); break;
    case "selfheal":
      refreshHeal(); break;
  }
}

// ── ask form ─────────────────────────────────────────
$("#ask-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const inp = $("#ask-input"); const text = inp.value.trim();
  if (!text) return;
  inp.value = "";
  logEvent(`<span class="tag">[you]</span> ${escapeHTML(text)}`);
  const m = text.match(/^@(\w+)\s+(.+)/);
  const agent = m ? m[1] : null;
  const prompt = m ? m[2] : text;
  try {
    // real-time engine: returns at once; ack, streaming reply and timings
    // arrive over /ws ("cmd" events) and render in LIVE COMMANDS
    const r = await fetch("/api/command", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ text: prompt, agent, source: "text" }),
    });
    const data = await r.json();
    if (!data.ok) logEvent(`<span class="tag">[err]</span> ${escapeHTML(data.error || "command rejected")}`, "error");
  } catch (err) { logEvent("command failed: " + escapeHTML(err.message), "error"); }
});

// ── news refresh button ──────────────────────────────
$("#news-refresh").addEventListener("click", async () => {
  $("#news-refresh").disabled = true;
  try { await fetch("/api/news/refresh", { method: "POST" }); }
  finally { setTimeout(() => { $("#news-refresh").disabled = false; }, 1500); }
});

/* ═══ PHASE 6 · LICENSE — one paid plan, UPI payments, owner-signed keys ═══ */
const PRICING_URL = "https://saikiranthatikonda-coder.github.io/Avengers-Bobbiey-UCS/#pricing";
const _licPost = (url, body) => fetch(url, { method: "POST",
  headers: { "content-type": "application/json" }, body: JSON.stringify(body || {}) }).then(r => r.json());
const _fmtDate = ts => ts ? new Date(ts * 1000).toLocaleDateString([], { day: "2-digit", month: "short", year: "numeric" }) : "—";

function renderLicence(lic, plan) {
  const host = $("#lic-status"); if (!host) return;
  const ed = $("#lic-edition");
  if (ed) ed.textContent = plan ? `${plan.name.toUpperCase()} · ${plan.price}${plan.period}` : "—";
  if (lic.owner) {
    host.innerHTML = `<div class="lic-state ok">● OWNER MODE: everything unlocked; you can issue licences</div>
      <div class="lic-meta">Customers pay over UPI on the website, then send you the UTR + install ID. Issue the key below and email it to them.</div>`;
  } else if (lic.licensed) {
    host.innerHTML = `<div class="lic-state ok">● BUCS PRO · ${escapeHTML(lic.key || "")}</div>
      <div class="lic-meta">${escapeHTML([lic.customer, `valid until ${_fmtDate(lic.expires_at)}`, `${lic.days_left} days left`].filter(Boolean).join(" · "))}</div>
      <div class="lic-acts"><a class="cmd-btn" href="${PRICING_URL}" target="_blank" rel="noopener">RENEW ↗</a>
        <button class="ghost-btn" data-lic="deactivate" title="remove the key from this install">REMOVE KEY</button></div>`;
  } else {
    host.innerHTML = `<div class="lic-state">○ NOT LICENSED</div>`;
  }
  host.querySelector('[data-lic="deactivate"]')?.addEventListener("click", async () => {
    if (!confirm("Remove the licence key? BUCS locks until a key is activated again.")) return;
    await _licPost("/api/license/deactivate");
    location.reload();
  });
  const own = $("#lic-owner"); if (own) own.hidden = !lic.can_issue;
}

async function refreshIssued() {
  const host = $("#lic-issued"); if (!host) return;
  const d = await fetch("/api/license/issued").then(r => r.json()).catch(() => null);
  if (!d || !d.ok) return;
  $("#lic-issued-n").textContent = d.count; $("#lic-active-n").textContent = d.active;
  const now = Date.now() / 1000;
  host.innerHTML = d.issued.length ? d.issued.slice(0, 12).map(r => `
    <div class="lic-row${r.exp < now ? " expired" : ""}">
      <span class="lr-who">${escapeHTML(r.to)}</span>
      <span class="lr-meta">${escapeHTML([r.payment_ref ? "UTR " + r.payment_ref : "", r.iid ? "ID " + r.iid : "any install"].filter(Boolean).join(" · "))}</span>
      <span class="lr-exp">${r.exp < now ? "EXPIRED" : "→ " + _fmtDate(r.exp)}</span>
    </div>`).join("") : `<div class="tf-empty">no licences issued yet</div>`;
}

$("#lic-issue-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const out = $("#lic-issued-key");
  const body = { customer: $("#li-customer").value, payment_ref: $("#li-utr").value,
    install_id: $("#li-iid").value || null, days: +$("#li-days").value };
  const r = await _licPost("/api/license/issue", body).catch(err => ({ ok: false, error: err.message }));
  out.hidden = false;
  if (!r.ok) { out.innerHTML = `<div style="color:var(--error)">${escapeHTML(r.error || "refused")}</div>`; return; }
  const mail = `mailto:${encodeURIComponent(body.customer)}?subject=${encodeURIComponent("Your BUCS Pro licence key")}&body=${encodeURIComponent(
    `Thank you for your payment${body.payment_ref ? " (UTR " + body.payment_ref + ")" : ""}.\n\nYour BUCS Pro licence key (valid until ${_fmtDate(r.record.exp)}):\n\n${r.key}\n\nOpen BUCS, paste the key on the activation screen and press ACTIVATE.\n`)}`;
  out.innerHTML = `<div class="lik-label">KEY FOR ${escapeHTML(r.record.to)} · VALID UNTIL ${_fmtDate(r.record.exp)}</div>
    <textarea readonly class="lik-key">${escapeHTML(r.key)}</textarea>
    <div class="lic-acts"><button class="cmd-btn" type="button" id="lik-copy">COPY KEY</button>
      <a class="ghost-btn" href="${mail}">EMAIL IT ↗</a></div>`;
  $("#lik-copy").addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(r.key); $("#lik-copy").textContent = "COPIED"; } catch (err) {}
  });
  e.target.reset();
  logEvent(`<span class="tag">[license]</span> issued ${escapeHTML(r.record.id)} → ${escapeHTML(r.record.to)}`);
  refreshIssued();
});

async function refreshBilling() {
  try {
    const d = await (await fetch("/api/billing")).json();
    renderLicence(d.license || {}, (d.editions || [])[0]);
    if ((d.license || {}).can_issue) refreshIssued();
  } catch (e) {}
}
refreshBilling(); setInterval(refreshBilling, 60000);

/* ═══ AI BRAIN ROUTER — which brain answers, real route usage ═══ */
const ROUTE_NAMES = { claude: "Claude", "local-llm": "Local LLM", template: "Rule templates", offline: "Offline" };
async function refreshRouter() {
  const routes = $("#rt-routes"), provs = $("#rt-provs"); if (!routes) return;
  const d = await fetch("/api/llm/providers").then(r => r.json()).catch(() => null);
  if (!d) return;
  const act = (d.providers || []).find(p => p.active);
  $("#rt-active").textContent = act ? act.name.toUpperCase().slice(0, 26) : "—";
  const u = d.usage || {}, rep = u.replies || {};
  const total = Object.values(rep).reduce((a, b) => a + b, 0);
  routes.innerHTML = total ? Object.entries(rep).sort((a, b) => b[1] - a[1]).map(([k, n]) => {
    const name = k.startsWith("provider:") ? k.slice(9) : (ROUTE_NAMES[k] || k);
    const pct = Math.round(n / total * 100);
    return `<div class="rt-route"><span class="rt-name">${escapeHTML(name)}</span>
      <span class="rt-bar"><i style="width:${pct}%"></i></span>
      <span class="rt-n">${n} · ${pct}%${u.last_ms && u.last_ms[k] != null ? ` · ${u.last_ms[k]} ms` : ""}</span></div>`;
  }).join("") : `<div class="tf-empty">no replies yet this session: ask JARVIS anything</div>`;
  provs.innerHTML = (d.providers || []).map(p => `
    <button class="rt-prov${p.active ? " on" : ""}" data-id="${escapeHTML(p.id)}" ${p.locked ? "disabled" : ""}
      title="${escapeHTML(p.name)}${p.health ? (p.health.ok ? " · ✓ " + p.health.latency_ms + " ms" : " · last test failed") : ""}">
      ${p.health ? (p.health.ok ? "●" : "○") : "◌"} ${escapeHTML(p.name.split(" (")[0])}</button>`).join("");
}
$("#rt-provs")?.addEventListener("click", async (e) => {
  const b = e.target.closest(".rt-prov"); if (!b || b.classList.contains("on")) return;
  b.textContent = "…";
  const r = await _licPost("/api/llm/active", { id: b.dataset.id }).catch(err => ({ ok: false, error: err.message }));
  if (!r.ok) logEvent(`<span class="tag">[llm]</span> ${escapeHTML(r.error || "switch refused")}`, "warn");
  if (r.ok) onBrainChanged(); else refreshRouter();       // every brain display, not just this card
});
$("#rt-open")?.addEventListener("click", () => openModelManager());
refreshRouter(); setInterval(refreshRouter, 15000);

/* ═══ MARKET WATCH — live prices (server-cached CoinGecko) ═══ */
async function refreshMarket() {
  const host = $("#mw-list"); if (!host || !host.offsetParent) return;      // only while on screen
  const d = await fetch("/api/market").then(r => r.json()).catch(() => null);
  if (!d) return;
  const age = d.fetched_at ? Math.round(Date.now() / 1000 - d.fetched_at) : null;
  $("#mw-age").textContent = age == null ? "—" : age < 90 ? `${age}s AGO` : `${Math.round(age / 60)} MIN AGO`;
  if (!d.assets.length) { host.innerHTML = `<div class="tf-empty">${escapeHTML(d.error ? "price feed unreachable: " + d.error : "no data")}</div>`; return; }
  const money = (v, cur) => v == null ? "—" : v.toLocaleString(cur === "INR" ? "en-IN" : "en-US",
    { style: "currency", currency: cur, maximumFractionDigits: v < 10 ? 3 : 0 });
  host.innerHTML = d.assets.map(a => {
    const ch = a.change_24h, up = ch >= 0;
    return `<div class="mw-row"><span class="mw-sym">${escapeHTML(a.symbol)}</span>
      <span class="mw-usd">${money(a.usd, "USD")}</span><span class="mw-inr">${money(a.inr, "INR")}</span>
      <span class="mw-ch ${up ? "up" : "down"}">${ch == null ? "—" : (up ? "▲ " : "▼ ") + Math.abs(ch).toFixed(2) + "%"}</span></div>`;
  }).join("");
}
refreshMarket(); setInterval(refreshMarket, 60000);

/* ═══════════════════════════════════════════════════════════════
   PHASE 6 · WEB3 COMMAND CENTER — functional subsystem
   Optional & modular: everything here is inert when the module is
   disabled. Keys never leave the browser; the server only records the
   address and independently verifies balances over RPC.
   ═══════════════════════════════════════════════════════════════ */

const fmtTok = n => n == null ? "—"
  : n >= 1e9 ? (n / 1e9).toFixed(2) + "B"
  : n >= 1e6 ? (n / 1e6).toFixed(1) + "M"
  : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : String(Math.round(n * 100) / 100);
const shortAddr = a => a ? `${a.slice(0, 6)}…${a.slice(-4)}` : "—";

/* ── EIP-6963: discover every installed wallet, not just window.ethereum ── */
const W3Wallets = { providers: [], selected: null };
window.addEventListener("eip6963:announceProvider", (e) => {
  const d = e.detail;
  if (d && d.info && !W3Wallets.providers.some(p => p.info.uuid === d.info.uuid))
    W3Wallets.providers.push(d);
});
try { window.dispatchEvent(new Event("eip6963:requestProvider")); } catch (e) {}

function w3Provider() {
  if (W3Wallets.selected) return W3Wallets.selected.provider;
  if (W3Wallets.providers.length === 1) return W3Wallets.providers[0].provider;
  return window.ethereum || null;
}

/* ── connect / disconnect / switch network ── */
async function w3Connect(detail) {
  if (detail) W3Wallets.selected = detail;
  const prov = w3Provider();
  if (!prov) {
    logEvent('<span class="tag">[web3]</span> no wallet detected — install MetaMask or another EIP-6963 wallet', "warn");
    return;
  }
  try {
    const accounts = await prov.request({ method: "eth_requestAccounts" });
    const chainHex = await prov.request({ method: "eth_chainId" });
    await fetch("/api/web3/wallet", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({
        address: accounts[0], chain_id: parseInt(chainHex, 16),
        label: (W3Wallets.selected && W3Wallets.selected.info.name) || "injected",
      }),
    });
    // react to the user changing account/network in the wallet itself
    if (!prov.__bucsBound) {
      prov.__bucsBound = true;
      prov.on && prov.on("accountsChanged", (a) => a.length ? w3Connect() : w3Disconnect());
      prov.on && prov.on("chainChanged", () => w3Connect());
    }
    const picker = $("#w3-wallet-picker"); if (picker) picker.hidden = true;
    logEvent('<span class="tag">[web3]</span> wallet connected');
  } catch (e) {
    logEvent('<span class="tag">[web3]</span> wallet connection cancelled', "warn");
  }
  refreshWeb3();
}

async function w3Disconnect() {
  try { await fetch("/api/web3/wallet/disconnect", { method: "POST" }); } catch (e) {}
  W3Wallets.selected = null;
  refreshWeb3();
}

async function w3SwitchChain(chainId) {
  const prov = w3Provider();
  const hex = "0x" + Number(chainId).toString(16);
  if (prov) {
    try {
      await prov.request({ method: "wallet_switchEthereumChain", params: [{ chainId: hex }] });
      logEvent(`<span class="tag">[web3]</span> network switched`);
    } catch (e) {
      logEvent('<span class="tag">[web3]</span> network switch declined by wallet', "warn");
    }
  }
  // keep the server view in sync even with no wallet (read-only chain monitoring)
  try {
    await fetch("/api/web3/config", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ default_chain: Number(chainId) }),
    });
  } catch (e) {}
  refreshWeb3();
}

/* ── portfolio sparkline (real observed balance history) ── */
function drawPortfolio(series) {
  const cv = document.getElementById("w3-pf-canvas"); if (!cv) return;
  const ctx = cv.getContext("2d");
  const W = cv.width = cv.clientWidth || 260, H = cv.height = 52;
  ctx.clearRect(0, 0, W, H);
  if (!series || series.length < 2) {
    ctx.fillStyle = "rgba(126,150,179,0.6)"; ctx.font = "9px monospace";
    ctx.fillText("collecting balance history…", 6, H / 2 + 3);
    return;
  }
  const vals = series.map(p => p.native + (p.token || 0));
  const min = Math.min(...vals), max = Math.max(...vals), span = (max - min) || 1;
  ctx.beginPath();
  series.forEach((p, i) => {
    const x = (i / (series.length - 1)) * (W - 4) + 2;
    const y = H - 4 - ((vals[i] - min) / span) * (H - 10);
    i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  });
  ctx.strokeStyle = "#a855f7"; ctx.lineWidth = 1.6; ctx.stroke();
  ctx.lineTo(W - 2, H - 2); ctx.lineTo(2, H - 2); ctx.closePath();
  ctx.fillStyle = "rgba(168,85,247,0.14)"; ctx.fill();
}

/* ── main refresh ── */
async function refreshWeb3() {
  try {
    const d = await (await fetch("/api/web3")).json();
    const on = !!d.enabled;
    const st = $("#web3-state"); if (st) st.textContent = on ? "ENABLED" : "DISABLED";
    const btn = $("#btn-web3-toggle");
    if (btn) { btn.textContent = on ? "◈ WEB3 ENABLED" : "◇ ENABLE WEB3"; btn.classList.toggle("on", on); }
    const row = $("#web3-row"); if (row) row.hidden = !on;
    if (on) refreshMarket();
    const mini = $("#web3-wallet-mini");
    if (mini) mini.innerHTML = !on
      ? '<div class="tf-empty">enable the module, then connect a wallet</div>'
      : (d.wallet
        ? `<div class="w3-kv"><span class="k">WALLET</span><span class="v">${escapeHTML(shortAddr(d.wallet.address))} · ${escapeHTML(d.wallet.network || "")}</span></div>`
        : '<div class="tf-empty">module on · connect a wallet in the WALLET widget below</div>');
    if (!on) return;

    /* ── WALLET ── */
    const w = d.wallet;
    const wStatus = $("#w3-wallet-status");
    if (wStatus) wStatus.textContent = w ? "CONNECTED" : "DISCONNECTED";
    const wb = $("#w3-wallet-body");
    const cbtn = $("#btn-wallet-connect"), dbtn = $("#btn-wallet-disconnect"), rbtn = $("#btn-wallet-refresh");
    if (wb) {
      if (w) {
        const ex = w.explorer ? `${w.explorer}/address/${w.address}` : null;
        wb.innerHTML = `
          <div class="w3-kv"><span class="k">ADDRESS</span><span class="v" title="${escapeHTML(w.address)}">${escapeHTML(shortAddr(w.address))}${ex ? ` <a href="${escapeHTML(ex)}" target="_blank" rel="noopener" style="color:#c084fc">↗</a>` : ""}</span></div>
          <div class="w3-kv"><span class="k">NETWORK</span><span class="v">${escapeHTML(w.network || "—")}</span></div>
          <div class="w3-kv"><span class="k">${escapeHTML(w.native_symbol || "NATIVE")}</span><span class="v">${w.native_balance != null ? w.native_balance.toFixed(5) : "—"}</span></div>
          <div class="w3-kv"><span class="k">${escapeHTML(w.token_symbol || "TOKEN")}</span><span class="v">${w.token_balance != null ? w.token_balance.toFixed(3) : (d.config.has_contract ? "0" : "pre-launch")}</span></div>
          <div class="w3-kv"><span class="k">WALLET</span><span class="v">${escapeHTML(w.label || "injected")}</span></div>`;
        if (cbtn) cbtn.hidden = true; if (dbtn) dbtn.hidden = false; if (rbtn) rbtn.hidden = false;
      } else {
        const n = W3Wallets.providers.length;
        wb.innerHTML = n || window.ethereum
          ? `<div class="tf-empty">${n ? n + " wallet(s) detected" : "wallet detected"} — click Connect</div>`
          : '<div class="tf-empty">no browser wallet detected — install MetaMask (or any EIP-6963 wallet) to connect</div>';
        if (cbtn) cbtn.hidden = false; if (dbtn) dbtn.hidden = true; if (rbtn) rbtn.hidden = true;
      }
    }

    /* ── BLOCKCHAIN STATUS (live RPC) ── */
    const c = d.chain || {};
    const cn = $("#w3-chain-name"); if (cn) cn.textContent = (c.name || "—").toUpperCase();
    const cs = $("#w3-chain-stats");
    if (cs) cs.innerHTML = [
      ["NETWORK", c.name || "—"],
      ["BLOCK", c.block != null ? "#" + c.block.toLocaleString() : "—"],
      ["GAS", c.gas_gwei != null ? c.gas_gwei + " gwei" : "—"],
      ["RPC LATENCY", c.latency_ms != null ? c.latency_ms + " ms" : "—"],
      ["HEALTH", (c.health || "—").toUpperCase()],
      ["STATUS", c.online ? "● ONLINE" : "○ OFFLINE"],
    ].map(([k, v]) => `<div class="w3-stat"><span class="lbl">${k}</span><span class="val">${escapeHTML(String(v))}</span></div>`).join("");
    const qf = $("#w3-quality-fill");
    if (qf) {
      qf.style.width = (c.quality || 0) + "%";
      qf.className = c.quality >= 70 ? "" : c.quality >= 40 ? "warn" : "bad";
    }
    const qt = $("#w3-quality-txt"); if (qt) qt.textContent = (c.quality || 0) + "%";
    const cp = $("#w3-chain-picker");
    if (cp) {
      cp.innerHTML = (d.chains || []).map(x =>
        `<button class="w3-chain-btn${x.chain_id === c.chain_id ? " active" : ""}" data-chain="${x.chain_id}">${escapeHTML(x.name.toUpperCase())}</button>`).join("");
      cp.querySelectorAll(".w3-chain-btn").forEach(b =>
        b.addEventListener("click", () => w3SwitchChain(b.dataset.chain)));
    }

    /* ── PORTFOLIO ── */
    const an = d.analytics || {};
    const pfc = $("#w3-pf-change");
    if (pfc) pfc.textContent = an.points > 1 ? `${an.change_pct >= 0 ? "+" : ""}${an.change_pct}%` : `${an.points || 0} SAMPLES`;
    drawPortfolio(an.series);
    const hold = $("#w3-holdings");
    if (hold) hold.innerHTML = (an.holdings || []).length
      ? an.holdings.map(h => `<div class="w3-holding"><span class="asset">${escapeHTML(h.asset)}</span><span class="amt">${h.amount}</span><span class="kind">${escapeHTML(h.kind.toUpperCase())}</span></div>`).join("")
      : '<div class="tf-empty">connect a wallet to load holdings</div>';
    const act = $("#w3-activity");
    if (act) act.innerHTML = (d.wallet_history || []).length
      ? d.wallet_history.map(h => `<div class="w3-act"><b>${escapeHTML(shortAddr(h.address))}</b> · ${new Date(h.ts * 1000).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}</div>`).join("")
      : '<div class="w3-act">no wallet activity yet</div>';
    // transactions
    try {
      const tx = await (await fetch("/api/web3/transactions")).json();
      const tl = $("#w3-tx-list");
      if (tl) tl.innerHTML = (tx.transactions || []).length
        ? tx.transactions.map(t => `<div class="w3-tx ${t.direction}"><span class="dir">${t.direction === "in" ? "▼" : "▲"}</span><span class="hash">${escapeHTML(t.hash)}</span><span class="amt">${t.value}</span></div>`).join("")
        : `<div class="tf-empty">${escapeHTML(tx.note || (w ? "no recent transactions" : "connect a wallet"))}</div>`;
    } catch (e) {}

    /* ── TOKEN CENTER ── */
    const t = d.token || {};
    const tn = $("#w3-token-name"); if (tn) tn.textContent = (t.name || "—").toUpperCase();
    const tsym = $("#w3-token-sym"); if (tsym) tsym.textContent = t.symbol || "—";
    const tm = $("#w3-token-mode");
    if (tm) tm.textContent = t.live ? "● LIVE ON-CHAIN" : "PRE-LAUNCH · CONFIGURED";
    const tstats = $("#w3-token-stats");
    if (tstats) tstats.innerHTML = [
      ["TOTAL SUPPLY", fmtTok(t.total_supply)],
      ["CIRCULATING", `${fmtTok(t.circulating)} (${t.circulating_pct || 0}%)`],
      ["TREASURY", fmtTok(t.treasury_tokens)],
      ["COMMUNITY", fmtTok(t.community_tokens)],
      ["ECOSYSTEM", fmtTok(t.ecosystem_tokens)],
      ["DEVELOPMENT", fmtTok(t.development_tokens)],
      ["BURNED", fmtTok(t.burned)],
      ["HOLDERS", t.holders ? fmtTok(t.holders) : "—"],
    ].map(([k, v]) => `<div class="w3-stat"><span class="lbl">${k}</span><span class="val">${escapeHTML(String(v))}</span></div>`).join("");
    const alloc = $("#w3-alloc");
    if (alloc) alloc.innerHTML = (t.allocations || []).map(a => `
      <div class="w3-alloc-row"><span class="w3-alloc-name">${escapeHTML(a.label)}</span>
      <span class="w3-alloc-bar"><div style="width:${a.pct}%"></div></span>
      <span class="w3-alloc-pct">${a.pct}%</span></div>`).join("");
    const prem = $("#w3-premium");
    const power = (d.governance || {}).voting_power || 0;
    if (prem) prem.innerHTML = (t.utilities || []).map(u => {
      const unlocked = power >= u.stake;
      return `<div class="w3-prem-row"><span class="nm">${escapeHTML(u.name)}</span>
        <span class="stake">${u.stake} ${escapeHTML(t.symbol || "")}</span>
        <span class="lock">${unlocked ? "🔓" : "🔒"}</span></div>`;
    }).join("");

    /* ── TREASURY ── */
    const tr = d.treasury || {};
    const trTotal = $("#w3-treasury-total");
    if (trTotal) trTotal.textContent = `${fmtTok(tr.total_tokens)} ${tr.symbol || ""}`;
    const tt = $("#w3-treasury-top");
    if (tt) tt.innerHTML = `
      <div class="w3-kv"><span class="k">DAO TREASURY</span><span class="v">${fmtTok(tr.total_tokens)} ${escapeHTML(tr.symbol || "")}</span></div>
      <div class="w3-kv"><span class="k">ON-CHAIN</span><span class="v">${tr.live_native_balance != null ? tr.live_native_balance.toFixed(4) + " " + escapeHTML(tr.native_symbol || "") : (tr.address ? "reading…" : "no address configured")}</span></div>`;
    const rv = $("#w3-reserves");
    if (rv) rv.innerHTML = (tr.reserves || []).map(r => `
      <div class="w3-reserve">
        <div class="w3-res-head"><span class="w3-res-name">${escapeHTML(r.label)}</span><span class="w3-res-amt">${fmtTok(r.tokens)} · ${r.pct}%</span></div>
        <div class="w3-res-bar"><div style="width:${r.pct}%"></div></div>
        <div class="w3-res-purpose">${escapeHTML(r.purpose || "")}</div>
      </div>`).join("");
    const mv = $("#w3-moves");
    if (mv) mv.innerHTML = (tr.movements || []).length
      ? tr.movements.map(m => `<div class="w3-move"><span class="${m.delta >= 0 ? "up" : "down"}">${m.delta >= 0 ? "+" : ""}${fmtTok(m.delta)}</span> ${escapeHTML(m.reserve)} — ${escapeHTML(m.note || "")}</div>`).join("")
      : '<div class="tf-empty">no treasury movements recorded</div>';

    /* ── GOVERNANCE (real voting) ── */
    const g = d.governance || {};
    const ga = $("#w3-gov-active"); if (ga) ga.textContent = g.active_count || 0;
    const gp = $("#w3-gov-power"); if (gp) gp.textContent = g.voting_power || 0;
    const gv = $("#w3-gov-voters"); if (gv) gv.textContent = g.unique_voters || 0;
    const gl = $("#w3-gov-list");
    if (gl) {
      gl.innerHTML = (g.proposals || []).map(p => {
        const t2 = p.tally || {};
        const active = p.status === "active";
        return `<div class="w3-gov-item ${p.status}">
          <div class="w3-gov-title">${escapeHTML(p.id)} · ${escapeHTML(p.title)}</div>
          <div class="w3-gov-bar"><div style="width:${t2.for_pct || 0}%"></div></div>
          <div class="w3-gov-meta"><span>${t2.for || 0} for · ${t2.against || 0} against</span>
            <span>${active ? "ends " + p.ends_in_h + "h" : p.status.toUpperCase()}</span></div>
          <div class="w3-gov-quorum">QUORUM ${t2.quorum_met ? "MET" : "PENDING"} · ${t2.real_votes || 0} WALLET VOTES${p.your_vote ? " · YOU VOTED " + p.your_vote.toUpperCase() : ""}</div>
          ${active ? `<div class="w3-vote-btns">
            <button class="w3-vote for${p.your_vote === "for" ? " cast" : ""}" data-p="${escapeHTML(p.id)}" data-c="for"${w ? "" : " disabled"}>✓ FOR</button>
            <button class="w3-vote against${p.your_vote === "against" ? " cast" : ""}" data-p="${escapeHTML(p.id)}" data-c="against"${w ? "" : " disabled"}>✕ AGAINST</button>
            ${w ? "" : '<span class="w3-gov-quorum">connect a wallet to vote</span>'}
          </div>` : ""}
        </div>`;
      }).join("");
      gl.querySelectorAll(".w3-vote").forEach(b => b.addEventListener("click", async () => {
        b.disabled = true;
        try {
          const r = await (await fetch("/api/web3/governance/vote", {
            method: "POST", headers: { "content-type": "application/json" },
            body: JSON.stringify({ proposal_id: b.dataset.p, choice: b.dataset.c }) })).json();
          if (!r.ok && r.error) logEvent(`<span class="tag">[web3]</span> ${escapeHTML(r.error)}`, "warn");
          else logEvent(`<span class="tag">[web3]</span> vote recorded — ${escapeHTML(b.dataset.p)} ${escapeHTML(b.dataset.c)}`);
        } catch (e) {}
        refreshWeb3();
      }));
    }

    /* ── MARKETPLACE ── */
    const mk = d.marketplace || {};
    const mi = $("#w3-market-installed"); if (mi) mi.textContent = mk.installed_count || 0;
    const ml = $("#w3-market-list");
    if (ml) {
      ml.innerHTML = (mk.listings || []).map(m => `
        <div class="w3-market-item">
          <span><span class="nm">${escapeHTML(m.name)}</span><br>
            <span class="type">${escapeHTML(m.type.toUpperCase())} · ${escapeHTML(String(m.author).toUpperCase())} · ${m.installs} INSTALLS</span></span>
          <span style="text-align:right">
            <span class="price">${escapeHTML(m.price_label)}</span><br>
            <button class="w3-mk-btn${m.is_installed ? " remove" : ""}" data-slug="${escapeHTML(m.slug)}" data-act="${m.is_installed ? "uninstall" : "install"}">${m.is_installed ? "REMOVE" : "INSTALL"}</button>
          </span>
        </div>`).join("");
      ml.querySelectorAll(".w3-mk-btn").forEach(b => b.addEventListener("click", async () => {
        b.disabled = true;
        try {
          const r = await (await fetch("/api/web3/marketplace/" + b.dataset.act, {
            method: "POST", headers: { "content-type": "application/json" },
            body: JSON.stringify({ slug: b.dataset.slug }) })).json();
          if (!r.ok && r.error) logEvent(`<span class="tag">[web3]</span> ${escapeHTML(r.error)}`, "warn");
        } catch (e) {}
        refreshWeb3();
      }));
    }

    /* ── COMMUNITY / EVENT LOG ── */
    const cs2 = $("#w3-comm-stats");
    if (cs2) cs2.innerHTML = [
      ["VOTERS", g.unique_voters || 0],
      ["PROPOSALS", g.total_count || 0],
      ["INSTALLS", mk.installed_count || 0],
      ["PUBLISHED", mk.published_count || 0],
    ].map(([k, v]) => `<div class="w3-stat"><span class="lbl">${k}</span><span class="val">${v}</span></div>`).join("");
    const cn2 = $("#w3-comm-news");
    if (cn2) cn2.innerHTML = (an.events || []).length
      ? an.events.map(e => `<div class="w3-news-item">${escapeHTML(e.text)}</div>`).join("")
      : '<div class="w3-news-item">no on-chain events yet — connect a wallet or cast a vote</div>';
  } catch (e) {}
}
refreshWeb3(); setInterval(refreshWeb3, 30000);

/* ── controls ── */
$("#btn-web3-toggle")?.addEventListener("click", async () => {
  const enabling = !$("#btn-web3-toggle").classList.contains("on");
  try {
    const r = await (await fetch("/api/web3/toggle", { method: "POST",
      headers: { "content-type": "application/json" }, body: JSON.stringify({ on: enabling }) })).json();
    if (!r.ok && r.error) logEvent(`<span class="tag">[web3]</span> ${escapeHTML(r.error)}`, "warn");
  } catch (e) {}
  refreshWeb3();
});

$("#btn-wallet-connect")?.addEventListener("click", () => {
  // more than one wallet installed → let the operator choose (EIP-6963)
  if (W3Wallets.providers.length > 1) {
    const picker = $("#w3-wallet-picker");
    if (picker) {
      picker.hidden = false;
      picker.innerHTML = W3Wallets.providers.map((p, i) =>
        `<div class="w3-wallet-opt" data-i="${i}"><img src="${escapeHTML(p.info.icon)}" alt=""/> ${escapeHTML(p.info.name)}</div>`).join("");
      picker.querySelectorAll(".w3-wallet-opt").forEach(el =>
        el.addEventListener("click", () => w3Connect(W3Wallets.providers[+el.dataset.i])));
      return;
    }
  }
  w3Connect();
});
$("#btn-wallet-disconnect")?.addEventListener("click", w3Disconnect);
$("#btn-wallet-refresh")?.addEventListener("click", async () => {
  try { await fetch("/api/web3/wallet/refresh", { method: "POST" }); } catch (e) {}
  refreshWeb3();
});

$("#w3-gov-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = $("#w3-gov-title").value.trim(); if (!title) return;
  try {
    const r = await (await fetch("/api/web3/governance/propose", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ title }) })).json();
    if (r.ok) { $("#w3-gov-title").value = ""; logEvent(`<span class="tag">[web3]</span> proposal ${escapeHTML(r.proposal.id)} opened`); }
    else if (r.error) logEvent(`<span class="tag">[web3]</span> ${escapeHTML(r.error)}`, "warn");
  } catch (err) {}
  refreshWeb3();
});

$("#w3-publish-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = $("#w3-publish-name").value.trim(); if (!name) return;
  try {
    const r = await (await fetch("/api/web3/marketplace/publish", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, kind: "plugin" }) })).json();
    if (r.ok) { $("#w3-publish-name").value = ""; logEvent('<span class="tag">[web3]</span> listing published — pending review'); }
    else if (r.error) logEvent(`<span class="tag">[web3]</span> ${escapeHTML(r.error)}`, "warn");
  } catch (err) {}
  refreshWeb3();
});

/* ═══ DASHBOARD AUDIO — mute + volume (agent speech + alert sounds) ═══
   Agent speech is server-side TTS (host speakers), so mute/volume hit the
   backend; the browser alert siren is gated locally via window.dashAudioMuted. */
window.dashAudioMuted = false;
const AudioCtl = {
  muted: false, volume: 100,
  icon(v) { return this.muted || v === 0 ? "🔇" : v < 45 ? "🔉" : "🔊"; },
  paint() {
    const ctl = $("#audio-ctl"), btn = $("#audio-mute"), vol = $("#audio-vol");
    window.dashAudioMuted = this.muted;
    if (btn) btn.textContent = this.icon(this.volume);
    if (ctl) ctl.classList.toggle("muted", this.muted);
    if (vol && document.activeElement !== vol) vol.value = this.muted ? 0 : this.volume;
    const title = this.muted ? "Audio muted — click to unmute"
      : `Dashboard audio · ${this.volume}%`;
    if (ctl) ctl.title = title;
  },
  async load() {
    try {
      const d = await (await fetch("/api/audio")).json();
      this.muted = !!d.muted; this.volume = d.volume ?? 100;
    } catch (e) {}
    this.paint();
  },
  _seq: 0,
  async push(body) {
    const seq = ++this._seq;                     // slider drags send many; only the newest answer paints
    try {
      const d = await (await fetch("/api/audio", { method: "POST",
        headers: { "content-type": "application/json" }, body: JSON.stringify(body) })).json();
      if (seq !== this._seq) return;
      if (d && d.ok) { this.muted = !!d.muted; this.volume = d.volume ?? this.volume; this.paint(); }
      else this.load();
    } catch (e) {
      logEvent(`<span class="tag">[audio]</span> audio setting not saved: ${escapeHTML(e.message)}`, "warn");
      this.load();
    }
  },
  async toggleMute() {
    this.muted = !this.muted;
    if (this.muted && typeof AlertSystem !== "undefined") { try { AlertSystem.stopSiren?.(); } catch (e) {} }
    this.paint();
    await this.push({ muted: this.muted });
    logEvent(`<span class="tag">[audio]</span> dashboard audio ${this.muted ? "muted" : "unmuted"}`);
  },
  async setVolume(v) {
    this.volume = Math.max(0, Math.min(100, parseInt(v, 10) || 0));
    if (this.volume > 0 && this.muted) this.muted = false;   // dragging up unmutes
    this.paint();
    await this.push({ volume: this.volume, muted: this.muted });
  },
};
$("#audio-mute")?.addEventListener("click", () => AudioCtl.toggleMute());
$("#audio-vol")?.addEventListener("input", (e) => AudioCtl.setVolume(e.target.value));
AudioCtl.load();

/* ═══════════════════════════════════════════════════════════════
   PHASE 2 · MULTI-AGENT INTELLIGENCE — panel controllers
   orchestration · recommendations · product evolution ·
   local AI control · operator productivity · knowledge hub
   ═══════════════════════════════════════════════════════════════ */

// ── multi-agent orchestration ────────────────────────
async function refreshOrch() {
  try {
    const d = await (await fetch("/api/orchestrator")).json();
    const os = $("#orch-stat");
    if (os) os.textContent =
      `${d.active} ACTIVE · ${d.delegations_total} DELEGATED · ${d.collabs_total ?? 0} COLLABS`;
    // shared context blackboard chips
    const bb = d.blackboard || {}; const bbEl = $("#orch-bb");
    if (bbEl && bb.ts) {
      const chips = [
        ["CPU", `${Math.round(bb.cpu)}%`, bb.cpu > 85],
        ["MEM", `${Math.round(bb.mem)}%`, bb.mem > 88],
        ["RISK", `${bb.risk_score}`, bb.risk_score >= 50],
        ["INCIDENTS", `${bb.open_incidents}`, bb.open_incidents > 3],
        ["MAIL", `${bb.priority_mail}`, bb.priority_mail >= 2],
        ["PRESENCE", (bb.presence || "—").toUpperCase(), false],
      ];
      if (bb.next_meeting_min != null)
        chips.push(["NEXT MTG", `${Math.round(bb.next_meeting_min)}m`, bb.next_meeting_min < 15]);
      if (bb.focus_active) chips.push(["FOCUS", "GUARDED", false]);
      bbEl.innerHTML = chips.map(([k, v, hot]) =>
        `<span class="orch-chip${hot ? " hot" : ""}">${k} <b>${escapeHTML(String(v))}</b></span>`).join("");
    }
    // directives (active first, then recent completions greyed)
    const list = $("#orch-list");
    if (list) {
      const act = (d.directives || []).map(x => ({ ...x, _done: false }));
      const done = (d.recent_done || []).slice(0, 3).map(x => ({ ...x, _done: true }));
      const rows = [...act, ...done];
      list.innerHTML = rows.length ? rows.map(x => `
        <div class="orch-item${x._done ? " done" : ""}">
          <span class="orch-p p${x.priority}">${(d.priority_labels || {})[x.priority] || "P" + x.priority}</span>
          <span class="orch-main">
            <div class="orch-title">${escapeHTML(x.title)}</div>
            <div class="orch-detail">${escapeHTML(x.detail || "")}${x.consult ? " · ⇄ consulted " + escapeHTML(x.consult.toUpperCase()) : ""}</div>
          </span>
          <span class="orch-agent">${escapeHTML((x.agent || "").toUpperCase())}</span>
        </div>`).join("")
        : '<div class="tf-empty">no directives — all stations nominal</div>';
    }
  } catch (e) {}
}
refreshOrch(); setInterval(refreshOrch, 15000);

// ── command recommendations ──────────────────────────
async function refreshRecs() {
  try {
    const d = await (await fetch("/api/recommendations")).json();
    const list = $("#recs-list"); if (!list) return;
    const recs = d.recommendations || [];
    list.innerHTML = recs.length ? recs.map(r => `
      <div class="rec-item ${r.severity}">
        <span class="rec-main">
          <div class="rec-title">${escapeHTML(r.title)}</div>
          <div class="rec-detail">${escapeHTML(r.detail || "")}</div>
        </span>
      </div>`).join("") : '<div class="tf-empty">assessing conditions…</div>';
  } catch (e) {}
}
refreshRecs(); setInterval(refreshRecs, 30000);

$("#btn-briefing")?.addEventListener("click", async () => {
  const b = $("#btn-briefing"); b.disabled = true; b.textContent = "◈ COMPILING…";
  try { await fetch("/api/briefing", { method: "POST" }); } catch (e) {}
  setTimeout(() => { b.disabled = false; b.textContent = "◈ EXECUTIVE BRIEFING"; }, 4000);
});

// ── product evolution (live roadmap) ─────────────────
async function refreshRoadmap() {
  try {
    const d = await (await fetch("/api/roadmap")).json();
    const v = $("#evo-version"); if (v) v.textContent = d.version;
    const p = $("#evo-pct"); if (p) p.textContent = d.progress_pct + "%";
    const f = $("#evo-fill"); if (f) f.style.width = d.progress_pct + "%";
    const host = $("#evo-phases");
    if (host) {
      host.innerHTML = (d.phases || []).map(ph => `
        <div class="evo-phase" data-n="${ph.n}" tabindex="0" role="button">
          <span class="n">P${ph.n}</span>
          <span class="nm">${escapeHTML(ph.name)}</span>
          <span class="pc">${ph.done}/${ph.total}</span>
          <span class="st ${ph.status}">${ph.status.toUpperCase()}</span>
          <div class="evo-feats">
            ${ph.features.map(ft => `<div class="evo-feat${ft.done ? " done" : ""}">${escapeHTML(ft.name)}</div>`).join("")}
          </div>
        </div>`).join("");
      host.querySelectorAll(".evo-phase").forEach(el => {
        const toggle = () => el.classList.toggle("open");
        el.addEventListener("click", toggle);
        el.addEventListener("keydown", (e) => { if (e.key === "Enter") toggle(); });
      });
      // current (active) phase starts expanded
      host.querySelector(".evo-phase .st.active")?.closest(".evo-phase")?.classList.add("open");
    }
    const dev = $("#evo-dev");
    if (dev) dev.textContent = (d.in_development || []).join(" · ") || "—";
  } catch (e) {}
}
refreshRoadmap(); setInterval(refreshRoadmap, 120000);

// ── local AI control center ──────────────────────────
let _laiSeq = 0;
async function refreshLocalAI() {
  const seq = ++_laiSeq;
  try {
    const [models, stats] = await Promise.all([
      fetch("/api/models").then(r => r.json()),
      fetch("/api/models/stats").then(r => r.json()),
    ]);
    if (seq !== _laiSeq) return;                 // a newer refresh (e.g. after a switch) already won
    const act = $("#lai-active");
    if (act) act.textContent = (models.active_brain || "—").toUpperCase();
    const perf = stats.perf || {};
    const setV = (id, v) => { const el = $(id); if (el) el.textContent = v; };
    setV("#lai-latency", perf.latency_ms != null ? perf.latency_ms + "ms" : "—");
    setV("#lai-tps", perf.tokens_per_sec != null ? perf.tokens_per_sec : "—");
    // running model resources (Ollama /api/ps)
    const run = (stats.running || [])[0];
    setV("#lai-ram", run ? (run.vram_gb > 0 ? `${run.vram_gb}G VRAM` : `${run.ram_gb}G RAM`) : "unloaded");
    setV("#lai-ctx", run && run.context ? (run.context / 1024) + "k" : "—");
    // host memory
    const used = stats.host_ram_used_gb, total = stats.host_ram_total_gb;
    if (total) {
      const fill = $("#lai-host-fill");
      if (fill) fill.style.width = Math.round(used * 100 / total) + "%";
      setV("#lai-host-txt", `${used} / ${total} GB`);
    }
    // installed models — one click to switch the brain (no restart)
    const host = $("#lai-models");
    if (host) {
      const rows = [{ name: "claude", param_size: "CLOUD", quant: "ANTHROPIC" },
                    ...(models.local || [])];
      host.innerHTML = rows.map(m => {
        const isClaude = m.name === "claude";
        // a custom / smart provider answers even with force_local off → then neither row is active
        const viaProvider = /^(provider:|smart$)/.test(models.active_brain || "");
        const activeNow = isClaude ? (!models.force_local && !viaProvider)
                                   : (models.force_local && m.name === models.selected);
        const spec = isClaude ? "ANTHROPIC · CLOUD"
          : [m.param_size, m.quant, m.size_gb ? m.size_gb + "GB" : null].filter(Boolean).join(" · ");
        return `<div class="lai-model${activeNow ? " active" : ""}" data-model="${escapeHTML(m.name)}" tabindex="0" role="button">
          <span class="lai-m-name">${escapeHTML(m.name)}</span>
          <span class="lai-m-spec">${escapeHTML(spec || "")}</span>
          ${activeNow ? '<span class="lai-m-badge">● ACTIVE</span>' : ""}
        </div>`;
      }).join("");
      host.querySelectorAll(".lai-model").forEach(el => {
        const pick = async () => {
          el.style.opacity = "0.5";
          try {
            const r = await (await fetch("/api/models/select", { method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ model: el.dataset.model }) })).json();
            if (!r.ok) logEvent(`<span class="tag">[llm]</span> ${escapeHTML(r.error || "switch refused")}`, "warn");
            else if (r.endpoint_ok === false) logEvent(`<span class="tag">[llm]</span> ${escapeHTML(el.dataset.model)} selected, but the Ollama endpoint did not answer`, "warn");
          } catch (e) { logEvent(`<span class="tag">[llm]</span> switch failed: ${escapeHTML(e.message)}`, "warn"); }
          onBrainChanged();
        };
        el.addEventListener("click", pick);
        el.addEventListener("keydown", (e) => { if (e.key === "Enter") pick(); });
      });
    }
  } catch (e) {}
}
refreshLocalAI(); setInterval(refreshLocalAI, 25000);

// on-prem AI cluster: fleet nodes that can serve inference (Phase 4)
async function refreshCluster() {
  try {
    const d = await (await fetch("/api/cluster")).json();
    const stat = $("#cluster-stat");
    if (stat) stat.textContent = `${d.provider_count} PROVIDER${d.provider_count === 1 ? "" : "S"} · ${d.total_models} MODELS · ${d.gpu_nodes} GPU`;
    const host = $("#lai-cluster"); if (!host) return;
    const provs = d.providers || [];
    host.innerHTML = provs.length ? provs.map(p => {
      const routed = d.routed_remote && d.remote_node === p.name;
      return `<div class="lai-model${routed ? " active" : ""}" data-node="${escapeHTML(p.is_local ? "" : p.node_id)}" tabindex="0" role="button" title="route inference here">
        <span class="lai-m-name">${escapeHTML((p.name || "").toUpperCase())}${p.is_local ? " (LOCAL)" : ""}</span>
        <span class="lai-m-spec">${p.count} MODELS · GPU ${p.gpu == null ? "N/A" : Math.round(p.gpu) + "%"}</span>
        ${routed ? '<span class="lai-m-badge">● ROUTED</span>' : (p.is_local ? "" : '<span class="lai-m-spec">→ ROUTE</span>')}
      </div>`;
    }).join("") : '<div class="tf-empty">no fleet node is advertising Ollama — start Ollama on a node to add inference capacity</div>';
    host.querySelectorAll(".lai-model[data-node]").forEach(el => {
      el.addEventListener("click", async () => {
        el.style.opacity = "0.5";
        try {
          const r = await (await fetch("/api/cluster/route", { method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ node_id: el.dataset.node || null }) })).json();
          if (r.ok) logEvent(`<span class="tag">[cluster]</span> inference routed ${r.remote ? "to " + escapeHTML(String(r.node)) : "back to local"}`);
          else if (r.error) logEvent(`<span class="tag">[cluster]</span> ${escapeHTML(r.error)}`, "warn");
        } catch (e) {}
        onBrainChanged();
      });
    });
  } catch (e) {}
}
refreshCluster(); setInterval(refreshCluster, 20000);

// ── operator productivity ────────────────────────────
let prodSnap = null;
function renderProd(d) {
  prodSnap = d;
  const sc = $("#prod-score"); if (sc) sc.textContent = d.score;
  const setN = (id, v) => { const el = $(id); if (el) el.textContent = v; };
  setN("#pc-focus", d.focus_min_today);
  setN("#pc-sessions", d.sessions_today);
  setN("#pc-switch", d.switches_today);
  setN("#pc-done", d.tasks_done_today);
  const btn = $("#btn-focus");
  if (btn) btn.textContent = d.focus_active ? "■ END SESSION" : "▶ START DEEP WORK";
  const clock = $("#focus-clock");
  if (clock) clock.classList.toggle("live", !!d.focus_active);
  const inp = $("#task-input");
  if (inp && document.activeElement !== inp) inp.value = d.current_task || "";
  tickFocusClock();
}
function tickFocusClock() {
  const clock = $("#focus-clock"); if (!clock || !prodSnap) return;
  let secs = 0;
  if (prodSnap.focus_active) {
    secs = prodSnap.focus_elapsed_sec + Math.floor((Date.now() - prodSnap._rx) / 1000);
  }
  const m = Math.floor(secs / 60), s = secs % 60;
  clock.textContent = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
setInterval(tickFocusClock, 1000);

async function refreshProd() {
  try {
    const d = await (await fetch("/api/productivity")).json();
    d._rx = Date.now();
    renderProd(d);
  } catch (e) {}
}
async function prodAction(body) {
  try {
    const d = await (await fetch("/api/productivity", { method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body) })).json();
    d._rx = Date.now();
    renderProd(d);
  } catch (e) {}
}
refreshProd(); setInterval(refreshProd, 20000);
$("#btn-focus")?.addEventListener("click", () =>
  prodAction({ action: prodSnap && prodSnap.focus_active ? "focus_stop" : "focus_start" }));
$("#task-form")?.addEventListener("submit", (e) => {
  e.preventDefault();
  prodAction({ action: "task", text: $("#task-input").value.trim() });
});
$("#btn-task-done")?.addEventListener("click", () => prodAction({ action: "task_done" }));

// ── knowledge hub ────────────────────────────────────
async function refreshKbStats() {
  try {
    const d = await (await fetch("/api/knowledge/stats")).json();
    const el = $("#kb-stats");
    if (el) el.textContent = `${d.total} ITEMS · ${Object.keys(d.sources || {}).length} SOURCES`;
  } catch (e) {}
}
refreshKbStats(); setInterval(refreshKbStats, 60000);

function renderKbResults(items, answer) {
  const host = $("#kb-results"); if (!host) return;
  let html = "";
  if (answer) html += `<div class="kb-item answer"><div class="kb-src">JARVIS · SYNTHESIZED ANSWER</div>
    <div class="kb-text">${escapeHTML(answer)}</div></div>`;
  html += (items || []).map(r => `
    <div class="kb-item">
      <div class="kb-src">${escapeHTML((r.source || "").toUpperCase())} · ${escapeHTML(r.ref || "")}</div>
      <div class="kb-text">${escapeHTML(r.text)}</div>
    </div>`).join("");
  host.innerHTML = html || '<div class="tf-empty">no matches — try different words</div>';
}
$("#kb-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const q = $("#kb-input").value.trim(); if (!q) return;
  $("#kb-results").innerHTML = '<div class="tf-empty">searching all sources…</div>';
  try {
    const d = await (await fetch("/api/knowledge/search?q=" + encodeURIComponent(q))).json();
    renderKbResults(d.results);
  } catch (err) {}
});
$("#btn-kb-ask")?.addEventListener("click", async () => {
  const q = $("#kb-input").value.trim(); if (!q) return;
  $("#kb-results").innerHTML = '<div class="tf-empty">thinking over the knowledge base…</div>';
  try {
    const d = await (await fetch("/api/knowledge/ask", { method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ query: q }) })).json();
    renderKbResults(d.sources, d.answer);
  } catch (err) {}
});

/* ═══ PHASE 4 · ENTERPRISE COMMAND — roles · operators · audit · export ═══ */

let entState = { role: "commander", pin_required: false };

function auditRow(e) {
  const t = new Date(e.ts * 1000).toTimeString().slice(0, 5);
  return `<div class="aud-row"><span class="aud-t">${t}</span>
    <span class="aud-a"><b>${escapeHTML(e.action)}</b> ${escapeHTML(e.detail || "")}
    <span class="who">· ${escapeHTML(e.operator || "")}/${escapeHTML(e.role || "")}</span></span></div>`;
}
function prependAudit(e) {
  const host = $("#ent-audit"); if (!host) return;
  const empty = host.querySelector(".tf-empty"); if (empty) empty.remove();
  host.insertAdjacentHTML("afterbegin", auditRow(e));
  while (host.children.length > 20) host.lastChild.remove();
  const n = $("#ent-audit-n"); if (n) n.textContent = String(parseInt(n.textContent || "0") + 1);
}

async function refreshEnterprise() {
  try {
    const d = await (await fetch("/api/enterprise")).json();
    entState = d;
    const roleEl = $("#ent-role");
    if (roleEl) roleEl.textContent = (d.role || "—").toUpperCase();
    const opEl = $("#ent-op"); if (opEl) opEl.textContent = d.operator || "—";
    $("#btn-role-cmd")?.classList.toggle("on", d.role === "commander");
    $("#btn-role-obs")?.classList.toggle("on", d.role === "observer");
    document.body.classList.toggle("observer-mode", d.role === "observer");
    // operators
    const ops = $("#ent-ops");
    if (ops) {
      ops.innerHTML = (d.operators || []).map(o =>
        `<span class="ent-opchip${o.name === d.operator ? " active" : ""}" data-name="${escapeHTML(o.name)}" tabindex="0" role="button">
          ${escapeHTML(o.name.toUpperCase())} <span class="r">· ${escapeHTML((o.role || "").toUpperCase())}</span></span>`).join("")
        || '<div class="tf-empty">no operators registered</div>';
      ops.querySelectorAll(".ent-opchip").forEach(ch => ch.addEventListener("click", async () => {
        try {
          let r = await (await fetch("/api/operator", { method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ name: ch.dataset.name }) })).json();
          if (!r.ok && /PIN/.test(r.error || "")) {
            const pin = prompt("Commander PIN for " + ch.dataset.name + ":");
            if (pin) r = await (await fetch("/api/operator", { method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ name: ch.dataset.name, pin }) })).json();
          }
          if (!r.ok && r.error) logEvent(`<span class="tag">[rbac]</span> ${escapeHTML(r.error)}`, "warn");
        } catch (e) {}
        refreshEnterprise();
      }));
    }
    // audit feed
    const aud = (d.audit || {});
    const n = $("#ent-audit-n"); if (n) n.textContent = aud.entries_total ?? 0;
    const host = $("#ent-audit");
    if (host) host.innerHTML = (aud.recent || []).map(auditRow).join("")
      || '<div class="tf-empty">no audited actions yet</div>';
  } catch (e) {}
}
refreshEnterprise(); setInterval(refreshEnterprise, 45000);

async function switchRole(role) {
  const pinEl = $("#ent-pin");
  if (role === "commander" && entState.pin_required) {
    if (pinEl && pinEl.hidden) { pinEl.hidden = false; pinEl.focus(); return; }
  }
  try {
    const d = await (await fetch("/api/role", { method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ role, pin: pinEl ? pinEl.value : "" }) })).json();
    if (!d.ok && d.error) logEvent(`<span class="tag">[rbac]</span> ${escapeHTML(d.error)}`, "warn");
    if (pinEl) { pinEl.hidden = true; pinEl.value = ""; }
  } catch (e) {}
  refreshEnterprise();
}
$("#btn-role-cmd")?.addEventListener("click", () => switchRole("commander"));
$("#btn-role-obs")?.addEventListener("click", () => switchRole("observer"));
$("#ent-pin")?.addEventListener("keydown", (e) => { if (e.key === "Enter") switchRole("commander"); });

$("#ent-op-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = $("#ent-op-input").value.trim(); if (!name) return;
  $("#ent-op-input").value = "";
  try {
    const d = await (await fetch("/api/operators", { method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, role: "observer" }) })).json();
    if (!d.ok && d.error) logEvent(`<span class="tag">[rbac]</span> ${escapeHTML(d.error)}`, "warn");
  } catch (err) {}
  refreshEnterprise();
});

$("#btn-export")?.addEventListener("click", async () => {
  try {
    const d = await (await fetch("/api/export")).json();
    if (d.error) { logEvent(`<span class="tag">[export]</span> ${escapeHTML(d.error)}`, "warn"); return; }
    const blob = new Blob([JSON.stringify(d, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `bobbiey-ucs-export-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    logEvent('<span class="tag">[export]</span> compliance data export downloaded');
  } catch (e) {}
});

/* ═══ EXTERNAL HARDWARE — power · storage · network · peripherals ═══ */

const CLS_ICON = { Camera: "◉", Bluetooth: "❋", WPD: "▤", AudioEndpoint: "♪",
                   DiskDrive: "▤", Monitor: "▢", Image: "◈" };

async function refreshHardware() {
  try {
    const d = await (await fetch("/api/hardware")).json();
    // power
    const pw = $("#hw-power");
    if (pw) {
      const p = d.power || {};
      if (p.present) {
        const lvl = p.percent < 20 ? "low" : p.percent < 50 ? "mid" : "";
        pw.innerHTML = `<span class="hw-batt"><div class="${lvl}" style="width:${p.percent}%"></div></span>
          <span class="hw-pct">${p.percent}%</span>
          <span class="hw-ac ${p.plugged ? "on" : ""}">${p.plugged ? "⚡ CHARGING" : "ON BATTERY"}</span>`;
      } else {
        pw.innerHTML = `<span class="hw-pct" style="min-width:auto">AC</span>
          <span class="hw-ac on">⚡ MAINS POWER · NO BATTERY</span>`;
      }
    }
    // storage volumes
    const vh = $("#hw-vols");
    if (vh) {
      const vols = d.volumes || [];
      vh.innerHTML = vols.length ? vols.map(v => `
        <div class="hw-vol">
          <span class="nm">${escapeHTML(v.name)}</span>
          <span class="bar"><div class="${v.used_pct >= 90 ? "hot" : ""}" style="width:${v.used_pct}%"></div></span>
          <span class="pc">${v.used_pct}% · ${v.total_gb}G</span>
          ${v.removable ? '<span class="tag">USB</span>' : `<span class="pc" style="text-align:left">${escapeHTML(v.fstype)}</span>`}
        </div>`).join("") : '<div class="tf-empty">no volumes detected</div>';
    }
    // network interfaces
    const nh = $("#hw-nets");
    if (nh) {
      const nets = d.net || [];
      const nn = $("#hw-net-n"); if (nn) nn.textContent = nets.length;
      nh.innerHTML = nets.map(n =>
        `<span class="hw-net"><b>${escapeHTML(n.name)}</b>${n.speed_mbps ? " · " + n.speed_mbps + "M" : ""}${n.addr ? " · " + escapeHTML(n.addr) : ""}</span>`).join("");
    }
    // peripherals
    const ph = $("#periph-list");
    if (ph) {
      const per = d.peripherals || [];
      const pn = $("#periph-n"); if (pn) pn.textContent = per.length || "0";
      ph.innerHTML = per.length ? per.map(x => `
        <div class="periph-item">
          <span class="nm">${escapeHTML(CLS_ICON[x.cls] || "▪")} ${escapeHTML(x.name)}</span>
          <span class="cls">${escapeHTML(x.cls.toUpperCase())}</span>
          <span class="st ${x.ok ? "" : "err"}"></span>
        </div>`).join("")
        : '<div class="tf-empty">device enumeration unavailable on this OS</div>';
    }
  } catch (e) {}
}
refreshHardware(); setInterval(refreshHardware, 20000);

/* ═══ PHASE 4 · COMMAND FLEET — multi-site node telemetry ═══ */

function nodeBar(label, pct) {
  const cls = pct >= 90 ? "hot" : pct >= 70 ? "warm" : "";
  return `<div class="nb"><span class="nb-l">${label}</span>
    <span class="nb-bar"><div class="${cls}" style="width:${Math.min(100, pct || 0)}%"></div></span>
    <span class="nb-v">${pct == null ? "—" : Math.round(pct) + "%"}</span></div>`;
}
function humanUptime(min) {
  if (min == null) return "—";
  if (min < 60) return min + "m";
  const h = Math.floor(min / 60);
  return h < 24 ? `${h}h` : `${Math.floor(h / 24)}d ${h % 24}h`;
}
function humanSeen(sec) {
  if (sec == null) return "—";
  if (sec < 60) return sec + "s ago";
  if (sec < 3600) return Math.floor(sec / 60) + "m ago";
  return Math.floor(sec / 3600) + "h ago";
}

// plot the live fleet on the world map (real projected coordinates)
function renderFleetOnMap(nodes) {
  // legacy world SVG only; skipped once globalmap.js owns the panel
  const host = document.getElementById("map-fleet");
  if (!host || window.GlobalMap || !mapProjection) return;
  host.innerHTML = "";
  // command-link lines: host node → every other node (a live command network)
  const local = nodes.find(n => n.is_local && n.lat != null);
  if (local) {
    const lxy = projectCity({ lat: local.lat, lon: local.lon });
    if (isFinite(lxy[0])) {
      for (const n of nodes) {
        if (n.is_local || n.lat == null) continue;
        const xy = projectCity({ lat: n.lat, lon: n.lon });
        if (!isFinite(xy[0])) continue;
        const mx = (lxy[0] + xy[0]) / 2, my = Math.min(lxy[1], xy[1]) - 24;
        const col = n.status === "online" ? "#22c55e" : "#7e96b3";
        const p = document.createElementNS("http://www.w3.org/2000/svg", "path");
        p.setAttribute("d", `M ${lxy[0]} ${lxy[1]} Q ${mx} ${my} ${xy[0]} ${xy[1]}`);
        p.setAttribute("fill", "none");
        p.setAttribute("stroke", col);
        p.setAttribute("stroke-width", "0.8");
        p.setAttribute("stroke-dasharray", "3 4");
        p.setAttribute("opacity", "0.4");
        if (n.status === "online")
          p.innerHTML = '<animate attributeName="stroke-dashoffset" values="14;0" dur="1.2s" repeatCount="indefinite"/>';
        host.appendChild(p);
      }
    }
  }
  for (const n of nodes) {
    if (n.lat == null || n.lon == null) continue;
    const xy = projectCity({ lat: n.lat, lon: n.lon });
    const x = xy[0], y = xy[1];
    if (!isFinite(x) || !isFinite(y)) continue;
    const col = n.status === "online" ? "#22c55e" : n.status === "stale" ? "#facc15" : "#7e96b3";
    const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
    g.setAttribute("class", "fleet-marker" + (n.is_local ? " local" : ""));
    g.innerHTML = `
      <circle cx="${x}" cy="${y}" r="5" fill="none" stroke="${col}" stroke-width="1" opacity="0.5">
        ${n.status === "online" ? '<animate attributeName="r" values="4;10;4" dur="2.5s" repeatCount="indefinite"/><animate attributeName="opacity" values="0.6;0;0.6" dur="2.5s" repeatCount="indefinite"/>' : ""}
      </circle>
      <circle cx="${x}" cy="${y}" r="${n.is_local ? 4 : 3}" fill="${col}"/>
      <text x="${x + 8}" y="${y + 3}" fill="${col}" font-family="Orbitron" font-size="8" opacity="0.9">${(n.name || "").slice(0, 14).toUpperCase()}</text>`;
    host.appendChild(g);
  }
}

async function refreshFleet() {
  try {
    const d = await (await fetch("/api/fleet")).json();
    try { renderFleetOnMap(d.nodes || []); } catch (e) {}
    const agg = d.aggregate || {};
    const stat = $("#fleet-stat");
    if (stat) stat.textContent = `${agg.online}/${agg.nodes} ONLINE`;
    // the world-map badge reflects the REAL fleet, not a placeholder count
    const mapNodes = $("#map-nodes");
    if (mapNodes) mapNodes.textContent = `${agg.nodes} NODE${agg.nodes === 1 ? "" : "S"}`;
    const aggEl = $("#fleet-agg");
    if (aggEl) aggEl.innerHTML = [
      ["NODES", agg.nodes], ["ONLINE", agg.online],
      ["TOTAL CORES", agg.cpu_cores], ["TOTAL RAM", (agg.mem_total_gb || 0) + "G"],
      ["FLEET CPU", (agg.avg_cpu || 0) + "%"],
    ].map(([k, v]) => `<span class="chip">${k} <b>${v}</b></span>`).join("");
    const host = $("#fleet-nodes");
    if (host) {
      const nodes = d.nodes || [];
      host.innerHTML = nodes.length ? nodes.map((n, i) => `
        <div class="node-card ${n.status} ${n.is_local ? "local" : ""}" data-idx="${i}">
          <div class="node-head">
            <span class="node-dot ${n.status}"></span>
            <span class="node-name">${escapeHTML(n.name || "node")}${n.is_local ? '<span class="node-local">LOCAL</span>' : ""}</span>
            <span class="node-plat">${escapeHTML(n.platform || "")}</span>
          </div>
          <div class="node-bars">
            ${nodeBar("CPU", n.cpu)}${nodeBar("MEM", n.mem)}${nodeBar("DISK", n.disk)}
          </div>
          <div class="node-foot">${n.cpu_cores || "?"} cores · ${n.mem_total_gb || "?"}G RAM · GPU ${n.gpu == null ? "N/A" : Math.round(n.gpu) + "%"} · up ${humanUptime(n.uptime_min)} · ${n.status === "online" ? humanSeen(n.last_seen_sec) : "<b style='color:var(--text-dim)'>" + n.status.toUpperCase() + "</b>"}</div>
        </div>`).join("") : '<div class="tf-empty">no nodes reporting</div>';
      // click a node → full hardware detail
      host.querySelectorAll(".node-card").forEach(c => c.addEventListener("click", () => {
        const n = nodes[+c.dataset.idx]; if (!n) return;
        const vols = (n.volumes || []).map(v => `${v.name} ${v.used_pct}% of ${v.total_gb}G`).join(" · ") || "—";
        const per = (n.peripherals || []).map(p => p.name).join(", ") || "none reported";
        const nets = (n.net || []).map(x => `${x.name}${x.addr ? " " + x.addr : ""}`).join(" · ") || "—";
        openCustomModal(n.name + (n.is_local ? " · LOCAL HOST" : ""),
          `${n.platform} · ${n.status.toUpperCase()}`, null,
          `<div class="mb-grid">
            <div class="mb-stat"><span class="lbl">CPU</span><span class="val">${escapeHTML(String(n.cpu))}% · ${escapeHTML(String(n.cpu_cores))} cores</span></div>
            <div class="mb-stat"><span class="lbl">MEMORY</span><span class="val">${escapeHTML(String(n.mem))}% of ${escapeHTML(String(n.mem_total_gb))}G</span></div>
            <div class="mb-stat"><span class="lbl">GPU</span><span class="val">${n.gpu == null ? "N/A" : Math.round(n.gpu) + "%"}</span></div>
            <div class="mb-stat"><span class="lbl">UPTIME</span><span class="val">${humanUptime(n.uptime_min)}</span></div>
          </div>
          <div class="mb-list"><div class="mb-row"><b>Storage:</b> ${escapeHTML(vols)}</div>
          <div class="mb-row"><b>Network:</b> ${escapeHTML(nets)}</div>
          <div class="mb-row"><b>Peripherals:</b> ${escapeHTML(per)}</div></div>`);
      }));
    }
  } catch (e) {}
}
refreshFleet(); setInterval(refreshFleet, 8000);

// join instructions (token only fetches successfully on the host machine)
async function renderFleetJoin() {
  const body = $("#fleet-add-body"); if (!body) return;
  let code = "------";
  try {
    const p = await (await fetch("/api/fleet/paircode")).json();
    if (p.code) code = p.code;
  } catch (e) {}
  const origin = location.origin.includes("127.0.0.1") || location.origin.includes("localhost")
    ? "http://<THIS-LAPTOP-LAN-IP>:8765" : location.origin;
  const macCmd = `./join-fleet.sh ${origin}`;
  const winCmd = `join-fleet.cmd ${origin}`;
  body.innerHTML = `
    <div class="pair-code-box">
      <div class="pair-code-label">ACCESS CODE</div>
      <div class="pair-code" id="pair-code" title="click to copy">${escapeHTML(code)}</div>
      <button class="cmd-btn" id="btn-rotate-code" title="generate a new code">↻ ROTATE</button>
    </div>
    <b>1.</b> On the other laptop: <b>git clone</b> this repo, then <code>cd</code> into it.<br>
    <b>2.</b> Run ONE command — it auto-installs what it needs and asks for the code above:
    <div class="fleet-cmd" data-cmd="mac" title="click to copy">macOS / Linux&nbsp;&nbsp;${escapeHTML(macCmd)}</div>
    <div class="fleet-cmd" data-cmd="win" title="click to copy">Windows&nbsp;&nbsp;${escapeHTML(winCmd)}</div>
    <b>3.</b> Type the 6-character code. The node appears here within seconds.
    ${origin.includes("LAN-IP") ? "<br><br>Replace <b>&lt;THIS-LAPTOP-LAN-IP&gt;</b> with this machine's Wi-Fi IP (run <b>ipconfig</b>); the server already binds <b>0.0.0.0</b> when JARVIS_HOST is set in .env." : ""}
    <br><br><span style="opacity:0.7">Both machines must be on the same network. On office Wi-Fi that blocks device-to-device traffic, use a phone hotspot for both.</span>`;
  const cp = (txt, msg) => navigator.clipboard?.writeText(txt).then(() =>
    logEvent(`<span class="tag">[fleet]</span> ${msg}`)).catch(() => {});
  body.querySelector("#pair-code")?.addEventListener("click", () => cp(code, "access code copied"));
  body.querySelectorAll(".fleet-cmd").forEach(el => el.addEventListener("click", () =>
    cp(el.dataset.cmd === "win" ? winCmd : macCmd, "join command copied")));
  body.querySelector("#btn-rotate-code")?.addEventListener("click", async () => {
    try {
      const r = await (await fetch("/api/fleet/paircode/rotate", { method: "POST" })).json();
      if (r.ok) { logEvent('<span class="tag">[fleet]</span> access code rotated — old code now invalid'); renderFleetJoin(); }
      else if (r.error) logEvent(`<span class="tag">[fleet]</span> ${escapeHTML(r.error)}`, "warn");
    } catch (e) {}
  });
}
renderFleetJoin();

/* ═══ PHASE 5 · DECISION SUPPORT — propose · simulate · execute ═══ */

let decAutonomy = false;

async function refreshDecisions() {
  try {
    const d = await (await fetch("/api/decisions")).json();
    decAutonomy = !!d.autonomy;
    const btn = $("#btn-autonomy");
    if (btn) {
      btn.textContent = decAutonomy ? "◈ AUTONOMY ON" : "◇ AUTONOMY OFF";
      btn.classList.toggle("on", decAutonomy);
    }
    const note = $("#dec-auto-note");
    if (note) note.textContent = decAutonomy
      ? `auto-executes: ${(d.whitelist || []).join(", ")} · every action audited`
      : "low-risk whitelist only · every action audited";
    const cnt = $("#dec-count"); if (cnt) cnt.textContent = (d.proposals || []).length;
    const list = $("#dec-list");
    if (list) {
      list.innerHTML = (d.proposals || []).length ? d.proposals.map(p => `
        <div class="dec-item ${p.risk}">
          <div class="dec-title">${escapeHTML(p.title)}</div>
          <div class="dec-why">${escapeHTML(p.rationale || "")}</div>
          <div class="dec-impact">${escapeHTML(p.impact || "")}</div>
          <div class="dec-actions">
            <button class="dec-btn ok" data-id="${escapeHTML(p.id)}" data-act="execute">✓ APPROVE</button>
            <button class="dec-btn no" data-id="${escapeHTML(p.id)}" data-act="dismiss">✕ DISMISS</button>
          </div>
        </div>`).join("")
        : '<div class="tf-empty">no proposals — conditions don\'t warrant action</div>';
      list.querySelectorAll(".dec-btn").forEach(b => b.addEventListener("click", async () => {
        b.disabled = true; b.textContent = "…";
        try {
          const r = await (await fetch("/api/decisions/" + b.dataset.act, {
            method: "POST", headers: { "content-type": "application/json" },
            body: JSON.stringify({ id: b.dataset.id }) })).json();
          if (!r.ok && r.error) logEvent(`<span class="tag">[decision]</span> ${escapeHTML(r.error)}`, "warn");
          else if (r.note) logEvent(`<span class="tag">[decision]</span> executed — ${escapeHTML(r.note)}`);
        } catch (e) {}
        refreshDecisions(); refreshProd(); seedThreats();
      }));
    }
    const en = $("#dec-exec-n"); if (en) en.textContent = d.executed_total ?? 0;
    const done = $("#dec-done");
    if (done) {
      done.innerHTML = (d.executed || []).length ? d.executed.slice(0, 4).map(x => `
        <div class="dec-done-item"><b>✓</b> ${escapeHTML(x.title)} — ${escapeHTML(x.note || "")}
          <span class="by">${x.by === "autonomy" ? "AUTO" : "APPROVED"}</span></div>`).join("")
        : '<div class="tf-empty">nothing executed yet</div>';
    }
  } catch (e) {}
}
refreshDecisions(); setInterval(refreshDecisions, 30000);

$("#btn-autonomy")?.addEventListener("click", async () => {
  try {
    const r = await (await fetch("/api/decisions/autonomy", {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ on: !decAutonomy }) })).json();
    if (!r.ok && r.error) logEvent(`<span class="tag">[decision]</span> ${escapeHTML(r.error)}`, "warn");
  } catch (e) {}
  refreshDecisions();
});

/* ═══ PHASE 4 · REMOTE ACCESS & AUTH — the perimeter panel ═══ */

async function refreshSecurity() {
  try {
    const [st, panel] = await Promise.all([
      (await fetch("/api/auth/status")).json(),
      (await fetch("/api/auth/panel")).json(),
    ]);
    const lanExposed = st.binding !== "127.0.0.1";
    const state = $("#sec-state");
    if (state) state.textContent = lanExposed
      ? (st.password_set ? "LAN · SECURED" : "LAN · REMOTE DISABLED")
      : "LOCAL ONLY";
    const status = $("#sec-status");
    if (status) {
      status.innerHTML = [
        [`BINDING <b>${escapeHTML(st.binding)}</b>`, lanExposed ? "warn" : "ok"],
        [st.password_set ? "PASSWORD <b>ARMED</b>" : "PASSWORD <b>NOT SET</b>",
         st.password_set ? "ok" : (lanExposed ? "warn" : "")],
        [`SESSIONS <b>${(panel.sessions || []).length}</b>`, ""],
        [`TOKENS <b>${(panel.tokens || []).length}</b>`, ""],
        [lanExposed && !st.password_set
          ? "REMOTE <b>BLOCKED UNTIL ARMED</b>" : `REMOTE <b>${lanExposed ? "LOGIN REQUIRED" : "OFF"}</b>`,
         lanExposed && !st.password_set ? "err" : "ok"],
      ].map(([t, c]) => `<span class="sec-chip ${c}">${t}</span>`).join("");
    }
    const tn = $("#sec-tok-n"); if (tn) tn.textContent = (panel.tokens || []).length;
    const toks = $("#sec-tokens");
    if (toks) {
      toks.innerHTML = (panel.tokens || []).map(t => `
        <div class="sec-row">
          <span class="nm">🔑 ${escapeHTML(t.label)}</span>
          <span class="meta">${escapeHTML(t.prefix)}…</span>
          <button class="sec-revoke" data-prefix="${escapeHTML(t.prefix)}" title="revoke token">✕</button>
        </div>`).join("");
      toks.querySelectorAll(".sec-revoke").forEach(b => b.addEventListener("click", async () => {
        await fetch("/api/auth/revoke", { method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ prefix: b.dataset.prefix }) }).catch(() => {});
        refreshSecurity();
      }));
    }
    const sn = $("#sec-ses-n"); if (sn) sn.textContent = (panel.sessions || []).length;
    const ses = $("#sec-sessions");
    if (ses) {
      ses.innerHTML = (panel.sessions || []).length ? panel.sessions.map(s => `
        <div class="sec-row">
          <span class="nm">◉ ${escapeHTML(s.ip)}</span>
          <span class="meta">${s.age_min}m · ${escapeHTML((s.ua || "").split(" ")[0].slice(0, 18))}</span>
          <button class="sec-revoke" data-sid="${escapeHTML(s.sid)}" title="revoke session">✕</button>
        </div>`).join("") : '<div class="tf-empty">no remote sessions</div>';
      ses.querySelectorAll(".sec-revoke").forEach(b => b.addEventListener("click", async () => {
        await fetch("/api/auth/revoke", { method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ sid: b.dataset.sid }) }).catch(() => {});
        refreshSecurity();
      }));
    }
    // off-host: setting password / minting tokens is disabled by the server
    const onHost = panel.on_host !== false;
    ["#sec-pw", "#btn-sec-pw", "#sec-tok-label"].forEach(sel => {
      const el = $(sel); if (el) el.disabled = !onHost;
    });
    if (!onHost) {
      const pw = $("#sec-pw"); if (pw) pw.placeholder = "password changes: host console only";
    }
  } catch (e) {}
}
refreshSecurity(); setInterval(refreshSecurity, 60000);

$("#sec-pw-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const pw = $("#sec-pw").value;
  if (pw.length < 8) { logEvent('<span class="tag">[auth]</span> password must be 8+ characters', "warn"); return; }
  try {
    const d = await (await fetch("/api/auth/password", { method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ password: pw }) })).json();
    if (d.ok) { $("#sec-pw").value = ""; logEvent('<span class="tag">[auth]</span> remote access armed — password set'); }
    else if (d.error) logEvent(`<span class="tag">[auth]</span> ${escapeHTML(d.error)}`, "warn");
  } catch (err) {}
  refreshSecurity();
});

$("#sec-tok-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const label = $("#sec-tok-label").value.trim() || "token";
  try {
    const d = await (await fetch("/api/auth/token", { method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ label }) })).json();
    const once = $("#sec-token-once");
    if (d.ok && d.token && once) {
      once.hidden = false;
      once.innerHTML = `${escapeHTML(d.token)}<small>COPY NOW — SHOWN ONLY ONCE · CLICK TO COPY</small>`;
      once.onclick = () => navigator.clipboard?.writeText(d.token).then(() =>
        logEvent('<span class="tag">[auth]</span> token copied to clipboard')).catch(() => {});
      $("#sec-tok-label").value = "";
    } else if (d.error) logEvent(`<span class="tag">[auth]</span> ${escapeHTML(d.error)}`, "warn");
  } catch (err) {}
  refreshSecurity();
});

connect();

/* ═══ SECTION INFO — click any section title for what it is, where its data
   comes from, and the live values behind it. Everything shown is read from
   the real endpoint at click time; nothing here is invented. ═══ */
const _siNum = (v, unit = "") => (v == null || v === "" ? "—" : `${typeof v === "number" ? Math.round(v * 10) / 10 : v}${unit}`);
const _siAgo = (ts) => {
  if (!ts) return "—";
  const s = Math.max(0, Date.now() / 1000 - ts);
  return s < 90 ? `${Math.round(s)} s ago` : s < 5400 ? `${Math.round(s / 60)} min ago` : `${Math.round(s / 3600)} h ago`;
};
const _siDom = (sel, n = 8) => [...document.querySelectorAll(sel)].slice(0, n)
  .map(el => el.textContent.replace(/\s+/g, " ").trim()).filter(Boolean);

const THREATS = {
  api: "/api/threats",
  source: "threats.py — scored every cycle from this machine's live telemetry (CPU, memory, disk, network), agenda pressure and open incidents.",
  stats: d => [["RISK SCORE", d.risk_score], ["LEVEL", (d.level || "").toUpperCase()], ["EVENTS", (d.events || []).length],
    ["ANALYZED", d.soc?.analyzed], ["ALERTS", d.soc?.alerts], ["RESOLVED", d.soc?.resolved], ["ACKED", d.acked]],
  list: d => (d.events || []).slice(0, 8).map(e => `${(e.severity || "").toUpperCase()} · ${e.category} — ${e.title}`),
};
const AIOPS = {
  api: "/api/aiops",
  source: "insights.py — the AI engine analyses live telemetry, agenda and the webcam presence signal, then writes ranked insights.",
  stats: d => [["READINESS", _siNum(d.readiness, "%")], ["ANOMALY", _siNum(d.anomaly, "%")], ["ENGINE", d.engine?.source],
    ["MODEL", d.engine?.model], ["LAST RUN", _siAgo(d.engine?.last_run)], ["LATENCY", _siNum(d.engine?.latency_ms, " ms")],
    ["PRESENCE", d.presence?.state]],
  list: d => (d.insights || []).slice(0, 8).map(i => `${(i.severity || "").toUpperCase()} · ${i.insight}`),
};
const WEB3 = {
  api: "/api/web3",
  source: "web3 module — optional. Chain status and wallet balances are read live over public RPC; nothing moves funds and the module is inert while disabled.",
  stats: d => [["MODULE", d.enabled ? "ENABLED" : "DISABLED"], ["CHAIN", d.chain?.name], ["RPC", d.chain?.online ? "ONLINE" : "OFFLINE"],
    ["BLOCK", d.chain?.block], ["GAS", _siNum(d.chain?.gas_gwei, " gwei")], ["WALLET", d.wallet ? shortAddr(d.wallet.address || d.wallet) : "none"],
    ["TOKEN CONTRACT", d.config?.has_contract ? "configured" : "not configured"]],
};
const TELEMETRY = {
  api: "/api/status",
  source: "psutil on this machine, sampled every second and pushed over the /ws WebSocket.",
  stats: d => [["CPU", _siNum(d.metrics?.cpu, "%")], ["MEMORY", _siNum(d.metrics?.mem, "%")], ["DISK", _siNum(d.metrics?.disk, "%")],
    ["NET ↓", _siNum(d.metrics?.net_down, " KB/s")], ["NET ↑", _siNum(d.metrics?.net_up, " KB/s")]],
};
const MEMORY = {
  api: "/api/memory",
  source: "memory.py — operator_memory.json on this machine (enrolment, facts you taught, webcam observations).",
  stats: d => [["OPERATOR", d.name], ["ENROLLED", d.enrolled ? "YES" : "NO"], ["FACTS", (d.facts || []).length],
    ["ARRIVALS TODAY", d.arrivals_today], ["ACTIVE TODAY", _siNum(d.active_minutes_today, " min")], ["SESSIONS", d.sessions_total],
    ["GUEST SIGHTINGS", d.guest_sightings]],
  list: d => (d.observations || []).slice(-6).reverse().map(o => `${new Date(o.ts * 1000).toLocaleTimeString()} · ${o.text}`),
};
const MODELS = {
  api: "/api/models/stats",
  source: "Ollama's /api/ps + measured latency of the last local completions. Click the LLM row in the stage panel to switch brains.",
  stats: d => [["SELECTED", d.selected], ["ENDPOINT", d.endpoint_online ? "ONLINE" : "OFFLINE"], ["LATENCY", _siNum(d.perf?.latency_ms, " ms")],
    ["TOKENS/S", _siNum(d.perf?.tokens_per_sec)], ["CALLS", d.perf?.calls_total], ["HOST RAM", `${_siNum(d.host_ram_used_gb)} / ${_siNum(d.host_ram_total_gb)} GB`]],
  list: d => (d.running || []).map(r => `${r.name} · ${_siNum(r.ram_gb, " GB RAM")} · ${_siNum(r.vram_gb, " GB VRAM")}`),
};
const AGENDA = {
  api: "/api/agenda",
  source: "google_sync.py — your Google Calendar, Gmail and Tasks (read-only OAuth), synced every few minutes.",
  stats: d => [["SOURCE", (d.source || "").toUpperCase()], ["EVENTS TODAY", d.events_today], ["MEETING MIN", d.intel?.meeting_minutes],
    ["CONFLICTS", d.intel?.conflicts], ["FREE BLOCK", _siNum(d.intel?.largest_free_block_min, " min")], ["NEXT", d.intel?.next_title]],
  list: d => (d.events || []).slice(0, 8).map(e => `${new Date(e.start_ts * 1000).toLocaleString([], { weekday: "short", hour: "2-digit", minute: "2-digit" })} · ${e.title}`),
};
const HARDWARE = {
  api: "/api/hardware",
  source: "psutil + Windows PnP device query — volumes, adapters, battery and attached peripherals on this machine.",
  stats: d => [["POWER", d.power?.present ? `${_siNum(d.power.percent, "%")} ${d.power.plugged ? "· plugged" : ""}` : "AC (no battery)"],
    ["VOLUMES", (d.volumes || []).length], ["ADAPTERS", (d.net || []).length], ["PERIPHERALS", (d.peripherals || []).length]],
  list: d => [...(d.volumes || []).map(v => `${v.mount} ${v.fstype} · ${_siNum(v.used_pct, "%")} of ${_siNum(v.total_gb, " GB")}`),
    ...(d.peripherals || []).map(p => `${p.ok ? "●" : "○"} ${p.cls} · ${p.name}`)],
};
const GEO = {
  api: "/api/geo",
  source: "Static, hand-traced map outlines; the location pin comes from your public IP (ip-geo lookup) and the fleet nodes from /api/fleet.",
  stats: d => [["CITY", d.city], ["REGION", d.region], ["COUNTRY", d.country], ["ISP", d.isp], ["LAT/LON", `${_siNum(d.lat)}, ${_siNum(d.lon)}`], ["SOURCE", d.source]],
};

const SECTION_INFO = {
  "AVENGERS · ROSTER": { about: "The eight AI agents. Each runs its own routine and can be addressed by name.",
    api: "/api/status", source: "agents.py — live status pushed over /ws; replies come from the active LLM.",
    stats: d => [["AGENTS", (d.agents || []).length], ["BRAIN", (d.brain_mode || "").toUpperCase()], ["VOICE OUT", d.tts_enabled ? "ON" : "OFF"]],
    list: d => (d.agents || []).map(a => `${a.codename} — ${a.role} · ${a.status}`) },
  "EVENT STREAM": { about: "Everything the system does, as it happens: commands, agent actions, alerts. Mute it with the speaker toggle in Conversation Mode.",
    api: "/api/engine", source: "hub.py WebSocket broadcast; command latency from realtime.py.",
    stats: d => [["COMMANDS", d.totals?.commands], ["FAST PATH", d.totals?.fast], ["LLM", d.totals?.llm], ["CANCELLED", d.totals?.cancelled],
      ["FAILED", d.totals?.failed], ["FIRST TOKEN p50", _siNum(d.first_token_p50_ms, " ms")], ["FIRST SPEECH p50", _siNum(d.first_speech_p50_ms, " ms")]] },
  "WORLD CLOCKS": { about: "Local time in the cities you track.", api: null,
    source: "Your computer's clock, formatted in the browser (Intl API). No network involved.",
    stats: () => [["LOCAL", new Date().toLocaleTimeString()], ["UTC", new Date().toUTCString().slice(17, 25)],
      ["TIMEZONE", Intl.DateTimeFormat().resolvedOptions().timeZone]] },
  "AGENDA": { about: "Your next meetings, with conflicts and free blocks worked out.", ...AGENDA },
  "INBOX": { about: "Priority unread mail from Gmail (read-only).", api: "/api/agenda", source: AGENDA.source,
    stats: d => [["PRIORITY UNREAD", d.priority_unread], ["SHOWN", (d.emails || []).length], ["SOURCE", (d.source || "").toUpperCase()]],
    list: d => (d.emails || []).map(e => `${e.sender} — ${e.subject}`) },
  "WORLD FEED": { about: "Live headlines, refreshed every 10 minutes.", api: "/api/status",
    source: "open_news.py — keyless open feeds (BBC World, The Hindu, Al Jazeera, The Hacker News, Hacker News). Real headlines only.",
    stats: d => [["HEADLINES", d.news_count], ["SOURCE", (d.news_source || "").toUpperCase()]], list: () => _siDom("#news-list > *") },
  "VISION DIGEST": { about: "A short synthesis of what the system observed in the last cycle.", api: "/api/digest",
    source: "insights.py digest() — built from the webcam presence signal + live telemetry.",
    stats: d => [["KIND", d.kind], ["WRITTEN", _siAgo(d.ts)]], list: d => d.msg ? [d.msg] : [] },
  "INDIA · NATIONAL GRID": { about: "National view with your state highlighted.", ...GEO },
  "GLOBAL ACTIVITY MAP": { about: "Where this node and your fleet nodes are.", ...GEO },
  "TELANGANA · STATE": { about: "State view with district outlines.", ...GEO },
  "THREAT MONITOR": { about: "Current risk level and the newest events.", ...THREATS },
  "THREAT MATRIX": { about: "Risk split by domain (operational, infrastructure, network, AI, resource, security).", ...THREATS,
    stats: d => Object.entries(d.matrix || {}).map(([k, v]) => [k.toUpperCase(), typeof v === "object" ? _siNum(v.score ?? v.level ?? JSON.stringify(v)) : v]) },
  "THREAT ANALYTICS": { about: "Risk score history and event mix.", ...THREATS },
  "SECURITY OPERATIONS": { about: "SOC counters: analysed, alerting, resolved.", ...THREATS },
  "INCIDENT RESPONSE TIMELINE": { about: "The response queue: incidents waiting for action.", ...THREATS,
    list: d => (d.response_queue || []).map(e => `${(e.severity || "").toUpperCase()} · ${e.title}`) },
  "TELEMETRY ANALYSIS": { about: "Live machine load and readiness.", ...TELEMETRY },
  "RESOURCE MONITOR": { about: "CPU, memory and disk on this machine.", ...TELEMETRY },
  "STRATEGIC INTELLIGENCE": { about: "Ranked insights and the services that feed them.", ...AIOPS },
  "JARVIS INSIGHTS": { about: "What JARVIS noticed and what it recommends.", ...AIOPS },
  "PREDICTIVE ANALYTICS": { about: "Short-term CPU/memory trend forecast from recent samples.", ...AIOPS },
  "AI REASONING": { about: "Which engine produced the last analysis, and how fast.", ...AIOPS },
  "AI OBSERVATION LOG": { about: "Recent webcam observations (only when the camera is on).", ...MEMORY },
  "MISSION READINESS": { about: "One score combining load, risk and schedule pressure.", ...AIOPS },
  "VISION AWARENESS": { about: "Presence and motion from the webcam, processed locally.", ...AIOPS },
  "AI PERFORMANCE": { about: "Speed and memory use of the local model.", ...MODELS },
  "LOCAL AI CONTROL CENTER": { about: "Local models installed in Ollama, and which one is loaded.", ...MODELS },
  "OPERATOR RECOGNITION": { about: "Whether the enrolled operator is at the desk.", ...MEMORY },
  "OPERATOR MEMORY": { about: "What BUCS remembers about you: facts and the Commander profile.", ...MEMORY },
  "ACTIVITY TIMELINE": { about: "Your presence across the 24 hours of today.", ...MEMORY,
    list: d => (d.hourly_activity || []).map((v, h) => v ? `${String(h).padStart(2, "0")}:00 · ${v} min` : null).filter(Boolean) },
  "OPERATOR PRODUCTIVITY": { about: "Focus sessions, task switches and the day's score.", api: "/api/productivity",
    source: "productivity.py — focus timer + presence minutes, stored locally.",
    stats: d => [["SCORE", d.score], ["FOCUS", `${_siNum(d.focus_min_today)} / ${_siNum(d.focus_target_min)} min`], ["SESSIONS", d.sessions_today],
      ["SWITCHES", d.switches_today], ["TASKS DONE", d.tasks_done_today], ["PRESENT", _siNum(d.presence_min_today, " min")], ["CURRENT", d.current_task || "—"]] },
  "NOTES": { about: "Quick notes, stored on this machine.", api: "/api/notes", source: "notes in the local data store.",
    stats: d => [["NOTES", (d.notes || []).length]], list: d => (d.notes || []).slice(0, 8).map(n => n.text || String(n)) },
  "MULTI-AGENT ORCHESTRATION": { about: "How JARVIS hands work to the other agents.", api: "/api/orchestrator",
    source: "orchestrator.py — a shared blackboard of live conditions, prioritised directives and delegations.",
    stats: d => [["COORDINATOR", (d.coordinator || "").toUpperCase()], ["ACTIVE", d.active], ["DELEGATIONS", d.delegations_total],
      ["COLLABS", d.collabs_total], ["PREEMPTIONS", d.preemptions_total], ["CYCLES", d.cycles]],
    list: d => (d.directives || []).map(x => `P${x.priority} · ${x.agent} — ${x.title}`) },
  "LIVE OPERATIONS": { about: "Today's meeting load and the current mission.", ...AGENDA },
  "LICENSE & MONETIZATION": { about: "BUCS Pro licence status. On the owner machine: issue keys after a UPI payment.", api: "/api/license",
    source: "licensing.py — Ed25519-signed keys verified offline on every install; the signing key never leaves the owner's machine.",
    stats: d => [["PLAN", d.paid ? "BUCS PRO" : "NOT LICENSED"], ["MODE", d.owner ? "OWNER" : d.licensed ? "LICENSED" : "LOCKED"], ["KEY", d.key || "—"],
      ["DAYS LEFT", d.owner ? "∞" : d.days_left], ["INSTALL ID", d.install_id]],
    list: d => Object.entries(d.entitlements || {}).map(([k, v]) => `${v ? "✓" : "🔒"} ${k.replace(/_/g, " ")}`) },
  "SELF-HEALING · AUTONOMIC CORE": { about: "BUCS watches its own health every 30 s, repairs what it safely can (restarts crashed background tasks, refreshes stale feeds, restarts the scheduler), asks the connected AI to explain failures, and restarts itself through the launcher as a last resort. Code changes are never automatic.",
    api: "/api/health", source: "selfheal.py: real measurements of this process (event-loop lag, CPU, RAM), its tasks and scheduler, and feed freshness.",
    stats: d => [["OVERALL", (d.overall || "").toUpperCase()], ["AUTO-REPAIR", d.auto ? "ON" : "OFF"], ["RESTARTS 24 H", d.restarts_24h], ["UNDER LAUNCHER", d.under_launcher ? "YES" : "NO"]],
    list: d => Object.entries(d.checks || {}).map(([k, c]) => `${c.status.toUpperCase()} · ${k} — ${c.detail}`) },
  "AI BRAIN ROUTER": { about: "Which AI answers your commands, how often each route was used this session, and one-click switching.",
    api: "/api/llm/providers", source: "brain.py route counters (every streamed reply) + llm_providers.py registry and its last real health test.",
    stats: d => [["ACTIVE", ((d.providers || []).find(p => p.active) || {}).name], ["PROVIDERS", (d.providers || []).length],
      ["REPLIES", Object.values(d.usage?.replies || {}).reduce((a, b) => a + b, 0)], ["CLOUD", d.usage?.cloud_locked ? "LOCKED" : "ALLOWED"]],
    list: d => Object.entries(d.usage?.replies || {}).map(([k, n]) => `${k} — ${n} replies · last ${d.usage.last_ms?.[k] ?? "—"} ms`) },
  "MARKET WATCH": { about: "Live BTC, ETH, SOL and POL prices in USD and INR with 24-hour change.", api: "/api/market",
    source: "CoinGecko public API (no key), fetched by the server and cached for 2 minutes.",
    stats: d => [["ASSETS", (d.assets || []).length], ["FETCHED", _siAgo(d.fetched_at)], ["STATUS", d.error ? "ERROR" : "OK"]],
    list: d => (d.assets || []).map(a => `${a.symbol} · $${a.usd} · ₹${a.inr} · ${a.change_24h == null ? "—" : a.change_24h.toFixed(2) + "%"}`) },
  "KNOWLEDGE HUB": { about: "Everything BUCS can search, by source.", api: "/api/knowledge/stats",
    source: "knowledge.py — indexes memory facts, observations, insights, agent output, incidents, calendar, email and news.",
    stats: d => [["TOTAL", d.total], ...Object.entries(d.sources || {}).map(([k, v]) => [k.toUpperCase(), v])] },
  "EXTERNAL HARDWARE": { about: "Drives, adapters and power.", ...HARDWARE },
  "CONNECTED PERIPHERALS": { about: "Devices plugged into this machine.", ...HARDWARE },
  "ENTERPRISE COMMAND": { about: "Roles, operators and the audit trail.", api: "/api/enterprise",
    source: "auth.py + audit.py — local operators and an append-only audit log.",
    stats: d => [["ROLE", (d.role || "").toUpperCase()], ["OPERATOR", d.operator], ["OPERATORS", (d.operators || []).length],
      ["AUDIT ENTRIES", d.audit?.entries_total], ["PIN", d.pin_required ? "REQUIRED" : "OFF"]],
    list: d => (d.audit?.recent || []).slice(0, 8).map(a => `${a.action || a.kind || ""} — ${a.detail || a.msg || ""}`) },
  "DECISION SUPPORT": { about: "Proposed actions with predicted impact. Nothing runs without your approval unless autonomy is on.", api: "/api/decisions",
    source: "decisions.py — proposals from live conditions; impact is a model prediction, executed actions are real.",
    stats: d => [["AUTONOMY", d.autonomy ? "ON" : "OFF"], ["PROPOSALS", (d.proposals || []).length], ["EXECUTED", d.executed_total], ["AUTO-EXECUTED", d.auto_executed_total]],
    list: d => (d.proposals || []).map(p => `${(p.risk || "").toUpperCase()} · ${p.title}`) },
  "COMMAND RECOMMENDATIONS": { about: "What to do next, ranked.", api: "/api/recommendations", source: "insights.py + threats.py, ranked by severity.",
    stats: d => [["RECOMMENDATIONS", (d.recommendations || []).length]], list: d => (d.recommendations || []).map(r => `#${r.rank} ${r.title} — ${r.detail}`) },
  "COMMAND FLEET · MULTI-SITE": { about: "Every BUCS node reporting to this one.", api: "/api/fleet",
    source: "fleet.py — nodes report over an authenticated token; this machine is always a node.",
    stats: d => [["NODES", d.aggregate?.nodes], ["ONLINE", d.aggregate?.online], ["CORES", d.aggregate?.cpu_cores], ["RAM", _siNum(d.aggregate?.mem_total_gb, " GB")],
      ["AVG CPU", _siNum(d.aggregate?.avg_cpu, "%")], ["REPORTS", d.reports_total]],
    list: d => (d.nodes || []).map(n => `${n.name} · ${n.platform} · CPU ${_siNum(n.cpu, "%")}`) },
  "REMOTE ACCESS & AUTH": { about: "Who can reach this dashboard from another device.", api: "/api/auth/status",
    source: "auth.py — password + API tokens; sessions are listed here and can be revoked." },
  "PRODUCT EVOLUTION": { about: "Build progress by phase.", api: "/api/roadmap", source: "roadmap.py — each feature is checked against the running system.",
    stats: d => [["VERSION", d.version], ["PROGRESS", _siNum(d.progress_pct, "%")], ["FEATURES", `${d.completed_features} / ${d.total_features}`], ["PHASE", d.current_phase]],
    list: d => (d.phases || []).map(p => `${p.n}. ${p.name} — ${p.done}/${p.total} (${p.status})`) },
  "QUICK ACCESS": { about: "One-click commands. Each runs the same handler as typing or saying it.", api: null,
    source: "dashboard command handlers — scans and diagnostics read live endpoints; nothing here is simulated.",
    list: () => _siDom(".quick-grid .quick-btn", 12) },
  "WEB3 COMMAND CENTER": { about: "Optional token and community layer.", ...WEB3 },
  "WALLET": { about: "Your connected wallet. Keys never leave the browser.", ...WEB3 },
  "PORTFOLIO": { about: "Balances of the connected wallet.", ...WEB3 },
  "TOKEN CENTER": { about: "The configured token contract.", ...WEB3 },
  "TREASURY": { about: "Treasury address and live native balance.", ...WEB3 },
  "GOVERNANCE": { about: "Proposals and voting.", ...WEB3 },
  "MARKETPLACE": { about: "Plugins you can install.", ...WEB3 },
  "COMMUNITY & EVENTS": { about: "Community activity for the token layer.", ...WEB3 },
  "BLOCKCHAIN STATUS": { about: "The selected chain's RPC, block height and gas.", ...WEB3 },
};

function _sectionKey(el) {
  const c = el.cloneNode(true);
  c.querySelectorAll(".title-badge, button, .map-sub, .sec-info-i").forEach(x => x.remove());
  return c.textContent.replace(/\s+/g, " ").trim().toUpperCase();
}

async function openSectionInfo(key) {
  const def = SECTION_INFO[key]; if (!def) return;
  openCustomModal(key, "SECTION INFO · LIVE DATA", null, `<div style="color:var(--text-dim);font-style:italic">reading live data…</div>`);
  const seq = window._mSeq;
  let d = {}, err = null;
  if (def.api) {
    try { const r = await fetch(def.api); d = r.ok ? await r.json() : {}; if (!r.ok) err = `HTTP ${r.status}`; }
    catch (e) { err = e.message; }
  }
  let stats = [], list = [];
  try { stats = (def.stats ? def.stats(d) : []).filter(([, v]) => v !== undefined); } catch (e) {}
  try { list = (def.list ? def.list(d) : []).filter(Boolean).slice(0, 12); } catch (e) {}
  if (seq !== window._mSeq) return;              // another detail view replaced this one
  if (!def.stats && def.api && !err) {           // generic: top-level scalars only
    stats = Object.entries(d).filter(([, v]) => v == null || typeof v !== "object").slice(0, 8)
      .map(([k, v]) => [k.replace(/_/g, " ").toUpperCase(), v]);
  }
  $("#modal-body").innerHTML = `
    <div class="si-about">${escapeHTML(def.about || "")}</div>
    ${stats.length ? `<div class="mb-grid">${stats.map(([k, v]) =>
      `<div class="mb-stat"><span class="lbl">${escapeHTML(k)}</span><span class="val">${escapeHTML(v == null || v === "" ? "—" : String(v))}</span></div>`).join("")}</div>` : ""}
    ${list.length ? `<div class="mb-list">${list.map(t => `<div class="mb-row">${escapeHTML(String(t))}</div>`).join("")}</div>` : ""}
    ${err ? `<div class="mb-row" style="color:var(--error)">live data unavailable: ${escapeHTML(err)}</div>` : ""}
    ${!stats.length && !list.length && !err && def.api ? `<div class="mb-row">no data yet — this section fills in once its source reports.</div>` : ""}
    <div class="si-src"><span class="lbl">DATA SOURCE</span> ${escapeHTML(def.source || "")}
      ${def.api ? `<code>${escapeHTML(def.api)}</code>` : ""} · read ${new Date().toLocaleTimeString()}</div>`;
}

function initSectionInfo() {
  document.querySelectorAll(".panel-title, .bs-title").forEach(el => {
    const key = _sectionKey(el);
    if (!SECTION_INFO[key] || el.dataset.info) return;
    el.dataset.info = key;
    el.classList.add("has-info");
    const i = document.createElement("span");
    i.className = "sec-info-i"; i.textContent = "ⓘ"; i.setAttribute("aria-hidden", "true");
    const txt = [...el.childNodes].find(n => n.nodeType === 3 && n.textContent.trim());
    if (txt) txt.after(i); else (el.querySelector("span") || el).appendChild(i);
    el.setAttribute("tabindex", "0"); el.setAttribute("role", "button");
    el.title = `${key} — click for details and live data`;
    const go = (e) => {
      if (e.target.closest("button, a, input, select")) return;     // keep inline controls working
      e.stopPropagation(); openSectionInfo(key);
    };
    el.addEventListener("click", go);
    el.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(e); } });
  });
}
initSectionInfo();


/* ═══ SYSTEM · version, in-app updates, shutdown (updater.py) ═══ */
function sysOverlay(glyph, title, text) {
  window._bucsStopping = true;
  $("#sys-glyph").textContent = glyph; $("#sys-title").textContent = title; $("#sys-text").innerHTML = text;
  $("#sys-overlay").hidden = false;
}
let _sysVer = null;
function renderVersion(v) {
  _sysVer = { ...(_sysVer || {}), ...v };
  const pill = $("#sys-version"); if (!pill) return;
  const fv = $("#footer-ver"); if (fv && _sysVer.version) fv.textContent = "v" + _sysVer.version;
  const k = $("#sys-ver-k"), vv = $("#sys-ver-v");
  const set = (state, key, val, title) => {
    pill.dataset.state = state; pill.classList.toggle("update", state === "update");
    if (k) k.textContent = key; if (vv) vv.textContent = val; pill.title = title;
    if (!k || !vv) pill.textContent = `${key} ${val}`;
  };
  if (_sysVer.available && !_sysVer.managed_by_git)
    set("update", "UPDATE", "v" + _sysVer.latest, `Installed v${_sysVer.version || "—"} · v${_sysVer.latest} is available: click to see what's new and update`);
  else if (_sysVer.version)
    set("ok", _sysVer.managed_by_git ? "DEV BUILD" : "UP TO DATE", "v" + _sysVer.version, "BUCS version: click to check for updates");
  else set("idle", "BUILD", "v—", "BUCS version: click to check for updates");
}
async function refreshVersion() {
  try { renderVersion(await (await fetch("/api/system/version")).json()); } catch (e) {}
}
refreshVersion(); setInterval(refreshVersion, 10 * 60 * 1000);

async function openUpdates() {
  openCustomModal("BUCS UPDATES", "SIGNED RELEASES · VERIFIED BEFORE INSTALL", null,
    '<div style="color:var(--text-dim);font-style:italic">checking for updates…</div>');
  let v = {};
  try { v = await (await fetch("/api/system/update/check", { method: "POST" })).json(); renderVersion(v); } catch (e) {}
  const notes = (v.notes || []).map(n => `<div class="mb-row">• ${escapeHTML(n)}</div>`).join("");
  let html = `<div class="mb-grid">
      <div class="mb-stat"><span class="lbl">INSTALLED</span><span class="val">v${escapeHTML(v.version || "—")}</span></div>
      <div class="mb-stat"><span class="lbl">LATEST</span><span class="val">${v.latest ? "v" + escapeHTML(v.latest) : "—"}</span></div>
      <div class="mb-stat"><span class="lbl">CHECKED</span><span class="val">${v.checked_at ? new Date(v.checked_at * 1000).toLocaleTimeString() : "—"}</span></div></div>`;
  if (v.error) html += `<div class="mb-row" style="color:var(--warn)">Couldn't check for updates: ${escapeHTML(v.error)}</div>`;
  if (v.managed_by_git) {
    html += `<div class="mb-row">This is the owner's development copy (a git checkout). It updates with <b>git pull</b>, not in-app.${v.available ? ` A newer release (v${escapeHTML(v.latest)}) is published.` : ""}</div>`;
  } else if (v.available) {
    html += `<div class="model-section">— WHAT'S NEW IN v${escapeHTML(v.latest)}${v.date ? " · " + escapeHTML(v.date) : ""}</div><div class="mb-list">${notes || '<div class="mb-row">Improvements and fixes.</div>'}</div>
      <div class="mb-row">BUCS downloads the update, checks its signature, backs up the current version and restarts (about a minute). Your licence, settings and memory are kept. If the new version doesn't start, it rolls back automatically.</div>
      <div class="lic-acts"><button class="cmd-btn" id="upd-go">UPDATE &amp; RESTART</button></div>`;
  } else if (!v.error) {
    html += `<div class="mb-row" style="color:var(--success)">✓ You're on the latest version.</div>`;
  }
  $("#modal-body").innerHTML = html;
  $("#upd-go")?.addEventListener("click", async (e) => {
    e.target.disabled = true; e.target.textContent = "DOWNLOADING…";
    const r = await fetch("/api/system/update/apply", { method: "POST" }).then(x => x.json()).catch(err => ({ ok: false, error: err.message }));
    if (!r.ok) { e.target.disabled = false; e.target.textContent = "RETRY"; logEvent(`<span class="tag">[update]</span> ${escapeHTML(r.error || "update failed")}`, "warn"); return; }
    $("#tool-modal").hidden = true;
    sysOverlay("⟳", `Updating to v${r.to}`, "Installing and restarting. This page reloads by itself when BUCS is back.");
    waitForReturn(r.to);
  });
}
async function waitForReturn(expect) {
  await new Promise(res => setTimeout(res, 4000));
  for (let i = 0; i < 180; i++) {           // up to ~6 min (dependency installs on slow links)
    try {
      const v = await (await fetch("/api/system/version", { cache: "no-store" })).json();
      if (v.version) {
        if (expect && v.version !== expect) $("#sys-text").innerHTML = `BUCS came back on v${escapeHTML(v.version)}: the update was rolled back. Reloading…`;
        setTimeout(() => location.reload(), 1200); return;
      }
    } catch (e) {}
    await new Promise(res => setTimeout(res, 2000));
  }
  $("#sys-text").innerHTML = "BUCS hasn't come back yet. Check the BUCS window, or start it again from the desktop shortcut.";
}
makeInteractive($("#sys-version"), openUpdates, "BUCS version and updates");

/* power core: in-theme confirm popover (no browser confirm box) */
const PowerCtl = {
  open() {
    const pop = $("#power-pop"), b = $("#sys-power"); if (!pop || !b) return;
    pop.hidden = false; b.setAttribute("aria-expanded", "true"); b.classList.add("armed");
    setTimeout(() => $("#power-cancel")?.focus(), 0);
  },
  close(refocus) {
    const pop = $("#power-pop"), b = $("#sys-power"); if (!pop || !b || pop.hidden) return;
    pop.hidden = true; b.setAttribute("aria-expanded", "false"); b.classList.remove("armed");
    if (refocus) b.focus();
  },
  async go() {
    const go = $("#power-go"); if (go) { go.disabled = true; go.textContent = "STOPPING…"; }
    const r = await fetch("/api/system/shutdown", { method: "POST" }).then(x => x.json()).catch(() => ({ ok: true }));
    if (r.ok === false) {
      if (go) { go.disabled = false; go.textContent = "⏻ SHUT DOWN"; }
      this.close(true);
      logEvent(`<span class="tag">[sys]</span> ${escapeHTML(r.error || "shutdown refused")}`, "warn"); return;
    }
    this.close();
    try { ws && ws.close(); } catch (e) {}
    sysOverlay("⏻", "BUCS is shut down", "Everything stopped cleanly. You can close this tab.<br>To start again, double-click <b>BUCS</b> on your desktop.");
  },
};
$("#sys-power")?.addEventListener("click", (e) => { e.stopPropagation(); $("#power-pop")?.hidden ? PowerCtl.open() : PowerCtl.close(true); });
$("#power-cancel")?.addEventListener("click", () => PowerCtl.close(true));
$("#power-go")?.addEventListener("click", () => PowerCtl.go());
document.addEventListener("click", (e) => { if (!e.target.closest || !e.target.closest(".power-wrap")) PowerCtl.close(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") PowerCtl.close(true); });

/* mini system module: the two status tags reflect real state, not decoration */
function refreshSysMod() {
  const ch = $("#sm-channel"), tm = $("#sm-telemetry"); if (!ch || !tm) return;
  const linkUp = !!(ws && ws.readyState === 1);
  const fresh = linkUp && Date.now() - wsLastMsg < 6000;
  ch.classList.toggle("ok", linkUp);
  ch.title = linkUp ? "Live link to BUCS: connected (local WebSocket)" : "Live link to BUCS: reconnecting…";
  tm.classList.toggle("ok", fresh);
  tm.title = fresh ? "Telemetry streaming: last update " + Math.round((Date.now() - wsLastMsg) / 1000) + " s ago" : "Telemetry: waiting for data";
  const sp = $("#status-pill"), stx = $("#status-text");
  if (sp && stx) sp.title = "Dashboard link: " + stx.textContent;
}
setInterval(refreshSysMod, 1500); refreshSysMod();

/* ═══ SELF-HEALING · watchdog checks, repairs, AI diagnosis ═══ */
const HEAL_NAMES = { event_loop: "EVENT LOOP", cpu: "CPU", memory: "MEMORY", tasks: "BACKGROUND TASKS",
  scheduler: "SCHEDULER", weather: "WEATHER FEED", news: "NEWS FEED", google: "GOOGLE SYNC", brain: "AI BRAIN" };
function renderHeal(d) {
  if (!d || !$("#heal-grid")) return;
  const ov = $("#heal-overall"); ov.textContent = (d.overall || "—").toUpperCase(); ov.className = "heal-st-" + d.overall;
  $("#heal-auto").textContent = d.auto ? "ON" : "OFF";
  $("#heal-toggle").textContent = d.auto ? "AUTO-REPAIR: ON" : "AUTO-REPAIR: OFF";
  $("#heal-when").textContent = d.checked_at ? "checked " + new Date(d.checked_at * 1000).toLocaleTimeString() : "not checked yet";
  const checks = Object.entries(d.checks || {});
  if (checks.length) $("#heal-grid").innerHTML = checks.map(([k, c]) => `
    <div class="heal-chk ${escapeHTML(c.status)}" title="${escapeHTML(c.detail || "")}">
      <span class="hc-dot"></span><span class="hc-name">${escapeHTML(HEAL_NAMES[k] || k.toUpperCase())}</span>
      <span class="hc-detail">${escapeHTML(c.detail || "")}</span></div>`).join("");
  if (d.ai && d.ai.text) {
    $("#heal-ai").textContent = d.ai.text;
    $("#heal-ai-src").textContent = `${String(d.ai.engine || "AI").toUpperCase()} · ${new Date(d.ai.ts * 1000).toLocaleTimeString()}${d.ai.auto ? " · AUTO" : ""}`;
  }
  const log = d.log || [];
  $("#heal-log").innerHTML = log.length ? log.slice(0, 10).map(e => `
    <div class="heal-ev ${escapeHTML(e.level)}"><span class="he-t">${new Date(e.ts * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
      <span class="he-m">${escapeHTML(e.msg)}</span></div>`).join("") : `<div class="tf-empty">no repairs needed yet</div>`;
}
async function refreshHeal() { try { renderHeal(await (await fetch("/api/health")).json()); } catch (e) {} }
const _healPost = (u, b) => fetch(u, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(b || {}) }).then(r => r.json());
$("#heal-run")?.addEventListener("click", async (e) => {
  e.target.textContent = "CHECKING…"; renderHeal(await _healPost("/api/health/run")); e.target.textContent = "RUN CHECKS";
});
$("#heal-diag")?.addEventListener("click", async (e) => {
  e.target.textContent = "THINKING…"; $("#heal-ai").textContent = "Asking the connected AI to analyse the live checks…";
  const r = await _healPost("/api/health/diagnose").catch(err => ({ ok: false, error: err.message }));
  if (!r.ok && r.error) $("#heal-ai").textContent = r.error;
  e.target.textContent = "AI DIAGNOSE"; refreshHeal();
});
$("#heal-eng")?.addEventListener("click", async (e) => {
  e.target.textContent = "SENT…";
  const r = await _healPost("/api/health/engineer").catch(err => ({ ok: false, error: err.message }));
  logEvent(`<span class="tag">[self-heal]</span> ${r.ok === false ? escapeHTML(r.error || "engineering refused")
    : "diagnosis handed to engineering mode: review the proposal in the ENGINEERING panel"}`, r.ok === false ? "warn" : "info");
  setTimeout(() => { e.target.textContent = "SEND TO ENGINEERING"; }, 2500);
});
$("#heal-toggle")?.addEventListener("click", async () => {
  const on = $("#heal-auto").textContent !== "ON";
  const r = await _healPost("/api/health/auto", { on });
  if (r.ok === false) logEvent(`<span class="tag">[self-heal]</span> ${escapeHTML(r.error)}`, "warn"); else renderHeal(r);
});
// the header's live status lights open the self-healing panel
$("#sys-mod .sm-status")?.addEventListener("click", () => $("#heal-card")?.scrollIntoView({ behavior: "smooth", block: "center" }));
refreshHeal(); setInterval(refreshHeal, 30000);


/* ═══ DASHBOARD PASS · link state, measured AI performance, detail views, map linkage ═══
   Every value below is read from a live endpoint at render/click time. A failed read shows
   "unavailable", never an invented number. Detail views end with their source + read time. */

function bucsJump(sel) {
  const el = typeof sel === "string" ? document.querySelector(sel) : sel;
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "center" });
  el.classList.add("flash-target");
  setTimeout(() => el.classList.remove("flash-target"), 2200);
}
window.bucsJump = bucsJump;
const _srcFoot = (src, api) => `<div class="si-src"><span class="lbl">DATA SOURCE</span> ${escapeHTML(src)}
  ${api ? `<code>${escapeHTML(api)}</code>` : ""} · read ${new Date().toLocaleTimeString()}</div>`;
const _getJSON = async (u) => { const r = await fetch(u, { cache: "no-store" }); if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); };

/* — live link: values on screen are frozen while /ws is down — */
const LinkState = {
  since: null, timer: null,
  down() {
    if (this.since) return;
    this.since = Date.now();
    clearTimeout(this.timer);
    // brief blips (reconnect within 3 s) don't flash the banner
    this.timer = setTimeout(() => {
      if (!this.since) return;
      document.body.classList.add("link-down");
      const b = $("#link-banner"); if (b) b.hidden = false;
      this.paint();
    }, 3000);
  },
  up() {
    clearTimeout(this.timer);
    const was = this.since; this.since = null;
    document.body.classList.remove("link-down");
    const b = $("#link-banner"); if (b) b.hidden = true;
    if (was && Date.now() - was > 3000) {     // catch up on everything that was frozen
      try { seedThreats(); refreshAiPerf(); refreshSocResponse(); refreshFooterHealth(); } catch (e) {}
    }
  },
  paint() {
    const t = $("#link-banner-txt"); if (!t || !this.since) return;
    const s = Math.round((Date.now() - this.since) / 1000);
    t.textContent = `LIVE LINK LOST · values frozen since ${new Date(this.since).toLocaleTimeString()} (${s}s) · retrying`;
  },
};
setInterval(() => LinkState.paint(), 1000);
$("#link-banner-retry")?.addEventListener("click", () => { try { scheduleReconnect("manual"); } catch (e) {} });

/* — AI PERFORMANCE: measured command outcomes, latency and route usage — */
let _aiPerf = null;
async function refreshAiPerf() {
  const card = $("#ai-perf-card"); if (!card) return;
  try {
    const d = _aiPerf = await _getJSON("/api/dashboard/ai-performance");
    card.classList.remove("is-error");
    const pct = d.success_pct;
    $("#aip-success").innerHTML = pct == null ? "—" : `${Math.round(pct)}<span>%</span>`;
    const arc = $("#ai-arc");
    if (arc) {
      arc.setAttribute("stroke-dasharray", AI_CIRC.toFixed(1));
      arc.setAttribute("stroke-dashoffset", String((AI_CIRC * (1 - (pct == null ? 0 : pct / 100))).toFixed(1)));
    }
    $("#aip-cmds").textContent = d.commands ? `${d.commands} · ${d.failed} failed` : "none yet";
    $("#ai-rt").textContent = d.first_token_p50_ms != null ? `${(d.first_token_p50_ms / 1000).toFixed(2)} s` : "—";
    $("#aip-replies").textContent = d.replies ? String(d.replies) : "none yet";
    const ie = d.insight_engine || {};
    $("#aip-ins").textContent = ie.source ? String(ie.source).toUpperCase() : "—";
    $("#aip-when").textContent = d.commands ? `UPDATED ${new Date(d.ts * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : "NO COMMANDS YET";
  } catch (e) {
    card.classList.add("is-error");
    $("#aip-when").textContent = "UNAVAILABLE";
  }
}
refreshAiPerf(); setInterval(refreshAiPerf, 15000);
makeInteractive($("#ai-perf-card"), async () => {
  openCustomModal("AI PERFORMANCE", "MEASURED · THIS SESSION", null, '<div class="tf-empty">reading…</div>');
  const seq = window._mSeq;
  try {
    const d = await _getJSON("/api/dashboard/ai-performance");
    if (seq !== window._mSeq) return;
    const routes = Object.entries(d.routes || {});
    const ie = d.insight_engine || {}, lm = d.local_model || {};
    $("#modal-body").innerHTML = `<div class="mb-grid">
        ${_stat("COMMAND SUCCESS", d.success_pct == null ? "— (no commands yet)" : d.success_pct + "%", d.success_pct >= 90 ? "ok" : "")}
        ${_stat("COMMANDS", d.commands)}${_stat("FAST PATH", d.fast)}${_stat("VIA LLM", d.llm)}
        ${_stat("FAILED", d.failed, d.failed ? "warn" : "ok")}${_stat("CANCELLED", d.cancelled)}
        ${_stat("FIRST TOKEN p50", d.first_token_p50_ms != null ? d.first_token_p50_ms + " ms" : "—")}
        ${_stat("FIRST SPEECH p50", d.first_speech_p50_ms != null ? d.first_speech_p50_ms + " ms" : "—")}
        ${_stat("ACTIVE PROVIDER", (d.active_provider || "—").toUpperCase())}
        ${_stat("LOCAL MODEL tok/s", lm.tokens_per_sec ?? "—")}
      </div><div class="mb-list">
        ${routes.length ? routes.map(([k, n]) => _row(`${escapeHTML(k)} — ${n} replies`, `LAST ${d.route_ms?.[k] ?? "—"} ms`)).join("") : _none("No AI replies yet this session. Ask JARVIS something to start measuring.")}
        ${_row(`Insights engine: ${escapeHTML(ie.source || "—")} ${ie.model ? "· " + escapeHTML(ie.model) : ""}`, `LAST RUN ${_ago(ie.last_run)}`)}
      </div>
      <div class="mb-actions"><button class="cmd-btn" type="button" data-jump="#router-card">OPEN AI BRAIN ROUTER</button>
        <button class="cmd-btn" type="button" data-jump="#lai-card">LOCAL AI CONTROL</button></div>
      ${_srcFoot((d.sources || []).join(" · "), "/api/dashboard/ai-performance")}`;
  } catch (e) { $("#modal-body").innerHTML = `<div class="mb-row" style="color:var(--error)">unavailable: ${escapeHTML(e.message)}</div>`; }
}, "AI performance detail");

/* — SOC response status: what the decision engine may do on its own — */
async function refreshSocResponse() {
  const host = $("#soc-response"), txt = $("#soc-response-txt"); if (!host || !txt) return;
  const dot = host.querySelector(".rr-dot");
  try {
    const d = await _getJSON("/api/decisions");
    const n = (d.proposals || []).length;
    txt.textContent = `${d.autonomy ? "AUTONOMY ON · low-risk whitelist" : "AUTONOMY OFF · you approve every action"} · ${n} PROPOSAL${n === 1 ? "" : "S"} WAITING`;
    if (dot) dot.className = "rr-dot" + (d.autonomy ? " ok" : "");
  } catch (e) { txt.textContent = "decision engine unavailable"; if (dot) dot.className = "rr-dot"; }
}
refreshSocResponse(); setInterval(refreshSocResponse, 30000);
makeInteractive($("#soc-response"), () => bucsJump("#dec-card"), "Open DECISION SUPPORT");

/* — footer: real self-healing status instead of a fixed "ALL SYSTEMS NOMINAL" — */
async function refreshFooterHealth() {
  const el = $("#foot-health"); if (!el) return;
  try {
    const d = await _getJSON("/api/health");
    const checks = Object.values(d.checks || {});
    const ok = checks.filter(c => c.status === "ok").length;
    const ov = String(d.overall || "unknown").toUpperCase();
    el.textContent = checks.length ? `⌖ HEALTH ${ov} · ${ok}/${checks.length} CHECKS OK` : "⌖ HEALTH · first check pending";
    el.className = "foot-l " + (d.overall === "fail" ? "bad" : d.overall === "warn" ? "warn" : "");
  } catch (e) { el.textContent = "⌖ HEALTH UNAVAILABLE"; el.className = "foot-l warn"; }
}
refreshFooterHealth(); setInterval(refreshFooterHealth, 30000);
makeInteractive($("#foot-health"), () => bucsJump("#heal-card"), "Open SELF-HEALING");

/* — incident detail (threat feed, response timeline, response queue) — */
const ON_HOST = new Set(["system", "network", "ai", "productivity", "operations"]);
async function openIncident(id) {
  openCustomModal("INCIDENT", "THREAT INTELLIGENCE · LIVE", null, '<div class="tf-empty">reading…</div>');
  let d; const seq = window._mSeq;
  try { d = await _getJSON("/api/threats"); if (seq !== window._mSeq) return; }
  catch (e) { if (seq !== window._mSeq) return; $("#modal-body").innerHTML = `<div class="mb-row" style="color:var(--error)">threat engine unavailable: ${escapeHTML(e.message)}</div>`; return; }
  const ev = (d.events || []).find(e => e.id === id);
  if (!ev) { $("#modal-body").innerHTML = _none("This incident has rolled off the board (the engine keeps the latest 20).") + _srcFoot("threats.py", "/api/threats"); return; }
  $("#modal-title").textContent = ev.title;
  const g = window._geo;
  const mappable = ON_HOST.has(ev.category) && g && g.lat != null;
  const stageNote = {
    active: ev.auto_check ? "condition still true in live telemetry" : "observed; no automatic clear signal for this kind of incident",
    resolved: ev.resolved_note || "condition cleared in live telemetry",
    acknowledged: "acknowledged by an operator",
    expired: "older than 30 min with no clear signal; no longer counts toward risk",
  }[ev.stage] || "";
  $("#modal-body").innerHTML = `<div class="mb-grid">
      ${_stat("SEVERITY", (ev.severity || "").toUpperCase(), ev.severity === "low" ? "" : "warn")}
      ${_stat("CATEGORY", (ev.category || "").toUpperCase())}
      ${_stat("STATE", (ev.stage || "").toUpperCase(), ev.stage === "active" ? "warn" : "ok")}
      ${_stat("ASSIGNED", (ev.agent || "jarvis").toUpperCase())}
      ${_stat("DETECTED", new Date(ev.ts * 1000).toLocaleTimeString())}
      ${_stat("AGE", _ago(ev.ts))}
    </div><div class="mb-list">
      ${ev.detail ? _row(escapeHTML(ev.detail), "DETAIL") : ""}
      ${_row(escapeHTML(stageNote), "LIFECYCLE")}
      ${ON_HOST.has(ev.category) ? _row("Measured on this machine" + (g && g.city ? ` (${escapeHTML(g.city)}, IP-geolocated)` : ""), "WHERE") : ""}
    </div>
    <div class="mb-actions">
      ${["active", "resolved"].includes(ev.stage) ? `<button class="cmd-btn" type="button" data-ack="${escapeHTML(ev.id)}">ACKNOWLEDGE</button>` : ""}
      ${mappable ? `<button class="cmd-btn" type="button" data-map-lat="${g.lat}" data-map-lon="${g.lon}" data-map-id="${escapeHTML(ev.id)}" data-map-layer="threats" data-map-label="${escapeHTML(ev.title)}">SHOW ON MAP</button>` : ""}
      <button class="cmd-btn" type="button" data-jump="#tic-analytics">RESPONSE QUEUE</button>
    </div>
    ${_srcFoot("threats.py incident engine (live telemetry, news, agenda)", "/api/threats")}`;
}

/* — matrix domain detail — */
async function openDomain(key) {
  openCustomModal(`THREAT DOMAIN · ${key.toUpperCase()}`, "SIX-DOMAIN RISK MATRIX", null, '<div class="tf-empty">reading…</div>');
  const seq = window._mSeq;
  try {
    const d = await _getJSON("/api/threats");
    if (seq !== window._mSeq) return;
    const m = (d.matrix || {})[key] || {};
    const cat = { operational: "operations", infrastructure: "system", network: "network", ai: "ai", resource: "system", security: "external" }[key];
    const evs = (d.events || []).filter(e => e.category === cat).slice(0, 8);
    $("#modal-body").innerHTML = `<div class="mb-grid">
        ${_stat("SCORE", `${m.score ?? "—"} / 100`, m.score >= 60 ? "warn" : "ok")}
        ${_stat("TREND", (m.trend || "—").toUpperCase())}
        ${_stat("SIGNALS · 30 MIN", m.signals ?? 0)}
      </div><div class="mb-list">
        ${_row(escapeHTML(m.basis || "—"), "HOW THIS SCORE IS BUILT")}
        ${evs.length ? evs.map(e => `<div class="mb-row mb-click" data-incident="${escapeHTML(e.id)}" role="button" tabindex="0">${escapeHTML(e.title)}<div class="mb-row-meta">${escapeHTML((e.severity || "").toUpperCase())} · ${escapeHTML((e.stage || "").toUpperCase())} · ${_hm(e.ts)}</div></div>`).join("")
          : _none("No incidents in this domain right now.")}
      </div>${_srcFoot("threats.py matrix()", "/api/threats")}`;
  } catch (e) { $("#modal-body").innerHTML = `<div class="mb-row" style="color:var(--error)">unavailable: ${escapeHTML(e.message)}</div>`; }
}

/* — insight detail — */
function openInsight(d) {
  openCustomModal("JARVIS INSIGHT", `${String(d.source || "—").toUpperCase()} · ${new Date((d.ts || 0) * 1000).toLocaleTimeString()}`, null,
    `<div class="mb-list">${_row(escapeHTML(d.insight || ""), (d.severity || "info").toUpperCase())}
      ${d.recommendation ? _row(escapeHTML(d.recommendation), "RECOMMENDATION") : ""}
      ${_row(d.confidence != null ? `${d.confidence}% (reported by the model)` : "Rule-based insight: deterministic, no confidence score", "CONFIDENCE")}</div>
     <div class="mb-actions"><button class="cmd-btn" type="button" data-ask="${escapeHTML(d.insight || "")}">ASK JARVIS ABOUT THIS</button>
       <button class="cmd-btn" type="button" data-jump="#recs-card">RECOMMENDATIONS</button></div>
     ${_srcFoot("insights.py (local LLM → Claude → rules)", "/api/insights")}`);
}

/* — process detail — */
function openProcess(p) {
  openCustomModal(p.name, "PROCESS MONITOR · TOP CPU", null, `<div class="mb-grid">
      ${_stat("CPU · 100% = 1 CORE", `${p.cpu}%`, p.cpu > 50 ? "warn" : "")}
      ${_stat("MEMORY", p.mem_mb >= 1024 ? (p.mem_mb / 1024).toFixed(1) + " GB" : Math.round(p.mem_mb) + " MB")}
      ${_stat("INSTANCES", p.count || 1)}
    </div><div class="mb-list">${_row("Read-only view. BUCS does not kill processes from the dashboard; use Task Manager if you need to end one.", "NOTE")}</div>
    ${_srcFoot("procscan.py (psutil sweep, cached)", "/api/processes")}`);
}

/* one delegated handler for every detail trigger on the page */
function _detailFrom(el) {
  if (el.closest("#tool-modal") && !el.closest(".mb-click, [data-ack], [data-map-lat], [data-jump], [data-ask]")) return false;
  const inc = el.closest("[data-incident]");
  if (inc && !el.closest("button.ta-q-ack")) { openIncident(inc.dataset.incident); return true; }
  const dom = el.closest(".mx-row[data-domain]");
  if (dom) { openDomain(dom.dataset.domain); return true; }
  const ins = el.closest(".insight-item");
  if (ins && ins._data) { openInsight(ins._data); return true; }
  const pr = el.closest(".proc-row[data-i]");
  if (pr && window._lastProcs) { const p = (window._lastProcs.top_cpu || [])[+pr.dataset.i]; if (p) openProcess(p); return true; }
  const city = el.closest(".region-marker[data-lat]");
  if (city) { bucsShowOnMap({ lat: +city.dataset.lat, lon: +city.dataset.lon, id: "city:" + city.dataset.name, layer: "places", label: city.dataset.name }); return true; }
  const ack = el.closest("[data-ack]");
  if (ack) {
    ack.disabled = true; ack.textContent = "…";
    fetch("/api/threats/ack/" + encodeURIComponent(ack.dataset.ack), { method: "POST" }).then(r => r.json()).then(r => {
      if (r.ok === false) { ack.textContent = "REFUSED"; logEvent(`<span class="tag">[threat]</span> ACK refused: ${escapeHTML(r.error || "observer role")}`, "warn"); }
      else { ack.textContent = "ACKNOWLEDGED"; seedThreats(); }
    }).catch(() => { ack.textContent = "FAILED"; ack.disabled = false; });
    return true;
  }
  const mp = el.closest("[data-map-lat]");
  if (mp) { closeToolModal(); bucsShowOnMap({ lat: +mp.dataset.mapLat, lon: +mp.dataset.mapLon, id: mp.dataset.mapId, layer: mp.dataset.mapLayer, label: mp.dataset.mapLabel }); return true; }
  const jp = el.closest("[data-jump]");
  if (jp && jp.closest("#tool-modal")) { closeToolModal(); bucsJump(jp.dataset.jump); return true; }
  const ask = el.closest("[data-ask]");
  if (ask) { closeToolModal(); const i = $("#ask-input"); if (i) { i.value = "@jarvis explain and advise: " + ask.dataset.ask; i.focus(); bucsJump("#ask-form"); } return true; }
  return false;
}
document.addEventListener("click", (e) => {
  if (e.target.closest("a, input, select, textarea")) return;
  if (_detailFrom(e.target)) e.stopPropagation();      // capture phase: the card-level jump handlers stay quiet
}, true);
document.addEventListener("keydown", (e) => {
  if (e.key !== "Enter" && e.key !== " ") return;
  if (e.target.matches("[data-incident], .insight-item, .proc-row[data-i], .mb-click")) { e.preventDefault(); _detailFrom(e.target); }
});

/* — section info for the feature sections (they mount after initSectionInfo first ran) — */
Object.assign(SECTION_INFO, {
  "AI PERFORMANCE": { about: "How the AI is actually performing this session: command outcomes, latency and which brain answered.",
    api: "/api/dashboard/ai-performance", source: "realtime engine + brain route counters + insights engine status",
    stats: d => [["SUCCESS", d.success_pct == null ? "—" : d.success_pct + "%"], ["COMMANDS", d.commands], ["FAILED", d.failed],
      ["FIRST TOKEN p50", _siNum(d.first_token_p50_ms, " ms")], ["REPLIES", d.replies], ["PROVIDER", d.active_provider]] },
  "DISASTER RESPONSE": { about: "Natural hazards and digital outages from public feeds, ranked by severity and distance from you. Click any event for detail and to show it on the map.",
    api: "/api/disaster", source: "disaster.py: USGS, GDACS, NASA EONET, NDMA SACHET, CISA KEV, public statuspages, IODA. Every item names its feed and fetch time.",
    stats: d => [["EVENTS", d.counts?.total], ["CRITICAL", d.counts?.by_severity?.CRITICAL], ["HIGH", d.counts?.by_severity?.HIGH],
      ["NEAR YOU", d.counts?.near], ["FEEDS LIVE", `${(d.sources || []).filter(s => s.status === "ok").length}/${(d.sources || []).length}`]],
    list: d => (d.sources || []).map(s => `${s.label} · ${String(s.status).toUpperCase()} · ${s.count} items`) },
  "DEVICES & CONNECTIVITY": { about: "Smart devices you added (local protocols only) and the ways this node can link to your other machines.",
    api: "/api/devices", source: "devices.py: Home Assistant / Hue / Shelly / Tasmota / ESPHome / WLED / MQTT adapters, mDNS + SSDP discovery. Every action is audited.",
    stats: d => [["DEVICES", (d.devices || []).length], ["ONLINE", (d.devices || []).filter(x => x.status && x.status.online).length],
      ["DISCOVERED", (d.discovery?.items || []).length], ["ROLE", d.commander ? "COMMANDER" : "OBSERVER"]],
    list: d => (d.devices || []).map(x => `${x.name} · ${x.label} · ${x.status?.online ? "online" : "offline"}`) },
  "CYBER ANALYST": { about: "Scans this install for vulnerable dependencies, leaked secrets, exposure and risky config, with live threat intel.",
    api: "/api/secagent", source: "secagent.py: OSV.dev advisories, CISA KEV catalog, local checks. Fixes go through engineering mode and need your approval.",
    stats: d => [["POSTURE", d.score], ["CRITICAL", d.counts?.critical], ["HIGH", d.counts?.high], ["MEDIUM", d.counts?.medium], ["LOW", d.counts?.low],
      ["LAST FULL SCAN", _siAgo(d.last_scan?.full)]],
    list: d => (d.findings || []).slice(0, 10).map(f => `${String(f.severity).toUpperCase()} · ${f.title}`) },
});
setTimeout(initSectionInfo, 1500);
window.addEventListener("load", () => setTimeout(initSectionInfo, 400));


/* ═══ TIME MODULE · header clock with a seconds ring; click for world clocks, sun times,
   the next calendar event and a timer/stopwatch. Zones are remembered in localStorage
   (per browser); sun times are computed locally from the IP-geolocated lat/lon. ═══ */
const TimeModule = (() => {
  const KEY = "bucs.timezones";
  const DEFAULT_ZONES = ["UTC", "Europe/London", "America/New_York", "Asia/Tokyo"];
  const localTz = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "local"; } catch (e) { return "local"; } })();
  const CLOCK_KEY = "bucs.clock";           // stopwatch + timer + last tab survive a reload
  const validTz = (tz) => { try { new Intl.DateTimeFormat("en-GB", { timeZone: tz }); return true; } catch (e) { return false; } };
  let zones = DEFAULT_ZONES.slice();
  const loadZones = () => {
    try { const z = JSON.parse(localStorage.getItem(KEY) || "null"); if (Array.isArray(z)) zones = z.filter(x => typeof x === "string" && validTz(x)).slice(0, 8); } catch (e) {}
  };
  loadZones();
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(zones)); } catch (e) {} };
  const fmt = (d, tz, opt) => { try { return d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: tz, ...(opt || {}) }); } catch (e) { return "--:--"; } };
  const tzShort = (tz) => { try { return new Intl.DateTimeFormat("en-US", { timeZone: tz, timeZoneName: "short" }).formatToParts(new Date()).find(p => p.type === "timeZoneName").value; } catch (e) { return tz; } };
  const label = (tz) => tz === "UTC" ? "UTC" : tz.split("/").pop().replace(/_/g, " ");
  // whole-day difference vs local, so "+1" / "−1" shows across midnight
  const dayDiff = (tz) => {
    try {
      const k = (t) => new Date().toLocaleDateString("en-CA", { timeZone: t });
      const a = new Date(k(tz)), b = new Date(k(localTz));
      const d = Math.round((a - b) / 864e5); return d ? (d > 0 ? ` +${d}d` : ` −${-d}d`) : "";
    } catch (e) { return ""; }
  };

  // sunrise / sunset (SunCalc-style NOAA approximation, ±1–2 min)
  function sunTimes(date, lat, lon) {
    const rad = Math.PI / 180, dayMs = 864e5, J1970 = 2440588, J2000 = 2451545;
    const toJ = d => d.valueOf() / dayMs - 0.5 + J1970, fromJ = j => new Date((j + 0.5 - J1970) * dayMs);
    const d = toJ(date) - J2000, lw = rad * -lon, phi = rad * lat;
    const n = Math.round(d - 0.0009 - lw / (2 * Math.PI));
    const ds = 0.0009 + lw / (2 * Math.PI) + n;
    const M = rad * (357.5291 + 0.98560028 * ds);
    const C = rad * (1.9148 * Math.sin(M) + 0.02 * Math.sin(2 * M) + 0.0003 * Math.sin(3 * M));
    const L = M + C + rad * 102.9372 + Math.PI;
    const dec = Math.asin(Math.sin(L) * Math.sin(rad * 23.4397));
    const Jnoon = J2000 + ds + 0.0053 * Math.sin(M) - 0.0069 * Math.sin(2 * L);
    const cosw = (Math.sin(rad * -0.833) - Math.sin(phi) * Math.sin(dec)) / (Math.cos(phi) * Math.cos(dec));
    if (cosw < -1 || cosw > 1) return { polar: cosw < -1 ? "sun up all day" : "sun down all day" };
    const w = Math.acos(cosw);
    const Jset = J2000 + 0.0009 + (w + lw) / (2 * Math.PI) + n + 0.0053 * Math.sin(M) - 0.0069 * Math.sin(2 * L);
    return { rise: fromJ(Jnoon - (Jset - Jnoon)), set: fromJ(Jset), noon: fromJ(Jnoon) };
  }

  // timer + stopwatch keep running while the popover is closed
  const sw = { start: 0, acc: 0, running: false };
  const tm = { end: 0, running: false, total: 0 };
  let mode = "sw";
  const num = v => (typeof v === "number" && isFinite(v) && v >= 0 ? v : 0);
  const loadClock = () => {
    try {
      const c = JSON.parse(localStorage.getItem(CLOCK_KEY) || "null");
      if (!c || typeof c !== "object") return;
      if (c.sw) Object.assign(sw, { start: num(c.sw.start), acc: num(c.sw.acc), running: !!c.sw.running });
      if (c.tm) Object.assign(tm, { end: num(c.tm.end), total: num(c.tm.total), running: !!c.tm.running });
      if (c.mode === "sw" || c.mode === "tm") mode = c.mode;
    } catch (e) {}
  };
  loadClock();
  const saveClock = () => { try { localStorage.setItem(CLOCK_KEY, JSON.stringify({ sw, tm, mode })); } catch (e) {} };
  const two = n => String(n).padStart(2, "0");
  const dur = (ms) => { const s = Math.max(0, Math.floor(ms / 1000)); return `${s >= 3600 ? Math.floor(s / 3600) + ":" : ""}${two(Math.floor(s / 60) % 60)}:${two(s % 60)}`; };
  const swMs = () => sw.acc + (sw.running ? Date.now() - sw.start : 0);
  function beep() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      [0, 0.25, 0.5].forEach(t => { const o = ctx.createOscillator(), g = ctx.createGain();
        o.frequency.value = 880; g.gain.value = (typeof AudioCtl !== "undefined" && AudioCtl.muted) ? 0 : 0.08;
        o.connect(g); g.connect(ctx.destination); o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.15); });
    } catch (e) {}
  }

  const pop = () => document.getElementById("time-pop");
  const btn = () => document.getElementById("time-mod");
  let open = false;

  function tick() {
    const now = new Date();
    const r = document.getElementById("tm-ring");
    if (r) r.setAttribute("stroke-dasharray", `${now.getSeconds() + 1} 60`);
    const z = document.getElementById("tm-tz"); if (z && z.textContent === "—") z.textContent = tzShort(localTz);
    if (tm.running && Date.now() >= tm.end) {
      tm.running = false; saveClock(); beep();
      try { logEvent(`<span class="tag">[timer]</span> ${dur(tm.total)} timer finished`, "warn"); } catch (e) {}
      btn()?.classList.add("tm-done"); setTimeout(() => btn()?.classList.remove("tm-done"), 6000);
    }
    btn()?.classList.toggle("tm-active", sw.running || tm.running);
    if (open) paintLive();
  }

  function paintLive() {
    const now = new Date();
    const set = (id, t) => { const e = document.getElementById(id); if (e) e.textContent = t; };
    set("tp-local", now.toTimeString().slice(0, 8));
    document.querySelectorAll("#tp-zones [data-tz]").forEach(el => { el.querySelector(".tp-z-t").textContent = fmt(now, el.dataset.tz) + dayDiff(el.dataset.tz); });
    set("tp-sw", dur(swMs()));
    set("tp-tm", tm.running ? dur(tm.end - Date.now()) : (tm.total ? "done" : "--:--"));
  }

  function render() {
    const now = new Date(), g = window._geo || {};
    const lat = g.lat ?? (typeof userLat !== "undefined" ? userLat : null), lon = g.lon ?? (typeof userLon !== "undefined" ? userLon : null);
    let sunHTML = `<div class="tp-muted">location unknown: sun times need the IP-geolocated position</div>`;
    if (lat != null && lon != null) {
      const s = sunTimes(now, +lat, +lon);
      if (s.polar) sunHTML = `<div class="tp-muted">${s.polar}</div>`;
      else {
        const dl = s.set - s.rise, up = now > s.rise && now < s.set;
        sunHTML = `<div class="tp-sun"><span>☀ RISE <b>${fmt(s.rise, localTz)}</b></span><span>☾ SET <b>${fmt(s.set, localTz)}</b></span>
          <span>DAYLIGHT <b>${Math.floor(dl / 36e5)}h ${two(Math.round(dl / 6e4) % 60)}m</b></span></div>
          <div class="tp-sunbar" title="${up ? "sun is up" : "sun is down"}"><i style="left:${Math.max(0, Math.min(100, (now - s.rise) / dl * 100)).toFixed(1)}%"></i></div>
          <div class="tp-muted">computed for ${escapeHTML(g.city || "your location")} (${(+lat).toFixed(2)}, ${(+lon).toFixed(2)}, IP-geolocated)</div>`;
      }
    }
    // next calendar event: only when real agenda data exists
    let evHTML = "";
    try {
      const evs = ((typeof lastAgenda !== "undefined" && lastAgenda) ? lastAgenda.events : null) || [];
      const nx = evs.filter(e => e.start_ts && e.start_ts * 1000 > Date.now()).sort((a, b) => a.start_ts - b.start_ts)[0];
      if (nx) evHTML = `<div class="tp-sec"><div class="tp-h">NEXT EVENT</div><button type="button" class="tp-ev" data-tp-jump="#agenda-list">
        <b>${escapeHTML(nx.title || "event")}</b><span>${new Date(nx.start_ts * 1000).toLocaleString([], { weekday: "short", hour: "2-digit", minute: "2-digit" })} · in ${dur(nx.start_ts * 1000 - Date.now())}</span></button></div>`;
    } catch (e) {}
    let all = [];
    try { all = Intl.supportedValuesOf ? Intl.supportedValuesOf("timeZone") : []; } catch (e) {}
    pop().innerHTML = `
      <div class="tp-head"><div><div class="tp-big" id="tp-local">${now.toTimeString().slice(0, 8)}</div>
        <div class="tp-muted">${now.toLocaleDateString([], { weekday: "long", day: "numeric", month: "long", year: "numeric" })} · ${escapeHTML(localTz)} (${escapeHTML(tzShort(localTz))})${g.city ? " · " + escapeHTML(g.city) : ""}</div></div>
        <button type="button" class="tp-x" data-tp-close aria-label="Close">×</button></div>
      <div class="tp-sec"><div class="tp-h">WORLD CLOCKS <span class="tp-muted">· saved in this browser</span></div>
        <div class="tp-zones" id="tp-zones">${zones.map(z => `<div class="tp-z" data-tz="${escapeHTML(z)}"><span class="tp-z-n" title="${escapeHTML(z)}">${escapeHTML(label(z))}</span>
          <span class="tp-z-t">${fmt(now, z)}${dayDiff(z)}</span><button type="button" class="tp-z-x" data-tp-rm="${escapeHTML(z)}" aria-label="Remove ${escapeHTML(z)}">×</button></div>`).join("") || `<div class="tp-muted">no zones: add one below</div>`}</div>
        <form class="tp-add" id="tp-add" autocomplete="off"><input id="tp-add-in" list="tp-tzlist" placeholder="add a zone, e.g. Asia/Dubai" maxlength="40"/>
          <datalist id="tp-tzlist">${all.map(t => `<option value="${t}">`).join("")}</datalist><button type="submit" class="cmd-btn">ADD</button>
          ${zones.join() !== DEFAULT_ZONES.join() ? `<button type="button" class="ft-link" data-tp-reset>RESET</button>` : ""}</form>
        <div class="tp-err" id="tp-err"></div></div>
      ${evHTML}
      <div class="tp-sec"><div class="tp-h">SUN</div>${sunHTML}</div>
      <div class="tp-sec"><div class="tp-h"><span class="tp-mode${mode === "sw" ? " on" : ""}" data-tp-mode="sw" role="button" tabindex="0">STOPWATCH</span> · <span class="tp-mode${mode === "tm" ? " on" : ""}" data-tp-mode="tm" role="button" tabindex="0">TIMER</span></div>
        ${mode === "sw" ? `<div class="tp-clockrow"><span class="tp-mid" id="tp-sw">${dur(swMs())}</span>
            <button type="button" class="cmd-btn" data-tp-sw="toggle">${sw.running ? "PAUSE" : swMs() ? "RESUME" : "START"}</button>
            <button type="button" class="cmd-btn" data-tp-sw="reset" ${swMs() ? "" : "disabled"}>RESET</button></div>`
        : `<div class="tp-clockrow"><span class="tp-mid" id="tp-tm">${tm.running ? dur(tm.end - Date.now()) : "--:--"}</span>
            ${tm.running ? `<button type="button" class="cmd-btn" data-tp-tm="cancel">CANCEL</button>`
              : `<input id="tp-tm-min" type="number" min="1" max="600" value="${Math.round(tm.total / 6e4) || 25}" aria-label="minutes"/><span class="tp-muted">min</span>
                 <button type="button" class="cmd-btn" data-tp-tm="start">START</button>`}</div>`}
      </div>`;
  }

  function place() {
    const b = btn(), p = pop(); if (!b || !p) return;
    const r = b.getBoundingClientRect(), w = Math.min(340, window.innerWidth - 16);
    p.style.width = w + "px";
    p.style.top = Math.round(r.bottom + 8) + "px";
    p.style.left = Math.round(Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w))) + "px";
  }
  function show(on) {
    open = on; const p = pop(), b = btn(); if (!p || !b) return;
    if (on) { render(); p.hidden = false; place(); } else p.hidden = true;
    b.setAttribute("aria-expanded", String(on));
  }

  function init() {
    const b = btn(), p = pop(); if (!b || !p) return;
    b.addEventListener("click", (e) => { e.stopPropagation(); show(!open); });
    window.addEventListener("resize", () => { if (open) place(); });
    window.addEventListener("scroll", () => { if (open) place(); }, { passive: true });
    document.addEventListener("click", (e) => { const path = e.composedPath ? e.composedPath() : []; if (open && !path.includes(p) && !path.includes(b)) show(false); });
    document.addEventListener("keydown", (e) => { if (open && e.key === "Escape") { show(false); b.focus(); } });
    p.addEventListener("click", (e) => {
      const t = e.target;
      if (t.closest("[data-tp-close]")) return show(false);
      const rm = t.closest("[data-tp-rm]"); if (rm) { zones = zones.filter(z => z !== rm.dataset.tpRm); save(); return render(); }
      if (t.closest("[data-tp-reset]")) { zones = DEFAULT_ZONES.slice(); save(); return render(); }
      const md = t.closest("[data-tp-mode]"); if (md) { mode = md.dataset.tpMode; saveClock(); return render(); }
      const s = t.closest("[data-tp-sw]");
      if (s) {
        if (s.dataset.tpSw === "toggle") { if (sw.running) { sw.acc += Date.now() - sw.start; sw.running = false; } else { sw.start = Date.now(); sw.running = true; } }
        else { sw.acc = 0; sw.running = false; }
        saveClock();
        return render();
      }
      const tt = t.closest("[data-tp-tm]");
      if (tt) {
        if (tt.dataset.tpTm === "start") {
          const m = Math.max(1, Math.min(600, parseInt(document.getElementById("tp-tm-min")?.value, 10) || 0));
          tm.total = m * 6e4; tm.end = Date.now() + tm.total; tm.running = true;
        } else { tm.running = false; }
        saveClock();
        return render();
      }
      const j = t.closest("[data-tp-jump]"); if (j) { show(false); try { bucsJump(j.dataset.tpJump); } catch (e2) {} }
    });
    p.addEventListener("submit", (e) => {
      e.preventDefault();
      const v = (document.getElementById("tp-add-in")?.value || "").trim();
      const err = document.getElementById("tp-err");
      if (!v) return;
      const tz = v.toUpperCase() === "UTC" ? "UTC" : v;
      if (!validTz(tz)) { if (err) err.textContent = `"${v}" is not a time zone (use Region/City, e.g. Asia/Dubai)`; return; }
      if (zones.includes(tz)) { if (err) err.textContent = "already in the list"; return; }
      if (zones.length >= 8) { if (err) err.textContent = "up to 8 zones"; return; }
      zones.push(tz); save(); render();
    });
    // another open tab changed the zones / stopwatch / timer: follow it
    window.addEventListener("storage", (e) => {
      if (e.key === KEY) { loadZones(); if (open) render(); }
      else if (e.key === CLOCK_KEY) { loadClock(); if (open) render(); }
    });
    setInterval(tick, 1000); tick();
  }
  return { init, sunTimes, show };
})();
TimeModule.init();
