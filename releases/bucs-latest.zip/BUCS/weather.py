"""Open-Meteo client. Free, no key. Defaults to Hyderabad."""

import asyncio
import time

import httpx

from source_links import open_meteo as open_meteo_url


WMO_LABELS = {
    0: "Clear", 1: "Mostly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Rime fog",
    51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle",
    61: "Light rain", 63: "Rain", 65: "Heavy rain",
    66: "Freezing rain", 67: "Freezing rain",
    71: "Light snow", 73: "Snow", 75: "Heavy snow",
    77: "Snow grains",
    80: "Rain showers", 81: "Heavy showers", 82: "Violent showers",
    85: "Snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Storm w/ hail", 99: "Severe storm",
}

WMO_GLYPH = {
    0: "☀", 1: "🌤", 2: "⛅", 3: "☁",
    45: "🌫", 48: "🌫",
    51: "🌦", 53: "🌦", 55: "🌧",
    61: "🌧", 63: "🌧", 65: "🌧",
    66: "🌧", 67: "🌧",
    71: "🌨", 73: "🌨", 75: "❄",
    77: "❄",
    80: "🌦", 81: "🌧", 82: "🌧",
    85: "🌨", 86: "❄",
    95: "⛈", 96: "⛈", 99: "⛈",
}


class WeatherService:
    """Open-Meteo client. Accepts ad-hoc lat/lon at call time so the dashboard
    can re-fetch when the user's geolocation is detected. Each coord pair has
    its own short-lived cache."""

    def __init__(self, lat: float = 17.385, lon: float = 78.4867,
                 city: str = "Hyderabad", hub=None) -> None:
        self.lat, self.lon, self.city, self.hub = lat, lon, city, hub
        self._cache: dict[str, tuple[dict, float]] = {}
        self._inflight: dict[str, asyncio.Future] = {}
        self._stale: dict[str, tuple[dict, float]] = {}
        self.last_ok = 0.0

    async def get(self, lat: float | None = None, lon: float | None = None) -> dict | None:
        use_lat = float(lat) if lat is not None else self.lat
        use_lon = float(lon) if lon is not None else self.lon
        key = f"{use_lat:.3f},{use_lon:.3f}"
        cached = self._cache.get(key)
        if cached and time.time() < cached[1]:
            return cached[0]
        # the dashboard asks 2-3 times at load (IP geo, then GPS) — share one upstream call
        if key in self._inflight:
            return await asyncio.shield(self._inflight[key])
        fut = asyncio.get_running_loop().create_future()
        self._inflight[key] = fut
        try:
            res = await self._fetch(use_lat, use_lon, lat, lon, key, cached)
            fut.set_result(res)
            return res
        except Exception as e:                   # never leave waiters hanging
            fut.set_result({"error": str(e)})
            return {"error": str(e)}
        finally:
            self._inflight.pop(key, None)

    async def _fetch(self, use_lat, use_lon, lat, lon, key, cached):
        try:
            # connect fast, total well under the dashboard's own 15 s limit
            async with httpx.AsyncClient(timeout=httpx.Timeout(8.0, connect=4.0)) as c:
                r = await c.get(
                    "https://api.open-meteo.com/v1/forecast",
                    params={
                        "latitude": use_lat,
                        "longitude": use_lon,
                        "current": "temperature_2m,relative_humidity_2m,"
                                   "weather_code,wind_speed_10m,apparent_temperature",
                        "timezone": "auto",
                    },
                )
                r.raise_for_status()
                payload = r.json()
                data = payload.get("current", {}) or {}
        except Exception as e:
            if self.hub:
                await self.hub.broadcast({
                    "type": "log", "level": "warn",
                    "msg": f"weather fetch failed ({key}): {e}",
                })
            # serve the last good reading (marked stale) rather than an error
            last = cached or self._stale.get(key)
            if last:
                return {**last[0], "stale": True}
            return {"error": "weather service unreachable — retrying shortly"}

        code = int(data.get("weather_code") or 0)
        result = {
            "city": self.city if (lat is None and lon is None) else "Your location",
            "lat": use_lat,
            "lon": use_lon,
            "temp_c": data.get("temperature_2m"),
            "feels_c": data.get("apparent_temperature"),
            "humidity": data.get("relative_humidity_2m"),
            "wind_kmh": data.get("wind_speed_10m"),
            "code": code,
            "label": WMO_LABELS.get(code, "—"),
            "glyph": WMO_GLYPH.get(code, "◐"),
            "fetched_at": time.time(),
            "source": "Open-Meteo",
            "source_url": open_meteo_url(use_lat, use_lon),
        }
        # 5-minute cache per coord pair; the last good reading is kept for outages
        self._cache[key] = (result, time.time() + 300)
        self._stale[key] = (result, 0)
        self.last_ok = time.time()
        return result
